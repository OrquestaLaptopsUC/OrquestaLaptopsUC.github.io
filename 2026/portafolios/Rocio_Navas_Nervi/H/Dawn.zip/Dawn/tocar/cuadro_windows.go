//go:build windows

package main

import (
	"syscall"
	"unsafe"
)

// Un cuadro de mensaje de Windows (MessageBoxW). Devuelve el botón apretado (4 = Reintentar, 2 = Cancelar).
func cuadro(texto string, tipo uintptr) int {
	u := syscall.NewLazyDLL("user32.dll").NewProc("MessageBoxW")
	t, _ := syscall.UTF16PtrFromString(texto)
	c, _ := syscall.UTF16PtrFromString("Tocar Dawn")
	r, _, _ := u.Call(0, uintptr(unsafe.Pointer(t)), uintptr(unsafe.Pointer(c)), tipo|0x00010000) // MB_SETFOREGROUND
	return int(r)
}
