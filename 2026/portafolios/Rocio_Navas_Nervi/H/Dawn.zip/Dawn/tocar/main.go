// DAWN OF COMPUTER MUSIC · Tocar Dawn (la app de los intérpretes)
// Orquesta de Laptops UC
//
// Doble clic y se abre en Chrome la página para tocar, conectada a la directora.
// No se instala nada y no hay que escribir ninguna dirección:
//  1. Prueba primero la dirección de la vez anterior.
//  2. Escucha el aviso que el servidor de la directora manda cada segundo por la
//     red local (difusión UDP, puerto 48080).
//  3. Mientras tanto, recorre la red local (cada laptop de la misma red, puertos
//     8080 a 8085) preguntando /info hasta encontrar el servidor de Dawn.
//
// Si en 12 s no la encuentra, pregunta qué hacer: buscar de nuevo, escribir la
// dirección a mano o tocar sin red (abre la copia de la página que lleva adentro).
//
// Compilar: ver construir.sh.
package main

import (
	"bufio"
	"context"
	_ "embed"
	"encoding/json"
	"fmt"
	"net"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strconv"
	"strings"
	"sync"
	"time"
)

const (
	app          = "oluc-dawn" // lo que responde el servidor de Dawn en /info
	puertoBaliza = 48080
	espera       = 12 * time.Second
)

//go:embed incorporado/docm.html
var incorporada []byte

var soloBuscar = false // -solo-buscar: imprime la dirección y no abre nada (para probar)

func main() {
	for _, a := range os.Args[1:] {
		if a == "-solo-buscar" || a == "--solo-buscar" {
			soloBuscar = true
		}
	}
	for {
		if url := buscar(espera); url != "" {
			guardar(url)
			abrir(url)
			return
		}
		if soloBuscar {
			fmt.Println("no encontré la directora")
			os.Exit(1)
		}
		switch accion, texto := preguntar(); accion {
		case "buscar":
			continue
		case "direccion":
			if url := normalizar(texto); url != "" && esDawn(url, 3*time.Second) {
				guardar(url)
				abrir(url)
				return
			}
			avisar("No encontré la obra en «" + texto + "». Revisa la dirección que muestra el timer de la directora.")
		case "sin red":
			abrirSinRed()
			return
		default:
			return
		}
	}
}

/* ---------- buscar a la directora ---------- */

func buscar(limite time.Duration) string {
	ctx, cancel := context.WithTimeout(context.Background(), limite)
	defer cancel()
	hallado := make(chan string, 1)
	encontrar := func(u string) {
		select {
		case hallado <- u:
			cancel()
		default:
		}
	}
	var wg sync.WaitGroup

	soloBarrido := os.Getenv("DAWN_SOLO_BARRIDO") != "" // para probar el recorrido de la red sin la baliza

	// 1. La dirección de la vez anterior.
	if u := leerGuardada(); u != "" && !soloBarrido {
		wg.Add(1)
		go func() {
			defer wg.Done()
			if esDawn(u, 1500*time.Millisecond) {
				encontrar(u)
			}
		}()
	}

	// 2. La baliza del servidor.
	wg.Add(1)
	go func() {
		defer wg.Done()
		c, err := net.ListenPacket("udp4", fmt.Sprintf(":%d", puertoBaliza))
		if err != nil || soloBarrido {
			return
		}
		defer c.Close()
		go func() { <-ctx.Done(); c.Close() }()
		buf := make([]byte, 256)
		for ctx.Err() == nil {
			n, desde, err := c.ReadFrom(buf)
			if err != nil {
				return
			}
			campos := strings.Fields(string(buf[:n]))
			if len(campos) < 2 || campos[0] != "OLUC-DAWN" {
				continue
			}
			p, err := strconv.Atoi(campos[1])
			ua, ok := desde.(*net.UDPAddr)
			if err != nil || !ok {
				continue
			}
			u := fmt.Sprintf("http://%s:%d/", ua.IP.String(), p)
			if esDawn(u, 1500*time.Millisecond) {
				encontrar(u)
				return
			}
		}
	}()

	// 3. Recorrer la red local, en rondas (la primera vez, macOS pide permiso de «Red local»:
	//    mientras la persona no lo acepta, las conexiones fallan y se reintenta).
	wg.Add(1)
	go func() {
		defer wg.Done()
		for ctx.Err() == nil {
			inicioRonda := time.Now()
			if u := barrer(ctx); u != "" {
				encontrar(u)
				return
			}
			if d := 2*time.Second - time.Since(inicioRonda); d > 0 {
				select {
				case <-ctx.Done():
				case <-time.After(d):
				}
			}
		}
	}()

	go func() { wg.Wait(); cancel() }()
	select {
	case u := <-hallado:
		return u
	case <-ctx.Done():
		select {
		case u := <-hallado:
			return u
		default:
			return ""
		}
	}
}

// Recorre cada red local (como mucho las 254 direcciones de una red /24 alrededor de esta laptop)
// en los puertos 8080 a 8085, primero el 8080 en todas.
func barrer(ctx context.Context) string {
	var candidatos []string
	for p := 8080; p <= 8085; p++ {
		for _, ip := range vecinos() {
			candidatos = append(candidatos, fmt.Sprintf("%s:%d", ip, p))
		}
	}
	ctx2, cancel := context.WithCancel(ctx)
	defer cancel()
	trabajo := make(chan string)
	hallado := make(chan string, 1)
	var wg sync.WaitGroup
	for i := 0; i < 128; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			d := net.Dialer{Timeout: 450 * time.Millisecond}
			for hp := range trabajo {
				c, err := d.DialContext(ctx2, "tcp", hp)
				if err != nil {
					continue
				}
				c.Close()
				if u := "http://" + hp + "/"; esDawn(u, 1500*time.Millisecond) {
					select {
					case hallado <- u:
						cancel()
					default:
					}
				}
			}
		}()
	}
enviar:
	for _, hp := range candidatos {
		select {
		case trabajo <- hp:
		case <-ctx2.Done():
			break enviar
		}
	}
	close(trabajo)
	wg.Wait()
	select {
	case u := <-hallado:
		return u
	default:
		return ""
	}
}

var (
	_, cgnat, _       = net.ParseCIDR("100.64.0.0/10")
	prefijosVirtuales = []string{"utun", "tun", "tap", "tailscale", "wg", "zt", "ppp", "ipsec", "gif", "stf",
		"bridge", "vmnet", "vboxnet", "docker", "veth", "virbr", "awdl", "llw", "anpi"}
)

// Las direcciones vecinas de esta laptop en cada red local (sin VPN ni redes virtuales).
func vecinos() []string {
	var out []string
	visto := map[string]bool{}
	ifs, _ := net.Interfaces()
	for _, i := range ifs {
		if i.Flags&net.FlagUp == 0 || i.Flags&net.FlagLoopback != 0 {
			continue
		}
		virtual := false
		for _, p := range prefijosVirtuales {
			if strings.HasPrefix(strings.ToLower(i.Name), p) {
				virtual = true
			}
		}
		if virtual {
			continue
		}
		addrs, _ := i.Addrs()
		for _, a := range addrs {
			n, ok := a.(*net.IPNet)
			if !ok {
				continue
			}
			ip4 := n.IP.To4()
			if ip4 == nil || ip4.IsLinkLocalUnicast() || ip4.IsLoopback() || cgnat.Contains(ip4) {
				continue
			}
			unos, bits := n.Mask.Size()
			if bits != 32 || unos < 24 { // redes grandes: solo la /24 de esta laptop
				unos = 24
			}
			tam := 1 << (32 - unos)
			base := ipNum(ip4) &^ uint32(tam-1)
			for k := 1; k < tam-1; k++ {
				ip := numIP(base + uint32(k)).String()
				if !visto[ip] {
					visto[ip] = true
					out = append(out, ip)
				}
			}
		}
	}
	return out
}

func ipNum(ip net.IP) uint32 {
	return uint32(ip[0])<<24 | uint32(ip[1])<<16 | uint32(ip[2])<<8 | uint32(ip[3])
}
func numIP(n uint32) net.IP { return net.IPv4(byte(n>>24), byte(n>>16), byte(n>>8), byte(n)) }

// ¿Responde ahí el servidor de Dawn?
func esDawn(u string, t time.Duration) bool {
	cl := http.Client{Timeout: t}
	res, err := cl.Get(strings.TrimSuffix(u, "/") + "/info")
	if err != nil {
		return false
	}
	defer res.Body.Close()
	var info map[string]any
	return json.NewDecoder(res.Body).Decode(&info) == nil && info["app"] == app
}

// «192.168.0.10:8080», «192.168.0.10» o «http://…» → http://ip:puerto/
func normalizar(t string) string {
	t = strings.TrimSpace(t)
	t = strings.TrimPrefix(strings.TrimPrefix(t, "http://"), "https://")
	t = strings.TrimSuffix(strings.SplitN(t, "/", 2)[0], "/")
	if t == "" {
		return ""
	}
	if _, _, err := net.SplitHostPort(t); err != nil {
		t += ":8080"
	}
	return "http://" + t + "/"
}

/* ---------- recordar la dirección ---------- */

func archivoGuardado() string {
	d, err := os.UserConfigDir()
	if err != nil {
		return ""
	}
	return filepath.Join(d, "oluc-dawn", "directora.txt")
}

func leerGuardada() string {
	f := archivoGuardado()
	if f == "" {
		return ""
	}
	b, err := os.ReadFile(f)
	if err != nil {
		return ""
	}
	return strings.TrimSpace(string(b))
}

func guardar(u string) {
	if f := archivoGuardado(); f != "" {
		_ = os.MkdirAll(filepath.Dir(f), 0o755)
		_ = os.WriteFile(f, []byte(u+"\n"), 0o644)
	}
}

/* ---------- abrir la página ---------- */

func abrir(u string) {
	if soloBuscar {
		fmt.Println(u)
		return
	}
	switch runtime.GOOS {
	case "darwin":
		// La orquesta usa Chrome; si no está, el navegador que tenga la laptop.
		if exec.Command("open", "-a", "Google Chrome", u).Run() != nil {
			_ = exec.Command("open", u).Run()
		}
	case "windows":
		_ = exec.Command("rundll32", "url.dll,FileProtocolHandler", u).Run()
	default:
		_ = exec.Command("xdg-open", u).Run()
	}
}

// Sin red: la docm.html de la carpeta de la obra (junto a la app) o, si no está, la copia que lleva la app.
func abrirSinRed() {
	var archivo string
	if exe, err := os.Executable(); err == nil {
		d := filepath.Dir(exe)
		for i := 0; i < 4 && archivo == ""; i++ { // .app/Contents/MacOS → carpeta de la obra
			if _, err := os.Stat(filepath.Join(d, "docm.html")); err == nil {
				archivo = filepath.Join(d, "docm.html")
			}
			d = filepath.Dir(d)
		}
	}
	if archivo == "" {
		archivo = filepath.Join(os.TempDir(), "oluc-dawn-docm.html")
		if err := os.WriteFile(archivo, incorporada, 0o644); err != nil {
			return
		}
	}
	u := "file://" + filepath.ToSlash(archivo)
	if runtime.GOOS == "windows" {
		u = "file:///" + filepath.ToSlash(archivo)
	}
	abrir(u)
}

/* ---------- preguntar ---------- */

const textoNoEncontre = "No encontré a la directora en esta red.\n\n" +
	"Revisa que esta laptop esté en el mismo Wi-Fi que la directora y que su app «Servidor Dawn» esté abierta."

// Devuelve "buscar", "direccion" (con el texto escrito), "sin red" o "" (cerrar).
func preguntar() (string, string) {
	switch runtime.GOOS {
	case "darwin":
		guion := `display dialog "` + escaparAS(textoNoEncontre+"\n\nSi la conoces, escribe la dirección que muestra su timer:") +
			`" default answer "` + escaparAS(strings.TrimSuffix(strings.TrimPrefix(leerGuardada(), "http://"), "/")) +
			`" buttons {"Tocar sin red", "Conectar a esa dirección", "Buscar de nuevo"} default button "Buscar de nuevo" with title "Tocar Dawn"`
		out, err := exec.Command("osascript", "-e", guion).Output()
		if err != nil {
			return "", "" // la cerró
		}
		r := string(out)
		texto := ""
		if i := strings.Index(r, "text returned:"); i >= 0 {
			texto = strings.TrimSpace(r[i+len("text returned:"):])
		}
		switch {
		case strings.Contains(r, "Buscar de nuevo"):
			return "buscar", ""
		case strings.Contains(r, "Conectar"):
			return "direccion", texto
		case strings.Contains(r, "Tocar sin red"):
			return "sin red", ""
		}
		return "", ""
	case "windows":
		switch cuadro(textoNoEncontre+"\n\nReintentar: buscar de nuevo.\nCancelar: tocar sin red (con la copia de esta laptop).", 0x5|0x40) {
		case 4: // Reintentar
			return "buscar", ""
		case 2: // Cancelar
			return "sin red", ""
		}
		return "", ""
	default:
		fmt.Println(textoNoEncontre)
		fmt.Print("Dirección (Enter para buscar de nuevo, «sin red» para tocar sin red): ")
		l, _ := bufio.NewReader(os.Stdin).ReadString('\n')
		l = strings.TrimSpace(l)
		switch {
		case l == "":
			return "buscar", ""
		case l == "sin red":
			return "sin red", ""
		}
		return "direccion", l
	}
}

func avisar(t string) {
	switch runtime.GOOS {
	case "darwin":
		_ = exec.Command("osascript", "-e", `display dialog "`+escaparAS(t)+`" buttons {"OK"} default button "OK" with title "Tocar Dawn"`).Run()
	case "windows":
		cuadro(t, 0x40)
	default:
		fmt.Println(t)
	}
}

func escaparAS(t string) string {
	return strings.ReplaceAll(strings.ReplaceAll(t, `\`, `\\`), `"`, `\"`)
}
