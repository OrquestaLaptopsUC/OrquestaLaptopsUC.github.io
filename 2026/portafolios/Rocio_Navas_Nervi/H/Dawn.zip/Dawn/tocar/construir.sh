#!/bin/bash
# Reconstruye "Tocar Dawn.app" (y el .exe de Windows), la app de los intérpretes. Solo hace falta si
# se modifica main.go o docm.html (la app lleva una copia de la página para tocar sin red). Requiere Go
# (go.dev); en un Mac, además, las herramientas de línea de comandos de Xcode (lipo y codesign).
set -e
cd "$(dirname "$0")"
mkdir -p incorporado
cp ../docm.html incorporado/docm.html
export CGO_ENABLED=0
GOOS=darwin GOARCH=arm64 go build -trimpath -ldflags "-s -w" -o /tmp/tocar-dawn-arm64 .
GOOS=darwin GOARCH=amd64 go build -trimpath -ldflags "-s -w" -o /tmp/tocar-dawn-amd64 .
GOOS=windows GOARCH=amd64 go build -trimpath -ldflags "-s -w -H windowsgui" -o "../Tocar Dawn (Windows).exe" .
APP="../Tocar Dawn.app"
mkdir -p "$APP/Contents/MacOS"
if command -v lipo >/dev/null; then
  lipo -create -output "$APP/Contents/MacOS/tocar-dawn" /tmp/tocar-dawn-arm64 /tmp/tocar-dawn-amd64
  codesign --force --deep -s - "$APP"
else
  echo "(sin lipo: queda solo la versión para Apple Silicon)"
  cp /tmp/tocar-dawn-arm64 "$APP/Contents/MacOS/tocar-dawn"
fi
chmod 755 "$APP/Contents/MacOS/tocar-dawn"
echo "listo: $APP"
