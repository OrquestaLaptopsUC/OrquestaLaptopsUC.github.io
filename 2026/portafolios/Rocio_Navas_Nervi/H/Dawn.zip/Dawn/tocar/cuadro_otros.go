//go:build !windows

package main

func cuadro(string, uintptr) int { return 0 }
