@echo off
setlocal EnableDelayedExpansion
title Estudio de Sintesis - Instalacion
cd /d "%~dp0"
echo ============================================================
echo   Estudio de Sintesis - instalacion de dependencias
echo ============================================================
echo.

rem --- Buscar Python 3 (lanzador "py" o "python") ---
set "PY="
where py >nul 2>nul && (py -3 -c "import sys" >nul 2>nul && set "PY=py -3")
if not defined PY (
    where python >nul 2>nul && (python -c "import sys; sys.exit(0 if sys.version_info[0]==3 else 1)" >nul 2>nul && set "PY=python")
)
if not defined PY (
    echo No se encontro Python 3. Intentando instalarlo con winget...
    winget install -e --id Python.Python.3.12 --accept-package-agreements --accept-source-agreements
    echo.
    echo Si la instalacion de Python termino bien, CIERRA esta ventana y vuelve
    echo a ejecutar instalar.bat. Si winget no esta disponible, descarga Python desde
    echo https://www.python.org/downloads/  ^(marca "Add python.exe to PATH"^).
    pause
    exit /b 1
)
echo Python encontrado:
%PY% --version
%PY% -c "import tkinter" >nul 2>nul || (
    echo.
    echo ERROR: tu Python no incluye tkinter. Reinstala Python desde python.org
    echo marcando la opcion "tcl/tk and IDLE".
    pause
    exit /b 1
)

rem --- Entorno virtual ---
if not exist ".venv\Scripts\python.exe" (
    echo.
    echo Creando entorno virtual en .venv ...
    %PY% -m venv .venv || ( echo ERROR creando el entorno virtual & pause & exit /b 1 )
)
set "VPY=.venv\Scripts\python.exe"

echo.
echo Actualizando pip...
"%VPY%" -m pip install --upgrade pip

echo.
echo Instalando dependencias: numpy, scipy, matplotlib, sounddevice, soundfile ...
"%VPY%" -m pip install -r requirements.txt || ( echo ERROR instalando dependencias & pause & exit /b 1 )

echo.
echo Instalando numba (opcional, acelera mucho los filtros y efectos)...
"%VPY%" -m pip install numba || echo  - numba no se pudo instalar: el programa funcionara igual, algo mas lento.

echo.
echo Verificando la instalacion...
"%VPY%" -c "import numpy, scipy, matplotlib, sounddevice, soundfile, tkinter; print('  numpy', numpy.__version__, '| scipy', scipy.__version__, '| matplotlib', matplotlib.__version__); print('  dispositivos de audio OK:', len(sounddevice.query_devices()) > 0)" || ( echo ERROR en la verificacion & pause & exit /b 1 )
"%VPY%" -c "import numba; print('  numba', numba.__version__)" 2>nul

echo.
echo Preparando los nucleos DSP (la primera compilacion con numba tarda un poco)...
"%VPY%" -c "import sys; sys.path.insert(0,'.'); from dsp import kernels; kernels.warmup(); print('  listo')"

echo.
echo ============================================================
echo   Instalacion completa. Abre el programa con ejecutar.bat
echo ============================================================
pause
