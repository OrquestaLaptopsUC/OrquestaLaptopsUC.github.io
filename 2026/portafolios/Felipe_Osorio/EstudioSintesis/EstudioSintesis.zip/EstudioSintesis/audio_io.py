"""Carga, guardado y reproducción de audio."""
from __future__ import annotations

import os
import threading
import time

import numpy as np
from scipy import signal
from scipy.io import wavfile

try:
    import soundfile as sf
except Exception:  # pragma: no cover
    sf = None

try:
    import sounddevice as sd
except Exception:  # pragma: no cover
    sd = None


LOAD_TYPES = [("Audio", "*.wav *.flac *.ogg *.aif *.aiff *.mp3"), ("Todos", "*.*")]
SAVE_FORMATS = {
    "WAV 16 bits": ("WAV", "PCM_16", ".wav"),
    "WAV 24 bits": ("WAV", "PCM_24", ".wav"),
    "WAV 32 bits flotante": ("WAV", "FLOAT", ".wav"),
    "FLAC 24 bits": ("FLAC", "PCM_24", ".flac"),
    "OGG Vorbis": ("OGG", "VORBIS", ".ogg"),
}


def load_audio(path: str) -> tuple[np.ndarray, int]:
    """Devuelve (datos float64 (n, ch), sr)."""
    if sf is not None:
        try:
            data, sr = sf.read(path, dtype="float64", always_2d=True)
            return data, int(sr)
        except Exception:
            if not path.lower().endswith(".wav"):
                raise
    sr, data = wavfile.read(path)
    if data.dtype.kind == "i":
        data = data.astype(np.float64) / np.iinfo(data.dtype).max
    elif data.dtype.kind == "u":
        data = (data.astype(np.float64) - 128) / 128
    else:
        data = data.astype(np.float64)
    if data.ndim == 1:
        data = data[:, None]
    return data, int(sr)


def save_audio(path: str, data: np.ndarray, sr: int, fmt: str = "WAV 24 bits") -> str:
    data = np.clip(np.asarray(data, dtype=np.float64), -1.0, 1.0)
    container, subtype, ext = SAVE_FORMATS.get(fmt, SAVE_FORMATS["WAV 24 bits"])
    if not os.path.splitext(path)[1]:
        path += ext
    if sf is not None:
        sf.write(path, data, sr, format=container, subtype=subtype)
    else:
        wavfile.write(os.path.splitext(path)[0] + ".wav", sr, (data * 32767).astype(np.int16))
    return path


def resample(data: np.ndarray, sr_in: int, sr_out: int) -> np.ndarray:
    if sr_in == sr_out:
        return data
    from math import gcd
    g = gcd(sr_in, sr_out)
    return signal.resample_poly(data, sr_out // g, sr_in // g, axis=0)


class Player:
    """Reproductor simple no bloqueante basado en sounddevice."""

    def __init__(self):
        self.start_time = None
        self.offset = 0.0
        self.duration = 0.0
        self.playing = False
        self._loop = False
        self._lock = threading.Lock()

    @property
    def available(self):
        return sd is not None

    def play(self, data: np.ndarray, sr: int, offset_s=0.0, loop: bool = False, volume: float = 1.0):
        if sd is None:
            raise RuntimeError("sounddevice no está instalado: no se puede reproducir audio.")
        self.stop()
        data = np.clip(np.asarray(data, dtype=np.float32) * volume, -1, 1)
        with self._lock:
            sd.play(data, sr, loop=loop)
            self.start_time = time.perf_counter()
            self.offset = offset_s
            self.duration = len(data) / sr
            self.playing = True
            self._loop = loop

    def stop(self):
        if sd is not None:
            try:
                sd.stop()
            except Exception:
                pass
        self.playing = False

    def position(self):
        """Posición actual (s) relativa al inicio del buffer completo, o None si terminó."""
        if not self.playing or self.start_time is None:
            return None
        el = time.perf_counter() - self.start_time
        if self._loop and self.duration > 0:
            el = el % self.duration
        elif el > self.duration:
            self.playing = False
            return None
        return (self.offset or 0.0) + el
