"""Widgets reutilizables: scroll, tooltips, secciones plegables, panel de parámetros autogenerado,
banco de osciladores, gráfico ADSR, teclado de piano y tarjeta informativa."""
from __future__ import annotations

import copy
import math
import tkinter as tk
from tkinter import ttk, filedialog

import numpy as np

from dsp.core import Param, OSC_SHAPES, SHAPE_INFO, OSC_DEFAULT, MAX_OSCILLATORS, coerce_oscillators
from gui.theme import COLORS, PALETTE, FONT


# ===========================================================================
class ToolTip:
    def __init__(self, widget, text: str, delay=450):
        self.widget, self.text, self.tip, self.delay, self._job = widget, text, None, delay, None
        widget.bind("<Enter>", self._schedule, add="+")
        widget.bind("<Leave>", self.hide, add="+")
        widget.bind("<ButtonPress>", self.hide, add="+")

    def _schedule(self, _=None):
        if self.text:
            self._job = self.widget.after(self.delay, self.show)

    def show(self):
        if self.tip or not self.text:
            return
        try:
            x = self.widget.winfo_rootx() + 16
            y = self.widget.winfo_rooty() + self.widget.winfo_height() + 4
        except tk.TclError:
            return
        self.tip = tw = tk.Toplevel(self.widget)
        tw.wm_overrideredirect(True)
        tw.wm_geometry(f"+{x}+{y}")
        tk.Label(tw, text=self.text, justify="left", background=COLORS["tip_bg"], foreground=COLORS["fg"],
                 relief="solid", borderwidth=1, wraplength=360, padx=8, pady=5, font=(FONT, 9)).pack()

    def hide(self, _=None):
        if self._job:
            try:
                self.widget.after_cancel(self._job)
            except tk.TclError:
                pass
            self._job = None
        if self.tip:
            self.tip.destroy()
            self.tip = None


# ===========================================================================
class ScrollableFrame(ttk.Frame):
    """Marco con barra de desplazamiento; la rueda del ratón desplaza el panel bajo el puntero."""
    _instances: list = []
    _installed = False

    def __init__(self, master, bg=None, **kw):
        super().__init__(master, style="Panel.TFrame", **kw)
        self.canvas = tk.Canvas(self, highlightthickness=0, background=bg or COLORS["panel"], borderwidth=0)
        self.vsb = ttk.Scrollbar(self, orient="vertical", command=self.canvas.yview)
        self.inner = ttk.Frame(self.canvas, style="Panel.TFrame")
        self._win = self.canvas.create_window((0, 0), window=self.inner, anchor="nw")
        self.canvas.configure(yscrollcommand=self.vsb.set)
        self.canvas.pack(side="left", fill="both", expand=True)
        self.vsb.pack(side="right", fill="y")
        self.inner.bind("<Configure>", lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.canvas.bind("<Configure>", lambda e: self.canvas.itemconfigure(self._win, width=e.width))
        ScrollableFrame._instances.append(self)
        if not ScrollableFrame._installed:
            root = self.winfo_toplevel()
            root.bind_all("<MouseWheel>", ScrollableFrame._on_wheel, add="+")
            root.bind_all("<Button-4>", lambda e: ScrollableFrame._on_wheel(e, -120), add="+")
            root.bind_all("<Button-5>", lambda e: ScrollableFrame._on_wheel(e, 120), add="+")
            ScrollableFrame._installed = True

    @staticmethod
    def _on_wheel(e, delta=None):
        try:
            w = e.widget.winfo_containing(e.x_root, e.y_root)
        except (tk.TclError, AttributeError):
            return
        d = delta if delta is not None else -e.delta
        while w is not None:
            if isinstance(w, (ttk.Scale, ttk.Combobox, ttk.Spinbox)):
                return
            for sf in ScrollableFrame._instances:
                if w is sf.canvas:
                    top, bot = sf.canvas.yview()
                    if top <= 0 and bot >= 1:
                        return
                    sf.canvas.yview_scroll(int(np.sign(d)) * 3, "units")
                    return
            w = getattr(w, "master", None)

    def scroll_top(self):
        self.canvas.yview_moveto(0)


# ===========================================================================
def _fmt(v: float) -> str:
    a = abs(v)
    if a == 0:
        return "0"
    if a >= 1000:
        return f"{v:.0f}"
    if a >= 100:
        return f"{v:.1f}"
    if a >= 1:
        return f"{v:.2f}"
    return f"{v:.3f}"


class FloatControl:
    """Deslizador + campo numérico (escala lineal o logarítmica). Rueda del ratón = ajuste fino,
    doble clic = valor por defecto, se pueden escribir valores fuera de rango."""
    RES = 1000

    def __init__(self, parent, p: Param, value, on_change, card=False, entry_width=7):
        self.p, self.on_change = p, on_change
        self.var = tk.StringVar(value=_fmt(float(value)))
        self.svar = tk.DoubleVar(value=self._to_slider(float(value)))
        self.frame = ttk.Frame(parent, style="Card.TFrame" if card else "Panel.TFrame")
        if card:
            self.frame.configure(borderwidth=0, relief="flat")
        self.scale = ttk.Scale(self.frame, from_=0, to=self.RES, variable=self.svar, command=self._slid)
        self.entry = ttk.Entry(self.frame, textvariable=self.var, width=entry_width, justify="right")
        self.scale.pack(side="left", fill="x", expand=True)
        self.entry.pack(side="left", padx=(6, 0))
        if p.unit:
            ttk.Label(self.frame, text=p.unit, width=5, style="CardUnit.TLabel" if card else "Unit.TLabel").pack(
                side="left", padx=(3, 0))
        self.entry.bind("<Return>", self._typed)
        self.entry.bind("<FocusOut>", self._typed)
        self.scale.bind("<Double-Button-1>", lambda e: self.set(p.default, notify=True))
        self.scale.bind("<MouseWheel>", lambda e: self._wheel(e.delta))
        self.scale.bind("<Button-4>", lambda e: self._wheel(120))
        self.scale.bind("<Button-5>", lambda e: self._wheel(-120))

    def _wheel(self, delta):
        s = self.svar.get() + (10 if delta > 0 else -10)
        s = min(max(s, 0), self.RES)
        self.svar.set(s)
        self._slid(s)
        return "break"

    def _use_log(self):
        return self.p.log and self.p.min > 0

    def _to_slider(self, v):
        lo, hi = self.p.min, self.p.max
        v = min(max(v, lo), hi)
        if self._use_log():
            return self.RES * math.log(v / lo) / math.log(hi / lo)
        return self.RES * (v - lo) / ((hi - lo) or 1)

    def _from_slider(self, s):
        lo, hi = self.p.min, self.p.max
        s = float(s) / self.RES
        if self._use_log():
            return lo * (hi / lo) ** s
        return lo + s * (hi - lo)

    def _slid(self, s):
        self.var.set(_fmt(self._from_slider(s)))
        self.on_change()

    def _typed(self, _=None):
        try:
            v = float(self.var.get().replace(",", "."))
        except ValueError:
            v = self.p.default
        self.var.set(_fmt(v))
        self.svar.set(self._to_slider(v))
        self.on_change()

    def get(self):
        try:
            return float(self.var.get().replace(",", "."))
        except ValueError:
            return float(self.p.default)

    def set(self, v, notify=False):
        self.var.set(_fmt(float(v)))
        self.svar.set(self._to_slider(float(v)))
        if notify:
            self.on_change()


# ===========================================================================
class Section(ttk.Frame):
    """Sección plegable con cabecera clicable."""

    def __init__(self, master, title, open_=True, color=None):
        super().__init__(master, style="Panel.TFrame")
        self.title = title
        self.is_open = open_
        self.header = tk.Frame(self, background=COLORS["panel2"], cursor="hand2")
        self.header.pack(fill="x", pady=(8, 0))
        tk.Frame(self.header, background=color or COLORS["accent"], width=4).pack(side="left", fill="y")
        self.arrow = tk.Label(self.header, text="▼" if open_ else "►", background=COLORS["panel2"],
                              foreground=COLORS["muted"], font=(FONT, 8), width=2)
        self.arrow.pack(side="left", padx=(6, 0))
        self.label = tk.Label(self.header, text=title, background=COLORS["panel2"], foreground=COLORS["fg"],
                              font=(FONT, 10, "bold"), anchor="w", pady=5)
        self.label.pack(side="left", fill="x", expand=True)
        self.right = tk.Frame(self.header, background=COLORS["panel2"])
        self.right.pack(side="right", padx=4)
        self.body = ttk.Frame(self, style="Panel.TFrame", padding=(6, 4, 2, 2))
        if open_:
            self.body.pack(fill="x")
        for w in (self.header, self.arrow, self.label):
            w.bind("<Button-1>", self.toggle)
            w.bind("<Enter>", lambda e: self._hover(True))
            w.bind("<Leave>", lambda e: self._hover(False))

    def _hover(self, on):
        bg = COLORS["hover"] if on else COLORS["panel2"]
        for w in (self.header, self.arrow, self.label, self.right):
            w.configure(background=bg)

    def toggle(self, _=None):
        self.is_open = not self.is_open
        if self.is_open:
            self.body.pack(fill="x")
        else:
            self.body.pack_forget()
        self.arrow.configure(text="▼" if self.is_open else "►")


# ===========================================================================
class ADSRGraph(tk.Canvas):
    """Dibujo de una envolvente ADSR."""

    def __init__(self, master, height=86, color=None):
        super().__init__(master, height=height, background="#0f1116", highlightthickness=1,
                         highlightbackground=COLORS["border"])
        self.color = color or COLORS["ok"]
        self.vals = (0.01, 0.2, 0.7, 0.3, 1.0)
        self.bind("<Configure>", lambda e: self.redraw())

    def update_values(self, a, d, s, r, curve=1.0):
        self.vals = (max(a, 0), max(d, 0), min(max(s, 0), 1), max(r, 0), curve or 1.0)
        self.redraw()

    def redraw(self):
        self.delete("all")
        W = max(self.winfo_width(), 100)
        H = max(self.winfo_height(), 40)
        a, d, s, r, cv = self.vals
        hold = max((a + d + r) * 0.35, 0.15)
        tot = a + d + hold + r
        pad = 8
        sx = (W - 2 * pad) / tot
        top, bot = 10, H - 16

        def Y(v):
            return bot - v * (bot - top)
        pts = []
        N = 24
        for i in range(N + 1):
            t = i / N
            pts.append((pad + t * a * sx, Y(t ** cv)))
        x0 = pad + a * sx
        for i in range(1, N + 1):
            t = i / N
            pts.append((x0 + t * d * sx, Y(1 - (1 - s) * (t ** (1 / cv) if cv != 1 else t))))
        x1 = x0 + d * sx
        x2 = x1 + hold * sx
        pts.append((x2, Y(s)))
        for i in range(1, N + 1):
            t = i / N
            pts.append((x2 + t * r * sx, Y(s * (1 - t) ** cv)))
        poly = [(pad, bot)] + pts + [(pts[-1][0], bot)]
        self.create_polygon(*[c for p in poly for c in p], fill="#1b3a33", outline="")
        self.create_line(*[c for p in pts for c in p], fill=self.color, width=2, smooth=False)
        for x in (x0, x1, x2):
            self.create_line(x, top, x, bot, fill=COLORS["border"], dash=(2, 3))
        f = (FONT, 7)
        for lbl, xa, xb in (("A", pad, x0), ("D", x0, x1), ("S", x1, x2), ("R", x2, pts[-1][0])):
            self.create_text((xa + xb) / 2, H - 7, text=lbl, fill=COLORS["muted"], font=f)
        self.create_text(W - 6, 6, anchor="ne", text=f"total ≈ {a + d + r:.2f} s + sostenido",
                         fill=COLORS["dim"], font=f)


# ===========================================================================
def draw_wave_thumb(canvas: tk.Canvas, shape: str, pw=0.5, color=None, muted=False):
    canvas.delete("all")
    W = int(canvas.cget("width"))
    H = int(canvas.cget("height"))
    t = np.linspace(0, 2, 120, endpoint=False) % 1.0
    if shape == "seno":
        y = np.sin(2 * np.pi * t)
    elif shape == "triangular":
        y = 1 - 4 * np.abs(t - 0.5)
    elif shape == "sierra":
        y = 2 * t - 1
    elif shape == "cuadrada":
        y = np.where(t < 0.5, 1.0, -1.0)
    elif shape == "pulso":
        y = np.where(t < pw, 1.0, -1.0)
    else:
        rng = np.random.default_rng(1 if shape == "ruido blanco" else 2)
        y = rng.uniform(-1, 1, 120)
        if shape == "ruido rosa":
            y = np.convolve(y, np.ones(4) / 2, mode="same")
    xs = np.linspace(3, W - 3, len(y))
    ys = H / 2 - y * (H / 2 - 4)
    col = COLORS["dim"] if muted else (color or COLORS["accent"])
    canvas.create_line(3, H / 2, W - 3, H / 2, fill=COLORS["border"])
    canvas.create_line(*np.column_stack([xs, ys]).ravel().tolist(), fill=col, width=1.6)


class OscCard(ttk.Frame):
    """Tarjeta de un oscilador."""

    def __init__(self, bank, index, values):
        super().__init__(bank.list_frame, style="Card.TFrame", padding=(0, 0, 6, 6))
        self.bank = bank
        self.values = dict(values)
        color = PALETTE[index % len(PALETTE)]
        self.color = color
        tk.Frame(self, background=color, width=4).grid(row=0, column=0, rowspan=6, sticky="ns", padx=(0, 8))
        # cabecera
        head = ttk.Frame(self, style="Card.TFrame")
        head.configure(borderwidth=0, relief="flat")
        head.grid(row=0, column=1, columnspan=2, sticky="ew", pady=(6, 4))
        self.title = ttk.Label(head, text=f"Oscilador {index + 1}", style="CardTitle.TLabel")
        self.title.pack(side="left")
        self.thumb = tk.Canvas(head, width=70, height=26, background="#0f1116", highlightthickness=0)
        self.thumb.pack(side="left", padx=8)
        self.shape = tk.StringVar(value=self.values["shape"])
        cb = ttk.Combobox(head, textvariable=self.shape, values=OSC_SHAPES, state="readonly", width=11)
        cb.pack(side="left")
        cb.bind("<<ComboboxSelected>>", lambda e: self._changed(redraw=True))
        self.shape_tip = ToolTip(cb, SHAPE_INFO.get(self.values["shape"], ""))
        b = ttk.Button(head, text="Quitar", style="Danger.TButton", command=lambda: bank.remove(self))
        b.pack(side="right")
        ToolTip(b, "Eliminar este oscilador")
        b = ttk.Button(head, text="Duplicar", style="CardSmall.TButton", command=lambda: bank.duplicate(self))
        b.pack(side="right", padx=2)
        self.active = tk.BooleanVar(value=not self.values["mute"])
        c = ttk.Checkbutton(head, text="Activo", variable=self.active, style="Card.TCheckbutton",
                            command=lambda: self._changed(redraw=True))
        c.pack(side="right", padx=4)
        ToolTip(c, "Desmarca para silenciarlo sin borrarlo")

        self.info = ttk.Label(self, text=SHAPE_INFO.get(self.values["shape"], ""), style="CardMuted.TLabel",
                              wraplength=400, justify="left")
        self.info.grid(row=1, column=1, columnspan=2, sticky="w", pady=(0, 4))

        self.ctrls = {}
        grid = ttk.Frame(self, style="Card.TFrame")
        grid.configure(borderwidth=0, relief="flat")
        grid.grid(row=2, column=1, columnspan=2, sticky="ew")
        grid.columnconfigure(1, weight=1)
        grid.columnconfigure(3, weight=1)
        self.columnconfigure(1, weight=1)

        def slider(r, col, key, label, lo, hi, log=False, unit="", tip=""):
            lab = ttk.Label(grid, text=label, style="CardMuted.TLabel")
            lab.grid(row=r, column=col, sticky="w", padx=(0, 4), pady=1)
            if tip:
                ToolTip(lab, tip)
            fc = FloatControl(grid, Param(key, label, "float", OSC_DEFAULT[key], lo, hi, log=log, unit=unit),
                              self.values[key], self._changed, card=True, entry_width=5)
            fc.frame.grid(row=r, column=col + 1, sticky="ew", padx=(0, 10), pady=1)
            self.ctrls[key] = fc

        def spin(r, col, key, label, lo, hi, tip=""):
            lab = ttk.Label(grid, text=label, style="CardMuted.TLabel")
            lab.grid(row=r, column=col, sticky="w", padx=(0, 4), pady=1)
            if tip:
                ToolTip(lab, tip)
            var = tk.StringVar(value=str(int(self.values[key])))
            sp = ttk.Spinbox(grid, from_=lo, to=hi, textvariable=var, width=5, command=self._changed)
            sp.bind("<Return>", lambda e: self._changed())
            sp.bind("<FocusOut>", lambda e: self._changed())
            sp.grid(row=r, column=col + 1, sticky="w", pady=1)
            self.ctrls[key] = var

        slider(0, 0, "level", "Nivel", 0.0, 1.0, tip="Volumen de este oscilador en la mezcla")
        slider(0, 2, "pan", "Paneo", -1.0, 1.0, tip="-1 izquierda · 0 centro · 1 derecha")
        spin(1, 0, "octave", "Octava", -4, 4, tip="Desplazamiento en octavas (-1 = sub-oscilador)")
        spin(1, 2, "semi", "Semitonos", -24, 24, tip="7 = quinta, 12 = octava, 4 = tercera mayor")
        slider(2, 0, "cents", "Afinación fina", -100.0, 100.0, unit="ct",
               tip="Pequeñas desafinaciones (5–15 cents) entre osciladores engordan el sonido")
        slider(2, 2, "pw", "Ancho pulso", 0.05, 0.95, tip="Solo para la forma 'pulso'")
        spin(3, 0, "voices", "Voces unísono", 1, 9, tip="Copias desafinadas del oscilador (supersierra)")
        slider(3, 2, "spread", "Desafinación", 0.0, 100.0, unit="ct", tip="Separación entre las voces de unísono")
        slider(4, 2, "width", "Apertura estéreo", 0.0, 1.0, tip="Reparte las voces de unísono entre izquierda y derecha")
        self._redraw()

    def _changed(self, redraw=False):
        sh = self.shape.get()
        self.info.configure(text=SHAPE_INFO.get(sh, ""))
        self.shape_tip.text = SHAPE_INFO.get(sh, "")
        self._redraw()
        self.bank.changed()

    def _redraw(self):
        v = self.get()
        draw_wave_thumb(self.thumb, v["shape"], v["pw"], self.color, muted=v["mute"])

    def set_index(self, i):
        self.title.configure(text=f"Oscilador {i + 1}")

    def get(self):
        d = dict(OSC_DEFAULT)
        d["shape"] = self.shape.get()
        d["mute"] = not self.active.get()
        for k, c in self.ctrls.items():
            if isinstance(c, FloatControl):
                d[k] = c.get()
            else:
                try:
                    d[k] = int(float(c.get()))
                except ValueError:
                    d[k] = OSC_DEFAULT[k]
        return d


class OscillatorBank(ttk.Frame):
    """Lista editable de osciladores (añadir / duplicar / quitar)."""

    def __init__(self, master, values, on_change):
        super().__init__(master, style="Panel.TFrame")
        self.on_change = on_change
        self.cards: list[OscCard] = []
        top = ttk.Frame(self, style="Panel.TFrame")
        top.pack(fill="x", pady=(0, 4))
        self.count = ttk.Label(top, text="", style="Hint.TLabel")
        self.count.pack(side="left")
        self.list_frame = ttk.Frame(self, style="Panel.TFrame")
        self.list_frame.pack(fill="x")
        self.add_btn = ttk.Button(self, text="+  Añadir oscilador", style="Dashed.TButton", command=self.add)
        self.add_btn.pack(fill="x", pady=(4, 2))
        ToolTip(self.add_btn, f"Hasta {MAX_OSCILLATORS} osciladores. Cada uno se suma a la mezcla antes del filtro.")
        self.set(values)

    def _relayout(self):
        for i, c in enumerate(self.cards):
            c.pack_forget()
        for i, c in enumerate(self.cards):
            c.set_index(i)
            c.pack(fill="x", pady=(0, 6))
        n = len(self.cards)
        self.count.configure(text=f"{n} oscilador{'es' if n != 1 else ''} · se mezclan y pasan por el filtro")
        self.add_btn.state(["disabled"] if n >= MAX_OSCILLATORS else ["!disabled"])

    def set(self, values):
        for c in self.cards:
            c.destroy()
        self.cards = [OscCard(self, i, v) for i, v in enumerate(coerce_oscillators(values))]
        self._relayout()

    def get(self):
        return [c.get() for c in self.cards]

    def add(self, values=None):
        if len(self.cards) >= MAX_OSCILLATORS:
            return
        if values is None:
            values = dict(OSC_DEFAULT, level=0.6, cents=float(len(self.cards) * 5 % 20))
        self.cards.append(OscCard(self, len(self.cards), values))
        self._relayout()
        self.changed()

    def duplicate(self, card):
        if len(self.cards) >= MAX_OSCILLATORS:
            return
        v = card.get()
        v["cents"] = v["cents"] + 7.0
        i = self.cards.index(card)
        new = OscCard(self, i + 1, v)
        self.cards.insert(i + 1, new)
        self._relayout()
        self.changed()

    def remove(self, card):
        if len(self.cards) <= 1:
            return  # al menos uno
        self.cards.remove(card)
        card.destroy()
        self._relayout()
        self.changed()

    def changed(self):
        self.on_change()


# ===========================================================================
class ParamPanel(ttk.Frame):
    """Genera controles a partir de una lista de Param, agrupados en secciones plegables."""

    def __init__(self, master, on_change=None, graphs=None, **kw):
        super().__init__(master, style="Panel.TFrame", **kw)
        self.on_change_cb = on_change
        self.controls = {}
        self.params: list[Param] = []
        self.sections: dict[str, Section] = {}
        self.graphs_spec = graphs or {}
        self.graphs = {}
        self._pending = None

    def _changed(self):
        self._update_graphs()
        if self.on_change_cb is None:
            return
        if self._pending:
            self.after_cancel(self._pending)
        self._pending = self.after(150, self._fire)

    def _fire(self):
        self._pending = None
        self.on_change_cb(self.get_values())

    def _update_graphs(self):
        if not self.graphs:
            return
        vals = self.get_values()
        for g, (graph, keys) in self.graphs.items():
            a, d, s, r, cv = [vals.get(k, 1.0) if k else 1.0 for k in keys]
            graph.update_values(a, d, s, r, cv)

    def build(self, params: list[Param], values: dict | None = None, collapsed=()):
        for w in self.winfo_children():
            w.destroy()
        self.controls.clear()
        self.sections.clear()
        self.graphs.clear()
        self.params = params
        values = values or {}
        group = None
        grid = None
        row = 0
        sec_i = 0
        for p in params:
            gname = p.group or "Parámetros"
            if gname != group:
                group = gname
                sec = Section(self, gname, open_=gname not in collapsed, color=PALETTE[sec_i % len(PALETTE)])
                sec_i += 1
                sec.pack(fill="x")
                self.sections[gname] = sec
                if gname in self.graphs_spec:
                    graph = ADSRGraph(sec.body)
                    graph.pack(fill="x", pady=(2, 6))
                    self.graphs[gname] = (graph, self.graphs_spec[gname])
                grid = ttk.Frame(sec.body, style="Panel.TFrame")
                grid.pack(fill="x")
                grid.columnconfigure(1, weight=1)
                row = 0
            v = values.get(p.key, p.default)
            if p.kind == "oscillators":
                bank = OscillatorBank(grid, v, self._changed)
                bank.grid(row=row, column=0, columnspan=2, sticky="ew")
                self.controls[p.key] = ("osc", bank)
                row += 1
                continue
            lab = ttk.Label(grid, text=p.label, style="Panel.TLabel")
            lab.grid(row=row, column=0, sticky="w", padx=(2, 10), pady=3)
            if p.help:
                ToolTip(lab, p.help)
            if p.kind == "float":
                c = FloatControl(grid, p, v, self._changed)
                c.frame.grid(row=row, column=1, sticky="ew", pady=3)
                self.controls[p.key] = ("float", c)
                if p.help:
                    ToolTip(c.scale, p.help)
            elif p.kind == "int":
                var = tk.StringVar(value=str(int(v)))
                sp = ttk.Spinbox(grid, from_=p.min, to=p.max, textvariable=var, width=8, command=self._changed)
                sp.bind("<Return>", lambda e: self._changed())
                sp.bind("<FocusOut>", lambda e: self._changed())
                sp.grid(row=row, column=1, sticky="w", pady=3)
                self.controls[p.key] = ("int", var)
            elif p.kind == "choice":
                var = tk.StringVar(value=v)
                cb = ttk.Combobox(grid, textvariable=var, values=p.choices, state="readonly")
                cb.bind("<<ComboboxSelected>>", lambda e: self._changed())
                cb.grid(row=row, column=1, sticky="ew", pady=3)
                self.controls[p.key] = ("choice", var)
            elif p.kind == "bool":
                var = tk.BooleanVar(value=bool(v))
                ttk.Checkbutton(grid, variable=var, command=self._changed, style="Panel.TCheckbutton").grid(
                    row=row, column=1, sticky="w", pady=3)
                self.controls[p.key] = ("bool", var)
            elif p.kind == "file":
                var = tk.StringVar(value=v)
                fr = ttk.Frame(grid, style="Panel.TFrame")
                ttk.Entry(fr, textvariable=var).pack(side="left", fill="x", expand=True)

                def browse(var=var):
                    f = filedialog.askopenfilename(filetypes=[("Audio", "*.wav *.flac *.ogg *.aif *.aiff"),
                                                              ("Todos", "*.*")])
                    if f:
                        var.set(f)
                        self._changed()
                ttk.Button(fr, text="Buscar…", style="Small.TButton", command=browse).pack(side="left", padx=(4, 0))
                fr.grid(row=row, column=1, sticky="ew", pady=3)
                self.controls[p.key] = ("text", var)
            else:
                var = tk.StringVar(value=v)
                e = ttk.Entry(grid, textvariable=var)
                e.bind("<Return>", lambda ev: self._changed())
                e.bind("<FocusOut>", lambda ev: self._changed())
                e.grid(row=row, column=1, sticky="ew", pady=3)
                if p.help:
                    ToolTip(e, p.help)
                    row += 1
                    ttk.Label(grid, text=p.help, style="Hint.TLabel", wraplength=380, justify="left").grid(
                        row=row, column=0, columnspan=2, sticky="w", padx=2, pady=(0, 4))
                self.controls[p.key] = ("text", var)
            row += 1
        self.after_idle(self._update_graphs)

    def entry_var(self, key):
        kind, c = self.controls.get(key, (None, None))
        return c if kind == "text" else None

    def get_values(self) -> dict:
        out = {}
        for k, (kind, c) in self.controls.items():
            if kind in ("float", "osc"):
                out[k] = c.get()
            elif kind == "int":
                try:
                    out[k] = int(float(c.get()))
                except ValueError:
                    out[k] = 0
            else:
                out[k] = c.get()
        return out

    def set_values(self, values: dict):
        for k, v in values.items():
            if k in self.controls:
                kind, c = self.controls[k]
                c.set(copy.deepcopy(v) if kind == "osc" else v)
        self._update_graphs()

    def reset(self):
        self.set_values({p.key: p.default for p in self.params})
        self._changed()


# ===========================================================================
NOTE_NAMES = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]
NOTE_ES = {"C": "Do", "D": "Re", "E": "Mi", "F": "Fa", "G": "Sol", "A": "La", "B": "Si"}
# teclado del ordenador -> semitono desde la nota base
KEYMAP = {"a": 0, "w": 1, "s": 2, "e": 3, "d": 4, "f": 5, "t": 6, "g": 7, "y": 8, "h": 9, "u": 10, "j": 11,
          "k": 12, "o": 13, "l": 14, "p": 15, "ñ": 16, "ntilde": 16, "semicolon": 16}


class Piano(tk.Canvas):
    """Teclado de piano clicable."""

    def __init__(self, master, on_note, octaves=2, base_octave=3, height=78):
        super().__init__(master, height=height, background=COLORS["bg"], highlightthickness=0)
        self.on_note, self.octaves, self.base = on_note, octaves, base_octave
        self.keys = []
        self.bind("<Configure>", lambda e: self.redraw())
        self.bind("<Button-1>", self._click)

    def set_base(self, octv):
        self.base = int(min(max(octv, 0), 7))
        self.redraw()

    def note_name(self, semis_from_base):
        midi_oct = self.base + semis_from_base // 12
        return f"{NOTE_NAMES[semis_from_base % 12]}{midi_oct}"

    def redraw(self):
        self.delete("all")
        self.keys = []
        W = max(self.winfo_width(), 200)
        H = max(self.winfo_height(), 40)
        nwhite = 7 * self.octaves + 1
        ww = W / nwhite
        white_semis = [0, 2, 4, 5, 7, 9, 11]
        wi = 0
        for o in range(self.octaves + 1):
            for s in white_semis:
                if o == self.octaves and s > 0:
                    break
                semi = o * 12 + s
                x0 = wi * ww
                tag = f"k{semi}"
                self.create_rectangle(x0 + 1, 0, x0 + ww - 1, H - 1, fill="#e9ecf2", outline="#9aa3b2", tags=(tag,))
                if s == 0:
                    self.create_text(x0 + ww / 2, H - 10, text=f"C{self.base + o}", fill="#5b6475",
                                     font=(FONT, 7), tags=(tag,))
                self.keys.append((semi, x0, x0 + ww, False))
                wi += 1
        wi = 0
        for o in range(self.octaves + 1):
            for s in white_semis:
                if o == self.octaves:
                    break
                if s in (0, 2, 5, 7, 9):
                    semi = o * 12 + s + 1
                    x = (wi + 1) * ww
                    bw = ww * 0.6
                    tag = f"k{semi}"
                    self.create_rectangle(x - bw / 2, 0, x + bw / 2, H * 0.6, fill="#1d2129", outline="#000",
                                          tags=(tag,))
                    self.keys.append((semi, x - bw / 2, x + bw / 2, True))
                wi += 1

    def _click(self, e):
        H = max(self.winfo_height(), 40)
        hit = None
        for semi, x0, x1, black in self.keys:
            if black and x0 <= e.x <= x1 and e.y <= H * 0.6:
                hit = semi
                break
        if hit is None:
            for semi, x0, x1, black in self.keys:
                if not black and x0 <= e.x <= x1:
                    hit = semi
                    break
        if hit is not None:
            self.press(hit)

    def press(self, semi):
        tag = f"k{semi}"
        items = self.find_withtag(tag)
        if items:
            rect = items[0]
            old = self.itemcget(rect, "fill")
            self.itemconfigure(rect, fill=COLORS["accent"])
            self.after(220, lambda: self.itemconfigure(rect, fill=old))
        self.on_note(self.note_name(semi))


# ===========================================================================
class InfoCard(ttk.Frame):
    """Tarjeta con título, etiquetas, descripción y consejo."""

    def __init__(self, master, wrap=420):
        super().__init__(master, style="Card.TFrame", padding=(10, 8))
        self.t = ttk.Label(self, style="InfoTitle.TLabel", wraplength=wrap, justify="left")
        self.tags = ttk.Label(self, style="InfoTags.TLabel", wraplength=wrap, justify="left")
        self.text = ttk.Label(self, style="InfoText.TLabel", wraplength=wrap, justify="left")
        self.tip = ttk.Label(self, style="InfoTip.TLabel", wraplength=wrap, justify="left")
        self.t.pack(anchor="w")
        self.tags.pack(anchor="w", pady=(2, 4))
        self.text.pack(anchor="w", fill="x")
        self.tip.pack(anchor="w", fill="x", pady=(4, 0))
        self.bind("<Configure>", self._rewrap)

    def _rewrap(self, e):
        w = max(e.width - 24, 200)
        for lab in (self.t, self.tags, self.text, self.tip):
            lab.configure(wraplength=w)

    def show(self, title="", tags="", text="", tip=""):
        for lab in (self.t, self.tags, self.text, self.tip):
            lab.pack_forget()
        self.t.configure(text=title)
        self.tags.configure(text=tags)
        self.text.configure(text=text)
        self.tip.configure(text=tip)
        if title:
            self.t.pack(anchor="w")
        if tags:
            self.tags.pack(anchor="w", pady=(2, 4))
        if text:
            self.text.pack(anchor="w", fill="x")
        if tip:
            self.tip.pack(anchor="w", fill="x", pady=(4, 0))
