"""
Estudio de Síntesis — ventana principal.
"""
from __future__ import annotations

import copy
import json
import os
import queue
import re
import subprocess
import sys
import threading
import time
import traceback
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, simpledialog

import numpy as np
import matplotlib
matplotlib.use("TkAgg")
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.widgets import SpanSelector
from scipy import signal

from audio_io import Player, load_audio, save_audio, resample, SAVE_FORMATS, LOAD_TYPES
from dsp.core import as_2d, mix_to_length, HAS_NUMBA
from dsp import kernels
from dsp.synths import SYNTHS, SYNTH_BY_NAME, COMMON_PARAMS, render_synth, G_ENV
from dsp.effects import ALL_PROCESSORS, PROCESSOR_BY_NAME, CATEGORIES, run_chain
from gui.theme import COLORS, PALETTE, FONT, MONO, apply_theme, mpl_style
from gui.widgets import (ParamPanel, ScrollableFrame, ToolTip, Piano, InfoCard, KEYMAP)

APP_NAME = "Estudio de Síntesis"
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PRESET_DIR = os.path.join(BASE_DIR, "presets")
SAMPLE_RATES = [22050, 32000, 44100, 48000, 88200, 96000]
MAX_UNDO = 40
CATEGORY_ORDER = ["Bajos", "Leads", "Pads", "Teclas", "Campanas y metales", "Cuerdas y percusión", "Voces",
                  "Texturas y atmósferas", "Mis sonidos", "Cadenas de efectos"]
USE_MODES = [("Reemplazar el audio del editor", "replace"), ("Añadir al final", "append"),
             ("Insertar en el cursor", "insert"), ("Mezclar desde el cursor", "mix")]


def fmt_time(s):
    s = max(s, 0.0)
    m = int(s // 60)
    return f"{m}:{s - 60 * m:06.3f}"


class App:
    def __init__(self, root: tk.Tk):
        self.root = root
        root.title(APP_NAME)
        root.geometry("1480x900")
        root.minsize(1150, 720)
        apply_theme(root)
        matplotlib.rcParams.update(mpl_style())

        # --- estado ---
        self.audio: np.ndarray | None = None
        self.sr = 44100
        self.path: str | None = None
        self.undo_stack: list = []
        self.redo_stack: list = []
        self.selection: tuple[int, int] | None = None
        self.cursor = 0
        self.clipboard: np.ndarray | None = None
        self.chain: list[dict] = []
        self.chain_sel: int | None = None
        self.player = Player()
        self.tasks: queue.Queue = queue.Queue()
        self.busy = False
        self._pending_jobs: list = []
        self.export_fmt = tk.StringVar(value="WAV 24 bits")
        self.loop_var = tk.BooleanVar(value=False)
        self.volume = tk.DoubleVar(value=0.8)
        self.analysis_view = tk.StringVar(value="Espectrograma")
        self.log_freq = tk.BooleanVar(value=True)
        self.scope = tk.StringVar(value="todo")
        self.auto_preview = tk.BooleanVar(value=False)
        self.write_notes = tk.BooleanVar(value=False)
        self.library: list[dict] = []
        self._wave_artists = []
        self._bg_cache = None
        self._last_key = (None, 0.0)

        self._build_menu()
        self._build_toolbar()
        self._build_body()
        self._build_status()
        self._bind_keys()

        self.synth_combo.set(SYNTHS[0].name)
        self._on_synth_changed()
        self._refresh_library()
        self._refresh_all()
        self._show_chain_empty()
        self.root.after(50, self._poll_tasks)
        self.root.after(40, self._tick)
        self._run_bg(kernels.warmup, lambda _: self._status("Listo." + ("  (acelerado con numba)" if HAS_NUMBA else "")),
                     "Preparando el motor de audio…" + (" (compilando con numba, solo la primera vez)" if HAS_NUMBA else ""))

    # =====================================================================
    # Menú y barra superior
    # =====================================================================
    def _build_menu(self):
        m = tk.Menu(self.root)
        fm = tk.Menu(m, tearoff=0)
        fm.add_command(label="Nuevo (silencio)…", command=self.new_silence, accelerator="Ctrl+N")
        fm.add_command(label="Abrir audio…", command=self.open_file, accelerator="Ctrl+O")
        fm.add_command(label="Insertar archivo en el cursor…", command=self.insert_file)
        fm.add_command(label="Mezclar archivo en el cursor…", command=lambda: self.insert_file(mix=True))
        fm.add_separator()
        fm.add_command(label="Guardar", command=self.save, accelerator="Ctrl+S")
        fm.add_command(label="Guardar como…", command=self.save_as, accelerator="Ctrl+Shift+S")
        fm.add_command(label="Exportar selección…", command=self.export_selection)
        fmt = tk.Menu(fm, tearoff=0)
        for k in SAVE_FORMATS:
            fmt.add_radiobutton(label=k, variable=self.export_fmt, value=k)
        fm.add_cascade(label="Formato de exportación", menu=fmt)
        fm.add_separator()
        fm.add_command(label="Salir", command=self.root.destroy)
        m.add_cascade(label="Archivo", menu=fm)

        em = tk.Menu(m, tearoff=0)
        em.add_command(label="Deshacer", command=self.undo, accelerator="Ctrl+Z")
        em.add_command(label="Rehacer", command=self.redo, accelerator="Ctrl+Y")
        em.add_separator()
        em.add_command(label="Seleccionar todo", command=self.select_all, accelerator="Ctrl+A")
        em.add_command(label="Quitar selección", command=self.clear_selection, accelerator="Esc")
        em.add_separator()
        em.add_command(label="Copiar", command=self.copy_sel, accelerator="Ctrl+C")
        em.add_command(label="Cortar", command=self.cut_sel, accelerator="Ctrl+X")
        em.add_command(label="Pegar en el cursor", command=self.paste, accelerator="Ctrl+V")
        em.add_command(label="Pegar mezclando", command=lambda: self.paste(mix=True))
        em.add_separator()
        em.add_command(label="Recortar a la selección", command=self.crop_to_sel)
        em.add_command(label="Borrar selección", command=self.delete_sel, accelerator="Supr")
        em.add_command(label="Silenciar selección", command=self.silence_sel)
        em.add_command(label="Insertar silencio en el cursor…", command=self.insert_silence)
        em.add_separator()
        em.add_command(label="Cambiar frecuencia de muestreo…", command=self.change_sr)
        m.add_cascade(label="Editar", menu=em)

        pm = tk.Menu(m, tearoff=0)
        pm.add_command(label="Guardar sonido actual como preset…", command=self.save_synth_preset)
        pm.add_command(label="Cargar preset desde archivo…", command=self.load_preset_file)
        pm.add_separator()
        pm.add_command(label="Guardar cadena de efectos…", command=self.save_chain)
        pm.add_separator()
        pm.add_command(label="Abrir carpeta de presets", command=self.open_preset_folder)
        m.add_cascade(label="Presets", menu=pm)

        hm = tk.Menu(m, tearoff=0)
        hm.add_command(label="Guía rápida", command=self.show_help, accelerator="F1")
        hm.add_command(label="Acerca de", command=lambda: messagebox.showinfo(
            APP_NAME, f"{APP_NAME}\nSíntesis, filtros y efectos en Python.\n"
                      f"numpy · scipy · matplotlib · sounddevice · soundfile"
                      f"{' · numba' if HAS_NUMBA else ''}"))
        m.add_cascade(label="Ayuda", menu=hm)
        self.root.config(menu=m)

    def _build_toolbar(self):
        tb = ttk.Frame(self.root, style="Toolbar.TFrame", padding=(10, 8, 10, 6))
        tb.pack(side="top", fill="x")

        ttk.Label(tb, text="◆ Estudio de Síntesis", style="Brand.TLabel").pack(side="left", padx=(0, 14))

        def btn(text, cmd, tip="", style="Tool.TButton", **kw):
            b = ttk.Button(tb, text=text, command=cmd, style=style, **kw)
            b.pack(side="left", padx=2)
            if tip:
                ToolTip(b, tip)
            return b

        btn("Abrir", self.open_file, "Abrir un archivo de audio (Ctrl+O)")
        btn("Guardar", self.save, "Guardar el audio del editor (Ctrl+S)")
        ttk.Separator(tb, orient="vertical").pack(side="left", fill="y", padx=8)
        btn("Deshacer", self.undo, "Deshacer (Ctrl+Z)")
        btn("Rehacer", self.redo, "Rehacer (Ctrl+Y)")
        ttk.Separator(tb, orient="vertical").pack(side="left", fill="y", padx=8)
        btn("▶  Reproducir", self.play_all, "Reproducir el audio del editor (o la selección) — Espacio", "Play.TButton")
        btn("■  Detener", self.stop, "Detener (Espacio / Esc)", "TButton")
        lb = ttk.Checkbutton(tb, text="Bucle", variable=self.loop_var, style="TbToggle.Toolbutton")
        lb.pack(side="left", padx=6)
        ToolTip(lb, "Repetir la reproducción continuamente")
        self.time_label = ttk.Label(tb, text="0:00.000", style="Time.TLabel")
        self.time_label.pack(side="left", padx=(14, 4))
        self.dur_label = ttk.Label(tb, text="/ 0:00.000", style="ToolbarMuted.TLabel")
        self.dur_label.pack(side="left")

        right = ttk.Frame(tb, style="Toolbar.TFrame")
        right.pack(side="right")
        self.progress = ttk.Progressbar(right, mode="indeterminate", length=110)
        self.progress.pack(side="right", padx=(10, 0))
        self.peak_label = ttk.Label(right, text="", style="Peak.TLabel")
        self.peak_label.pack(side="right", padx=10)
        ttk.Label(right, text="Hz", style="ToolbarMuted.TLabel").pack(side="right", padx=(2, 4))
        self.sr_combo = ttk.Combobox(right, values=[str(s) for s in SAMPLE_RATES], width=7, state="readonly")
        self.sr_combo.set(str(self.sr))
        self.sr_combo.bind("<<ComboboxSelected>>", self._on_sr_combo)
        self.sr_combo.pack(side="right")
        ToolTip(self.sr_combo, "Frecuencia de muestreo del proyecto")
        vs = ttk.Scale(right, from_=0, to=1, variable=self.volume, length=80)
        vs.pack(side="right", padx=(0, 10))
        ToolTip(vs, "Volumen de escucha (no modifica el audio)")
        ttk.Label(right, text="Vol.", style="ToolbarMuted.TLabel").pack(side="right", padx=(0, 4))

    def _build_body(self):
        pw = ttk.Panedwindow(self.root, orient="horizontal")
        pw.pack(side="top", fill="both", expand=True, padx=8, pady=(0, 4))
        left = ttk.Frame(pw, style="Panel.TFrame", width=520)
        right = ttk.Frame(pw, style="Bg.TFrame")
        pw.add(left, weight=0)
        pw.add(right, weight=1)
        self.nb = ttk.Notebook(left)
        self.nb.pack(fill="both", expand=True)
        self._build_library_tab()
        self._build_synth_tab()
        self._build_fx_tab()
        self._build_plots(right)

    def _use_menubutton(self, parent, callback, text="Usar en el editor", style="Warm.TMenubutton"):
        mb = ttk.Menubutton(parent, text=text, style=style, direction="above")
        menu = tk.Menu(mb, tearoff=0)
        for label, mode in USE_MODES:
            menu.add_command(label=label, command=lambda m=mode: callback(m))
        mb["menu"] = menu
        ToolTip(mb, "Lleva el sonido al editor de la derecha, donde puedes procesarlo, editarlo y guardarlo")
        return mb

    # ---------------- pestaña biblioteca ----------------
    def _build_library_tab(self):
        tab = ttk.Frame(self.nb, style="Panel.TFrame", padding=10)
        self.nb.add(tab, text="  Biblioteca  ")
        ttk.Label(tab, text="Biblioteca de sonidos", style="Title.TLabel").pack(anchor="w")
        ttk.Label(tab, text="Elige un sonido para empezar. Doble clic para escucharlo; luego ajústalo en «Síntesis».",
                  style="Muted.TLabel", wraplength=470, justify="left").pack(anchor="w", pady=(2, 8))
        sf = ttk.Frame(tab, style="Panel.TFrame")
        sf.pack(fill="x")
        ttk.Label(sf, text="Buscar", style="Muted.TLabel").pack(side="left", padx=(0, 6))
        self.search = tk.StringVar()
        e = ttk.Entry(sf, textvariable=self.search, style="Search.TEntry")
        e.pack(side="left", fill="x", expand=True)
        self.search.trace_add("write", lambda *a: self._fill_library_tree())
        ToolTip(e, "Filtra por nombre, categoría, método o descripción (p. ej. «campana», «pad», «FM»)")

        tf = ttk.Frame(tab, style="Panel.TFrame")
        tf.pack(fill="both", expand=True, pady=(8, 8))
        self.lib_tree = ttk.Treeview(tf, show="tree", selectmode="browse")
        vsb = ttk.Scrollbar(tf, orient="vertical", command=self.lib_tree.yview)
        self.lib_tree.configure(yscrollcommand=vsb.set)
        self.lib_tree.pack(side="left", fill="both", expand=True)
        vsb.pack(side="right", fill="y")
        self.lib_tree.tag_configure("cat", font=(FONT, 10, "bold"), foreground=COLORS["accent"])
        self.lib_tree.tag_configure("chain", foreground=COLORS["accent2"])
        self.lib_tree.bind("<<TreeviewSelect>>", lambda e: self._on_lib_select())
        self.lib_tree.bind("<Double-1>", lambda e: self.lib_listen())
        self.lib_tree.bind("<Return>", lambda e: self.lib_listen())

        self.lib_info = InfoCard(tab)
        self.lib_info.pack(fill="x")
        self.lib_info.show("Selecciona un sonido", "", "Aquí verás qué puedes esperar de cada sonido.")

        bar = ttk.Frame(tab, style="Panel.TFrame")
        bar.pack(fill="x", pady=(8, 0))
        self.lib_listen_btn = ttk.Button(bar, text="▶  Escuchar", style="Accent.TButton", command=self.lib_listen)
        self.lib_listen_btn.pack(side="left")
        self.lib_edit_btn = ttk.Button(bar, text="Editar en Síntesis", command=self.lib_edit)
        self.lib_edit_btn.pack(side="left", padx=6)
        self.lib_use_btn = self._use_menubutton(bar, self.lib_use)
        self.lib_use_btn.pack(side="left")
        bar2 = ttk.Frame(tab, style="Panel.TFrame")
        bar2.pack(fill="x", pady=(6, 0))
        ttk.Button(bar2, text="Guardar sonido actual…", style="Small.TButton",
                   command=self.save_synth_preset).pack(side="left")
        ttk.Button(bar2, text="Abrir carpeta de presets", style="Small.TButton",
                   command=self.open_preset_folder).pack(side="left", padx=6)
        ttk.Button(bar2, text="Actualizar", style="Small.TButton",
                   command=self._refresh_library).pack(side="right")

    # ---------------- pestaña síntesis ----------------
    def _build_synth_tab(self):
        tab = ttk.Frame(self.nb, style="Panel.TFrame", padding=(10, 10, 4, 8))
        self.nb.add(tab, text="  Síntesis  ")
        top = ttk.Frame(tab, style="Panel.TFrame")
        top.pack(fill="x", padx=(0, 6))
        ttk.Label(top, text="Método de síntesis", style="Muted.TLabel").pack(anchor="w")
        self.synth_combo = ttk.Combobox(top, values=[s.name for s in SYNTHS], state="readonly",
                                        font=(FONT, 11, "bold"))
        self.synth_combo.pack(fill="x", pady=(2, 6))
        self.synth_combo.bind("<<ComboboxSelected>>", lambda e: self._on_synth_changed())

        # zona con scroll: información + parámetros del método + parámetros comunes
        self.synth_scroll = ScrollableFrame(tab)
        self.synth_scroll.pack(fill="both", expand=True)
        inner = self.synth_scroll.inner
        self.synth_info = InfoCard(inner)
        self.synth_info.pack(fill="x", padx=(0, 8), pady=(0, 2))
        self.synth_panel = ParamPanel(inner, on_change=self._on_synth_params,
                                      graphs={"Envolvente de filtro": ("f_a", "f_d", "f_s", "f_r", None)})
        self.synth_panel.pack(fill="x", padx=(0, 8))
        self.common_panel = ParamPanel(inner, on_change=self._on_synth_params,
                                       graphs={G_ENV: ("a", "d", "s", "r", "curve")})
        self.common_panel.pack(fill="x", padx=(0, 8), pady=(0, 8))
        self.common_panel.build(COMMON_PARAMS, collapsed=("Tono y vibrato", "Unísono y estéreo (global)"))

        # piano
        pf = ttk.Frame(tab, style="Panel.TFrame")
        pf.pack(fill="x", pady=(8, 0), padx=(0, 6))
        row = ttk.Frame(pf, style="Panel.TFrame")
        row.pack(fill="x", pady=(0, 3))
        ttk.Label(row, text="Teclado", style="Subtitle.TLabel").pack(side="left")
        ttk.Button(row, text="◄ Oct", style="Small.TButton", command=lambda: self._octave(-1)).pack(side="left", padx=(10, 2))
        self.oct_label = ttk.Label(row, text="", style="Muted.TLabel", width=9, anchor="center")
        self.oct_label.pack(side="left")
        ttk.Button(row, text="Oct ►", style="Small.TButton", command=lambda: self._octave(1)).pack(side="left", padx=2)
        c = ttk.Checkbutton(row, text="Escribir en «Notas»", variable=self.write_notes, style="Toggle.Toolbutton")
        c.pack(side="right")
        ToolTip(c, "Activado: cada tecla que toques se añade a la secuencia de notas")
        self.piano = Piano(pf, self._piano_note, octaves=2, base_octave=3, height=70)
        self.piano.pack(fill="x")
        ttk.Label(pf, text="Clic en las teclas o usa el teclado del ordenador: A W S E D F T G Y H U J K · Z / X cambian de octava",
                  style="Hint.TLabel").pack(anchor="w", pady=(2, 0))
        self._octave(0)

        bar = ttk.Frame(tab, style="Panel.TFrame")
        bar.pack(fill="x", pady=(8, 0), padx=(0, 6))
        b = ttk.Button(bar, text="▶  Escuchar", style="Accent.TButton", command=self.synth_preview)
        b.pack(side="left")
        ToolTip(b, "Genera la secuencia de «Notas» y la reproduce, sin tocar el editor")
        t = ttk.Checkbutton(bar, text="Escucha automática", variable=self.auto_preview, style="Toggle.Toolbutton")
        t.pack(side="left", padx=6)
        ToolTip(t, "Vuelve a sonar cada vez que cambias un parámetro: ideal para diseñar el sonido de oído")
        self._use_menubutton(bar, self.synth_commit).pack(side="left")
        b = ttk.Button(bar, text="Restablecer", style="Small.TButton", command=self._reset_synth)
        b.pack(side="right")
        ToolTip(b, "Vuelve a los valores por defecto del método")

    # ---------------- pestaña efectos ----------------
    def _build_fx_tab(self):
        tab = ttk.Frame(self.nb, style="Panel.TFrame", padding=(10, 10, 4, 8))
        self.nb.add(tab, text="  Efectos  ")
        ttk.Label(tab, text="Cadena de filtros y efectos", style="Title.TLabel").pack(anchor="w")
        ttk.Label(tab, text="El audio del editor pasa por los efectos de arriba hacia abajo.",
                  style="Muted.TLabel").pack(anchor="w", pady=(2, 8))
        add = ttk.Frame(tab, style="Panel.TFrame")
        add.pack(fill="x", padx=(0, 6))
        mb = ttk.Menubutton(add, text="+  Añadir efecto", style="Accent.TMenubutton")
        menu = tk.Menu(mb, tearoff=0)
        for cat in CATEGORIES:
            sub = tk.Menu(menu, tearoff=0)
            for p in ALL_PROCESSORS:
                if p.category == cat:
                    sub.add_command(label=p.name, command=lambda n=p.name: self.chain_add(n))
            menu.add_cascade(label=cat, menu=sub)
        mb["menu"] = menu
        mb.pack(side="left")
        ToolTip(mb, "Elige una categoría y un efecto; se añade al final de la cadena")
        self.chain_menu_btn = ttk.Menubutton(add, text="Cadenas guardadas")
        self.chain_menu = tk.Menu(self.chain_menu_btn, tearoff=0)
        self.chain_menu_btn["menu"] = self.chain_menu
        self.chain_menu_btn.pack(side="left", padx=6)

        chain_box = ttk.Frame(tab, style="Panel.TFrame")
        chain_box.pack(fill="x", pady=(8, 0), padx=(0, 6))
        self.tree = ttk.Treeview(chain_box, columns=("on", "name"), show="headings", height=5, selectmode="browse")
        self.tree.heading("on", text="")
        self.tree.heading("name", text="Efecto")
        self.tree.column("on", width=34, anchor="center", stretch=False)
        self.tree.column("name", width=300)
        self.tree.tag_configure("off", foreground=COLORS["dim"])
        self.tree.pack(side="left", fill="x", expand=True)
        self.tree.bind("<<TreeviewSelect>>", lambda e: self._on_chain_select())
        self.tree.bind("<Double-1>", lambda e: self.chain_toggle())
        self.tree.bind("<Delete>", lambda e: self.chain_remove())
        side = ttk.Frame(chain_box, style="Panel.TFrame")
        side.pack(side="left", fill="y", padx=(6, 0))
        for t, c, tip in (("▲ Subir", lambda: self.chain_move(-1), "Mover arriba (se procesa antes)"),
                          ("▼ Bajar", lambda: self.chain_move(1), "Mover abajo (se procesa después)"),
                          ("On / Off", self.chain_toggle, "Activar o desactivar sin borrarlo (bypass)"),
                          ("Duplicar", self.chain_duplicate, "Duplicar con los mismos ajustes"),
                          ("Quitar", self.chain_remove, "Quitar de la cadena")):
            b = ttk.Button(side, text=t, width=9, style="Small.TButton", command=c)
            b.pack(pady=1, fill="x")
            ToolTip(b, tip)

        self.fx_scroll = ScrollableFrame(tab)
        self.fx_scroll.pack(fill="both", expand=True, pady=(8, 0))
        self.fx_info = InfoCard(self.fx_scroll.inner)
        self.fx_info.pack(fill="x", padx=(0, 8))
        self.fx_panel = ParamPanel(self.fx_scroll.inner, on_change=self._on_fx_params)
        self.fx_panel.pack(fill="x", padx=(0, 8))

        scope = ttk.Frame(tab, style="Panel.TFrame")
        scope.pack(fill="x", pady=(8, 0), padx=(0, 6))
        ttk.Label(scope, text="Aplicar a", style="Muted.TLabel").pack(side="left", padx=(0, 6))
        ttk.Radiobutton(scope, text="Todo el audio", value="todo", variable=self.scope,
                        style="Seg.Toolbutton").pack(side="left")
        ttk.Radiobutton(scope, text="Solo la selección", value="sel", variable=self.scope,
                        style="Seg.Toolbutton").pack(side="left")
        ttk.Button(scope, text="Restablecer", style="Small.TButton", command=self._reset_fx).pack(side="right")

        bar = ttk.Frame(tab, style="Panel.TFrame")
        bar.pack(fill="x", pady=(8, 0), padx=(0, 6))
        b = ttk.Button(bar, text="▶  Escuchar resultado", style="Accent.TButton", command=self.chain_preview)
        b.pack(side="left", fill="x", expand=True)
        ToolTip(b, "Procesa y reproduce sin modificar el audio")
        b = ttk.Button(bar, text="Aplicar al audio", style="Warm.TButton", command=self.chain_apply)
        b.pack(side="left", fill="x", expand=True, padx=(6, 0))
        ToolTip(b, "Procesa el audio del editor con la cadena activa (se puede deshacer con Ctrl+Z)")

    # ---------------- gráficos ----------------
    def _build_plots(self, parent):
        wf = ttk.Frame(parent, style="Bg.TFrame")
        wf.pack(fill="both", expand=True)
        hdr = ttk.Frame(wf, style="Toolbar.TFrame", padding=(6, 4))
        hdr.pack(side="top", fill="x")
        ttk.Label(hdr, text="Editor", style="Brand.TLabel").pack(side="left", padx=(0, 10))

        def zb(text, cmd, tip):
            b = ttk.Button(hdr, text=text, command=cmd, style="Tool.TButton")
            b.pack(side="left", padx=1)
            ToolTip(b, tip)
        zb("Ver todo", self.zoom_fit, "Mostrar todo el audio")
        zb("Acercar +", lambda: self.zoom(0.5), "Acercar (también con la rueda del ratón sobre la onda)")
        zb("Alejar −", lambda: self.zoom(2.0), "Alejar")
        zb("Zoom a selección", self.zoom_sel, "Ajustar la vista a la selección")
        ttk.Separator(hdr, orient="vertical").pack(side="left", fill="y", padx=6)
        zb("Seleccionar todo", self.select_all, "Ctrl+A")
        zb("Quitar selección", self.clear_selection, "Esc")
        self.sel_label = ttk.Label(hdr, text="", style="ToolbarMuted.TLabel")
        self.sel_label.pack(side="right", padx=8)
        ToolTip(self.sel_label, "Arrastra sobre la onda para seleccionar; un clic mueve el cursor.\n"
                                "Rueda del ratón = zoom · Mayús + rueda = desplazar")

        self.fig_w = Figure(figsize=(8, 3), dpi=100)
        self.fig_w.subplots_adjust(left=0.055, right=0.995, top=0.97, bottom=0.12)
        self.ax_w = self.fig_w.add_subplot(111)
        self.canvas_w = FigureCanvasTkAgg(self.fig_w, master=wf)
        self.canvas_w.get_tk_widget().configure(background=COLORS["bg"], highlightthickness=0)
        self.canvas_w.get_tk_widget().pack(fill="both", expand=True)
        self.span = SpanSelector(self.ax_w, self._on_span, "horizontal", useblit=True, interactive=True,
                                 drag_from_anywhere=False, minspan=0,
                                 props=dict(alpha=0.22, facecolor=COLORS["sel"]))
        self.playhead = self.ax_w.axvline(0, color=COLORS["ok"], lw=1.4, visible=False, animated=True)
        self.cursor_line = self.ax_w.axvline(0, color=COLORS["sel"], lw=1, ls="--", alpha=0.8)
        self.ax_w.callbacks.connect("xlim_changed", self._on_xlim)
        self.canvas_w.mpl_connect("draw_event", self._on_draw_w)
        self.canvas_w.mpl_connect("button_press_event", self._on_press_w)
        self.canvas_w.mpl_connect("button_release_event", self._on_release_w)
        self.canvas_w.mpl_connect("scroll_event", self._on_scroll_w)

        af = ttk.Frame(parent, style="Bg.TFrame")
        af.pack(fill="both", expand=True)
        ctl = ttk.Frame(af, style="Toolbar.TFrame", padding=(6, 4))
        ctl.pack(side="top", fill="x")
        ttk.Label(ctl, text="Análisis", style="Brand.TLabel").pack(side="left", padx=(0, 10))
        for v in ("Espectrograma", "Espectro", "Respuesta del filtro"):
            ttk.Radiobutton(ctl, text=v, value=v, variable=self.analysis_view, style="Seg.Toolbutton",
                            command=self._draw_analysis).pack(side="left")
        ttk.Checkbutton(ctl, text="Frecuencias en escala logarítmica", variable=self.log_freq,
                        style="Toolbar.TCheckbutton", command=self._draw_analysis).pack(side="left", padx=14)
        self.fig_a = Figure(figsize=(8, 3), dpi=100)
        self.fig_a.subplots_adjust(left=0.055, right=0.995, top=0.92, bottom=0.14)
        self.ax_a = self.fig_a.add_subplot(111)
        self.canvas_a = FigureCanvasTkAgg(self.fig_a, master=af)
        self.canvas_a.get_tk_widget().configure(background=COLORS["bg"], highlightthickness=0)
        self.canvas_a.get_tk_widget().pack(fill="both", expand=True)

    def _build_status(self):
        sb = ttk.Frame(self.root, style="Toolbar.TFrame", padding=(10, 3))
        sb.pack(side="bottom", fill="x")
        self.status = ttk.Label(sb, text="", style="Status.TLabel")
        self.status.pack(side="left")
        self.info = ttk.Label(sb, text="", style="Status.TLabel")
        self.info.pack(side="right")

    def _bind_keys(self):
        r = self.root
        r.bind("<Control-o>", lambda e: self.open_file())
        r.bind("<Control-s>", lambda e: self.save())
        r.bind("<Control-S>", lambda e: self.save_as())
        r.bind("<Control-n>", lambda e: self.new_silence())
        r.bind("<Control-z>", lambda e: self.undo())
        r.bind("<Control-y>", lambda e: self.redo())
        r.bind("<Control-a>", self._key_guard(self.select_all))
        r.bind("<Control-c>", self._key_guard(self.copy_sel))
        r.bind("<Control-x>", self._key_guard(self.cut_sel))
        r.bind("<Control-v>", self._key_guard(self.paste))
        r.bind("<Delete>", self._key_guard(self.delete_sel))
        r.bind("<space>", self._key_guard(self.toggle_play))
        r.bind("<Escape>", lambda e: (self.stop(), self.clear_selection()))
        r.bind("<F1>", lambda e: self.show_help())
        r.bind("<KeyPress>", self._on_keypress, add="+")

    @staticmethod
    def _is_text_widget(w):
        return isinstance(w, (tk.Entry, ttk.Entry, ttk.Spinbox, ttk.Combobox, tk.Text))

    def _key_guard(self, fn):
        def h(e):
            if self._is_text_widget(e.widget):
                return None
            if isinstance(e.widget, ttk.Treeview) and e.keysym == "Delete":
                return None
            fn()
            return "break"
        return h

    def _on_keypress(self, e):
        """Teclado del ordenador como piano (solo en la pestaña Síntesis)."""
        if self._is_text_widget(e.widget) or (e.state & 0x4) or (e.state & 0x20000) or (e.state & 0x8):
            return
        try:
            if self.nb.index(self.nb.select()) != 1:
                return
        except tk.TclError:
            return
        k = e.keysym.lower()
        now = time.perf_counter()
        if self._last_key[0] == k and now - self._last_key[1] < 0.18:
            self._last_key = (k, now)
            return
        self._last_key = (k, now)
        if k == "z":
            self._octave(-1)
        elif k == "x":
            self._octave(1)
        elif k in KEYMAP:
            self.piano.press(KEYMAP[k])

    # =====================================================================
    # Tareas en segundo plano (cola con claves para no acumular pre-escuchas)
    # =====================================================================
    def _run_bg(self, fn, on_done, label="Procesando…", key=None):
        if self.busy:
            if key:
                self._pending_jobs = [j for j in self._pending_jobs if j[3] != key]
            self._pending_jobs.append((fn, on_done, label, key))
            return
        self.busy = True
        self.progress.start(12)
        self._status(label)
        t0 = time.perf_counter()

        def worker():
            try:
                res = fn()
                self.tasks.put(("ok", on_done, res, time.perf_counter() - t0))
            except Exception as ex:  # noqa
                self.tasks.put(("err", None, (ex, traceback.format_exc()), 0))
        threading.Thread(target=worker, daemon=True).start()

    def _poll_tasks(self):
        try:
            while True:
                kind, cb, res, dt = self.tasks.get_nowait()
                self.busy = False
                self.progress.stop()
                if kind == "ok":
                    try:
                        cb(res)
                    except Exception as ex:
                        traceback.print_exc()
                        messagebox.showerror("Error", str(ex))
                    if dt > 0.3:
                        self._status(self.status.cget("text") + f"  ({dt:.1f} s)")
                else:
                    ex, tb = res
                    print(tb)
                    self._status("Error: " + str(ex))
                    messagebox.showerror("Error", f"{ex}\n\n{tb[-1500:]}")
        except queue.Empty:
            pass
        if not self.busy and self._pending_jobs:
            self._run_bg(*self._pending_jobs.pop(0))
        self.root.after(40, self._poll_tasks)

    def _status(self, text):
        self.status.config(text=text)

    # =====================================================================
    # Estado del audio / deshacer
    # =====================================================================
    def _push_undo(self, label):
        self.undo_stack.append((label, None if self.audio is None else self.audio.copy(), self.sr))
        if len(self.undo_stack) > MAX_UNDO:
            self.undo_stack.pop(0)
        self.redo_stack.clear()

    def set_audio(self, data, label="Edición", sr=None, undoable=True, keep_view=False):
        if undoable:
            self._push_undo(label)
        self.audio = None if data is None else as_2d(np.nan_to_num(data)).astype(np.float64)
        if sr:
            self.sr = int(sr)
            self.sr_combo.set(str(self.sr))
        n = 0 if self.audio is None else len(self.audio)
        if self.selection and self.selection[1] > n:
            self.selection = None
        self.cursor = min(self.cursor, n)
        self._refresh_all(keep_view=keep_view)
        self._status(label)

    def undo(self):
        if not self.undo_stack:
            return self._status("Nada que deshacer.")
        label, data, sr = self.undo_stack.pop()
        self.redo_stack.append((label, None if self.audio is None else self.audio.copy(), self.sr))
        self.audio, self.sr = data, sr
        self.sr_combo.set(str(sr))
        self.selection = None
        self._refresh_all()
        self._status(f"Deshecho: {label}")

    def redo(self):
        if not self.redo_stack:
            return self._status("Nada que rehacer.")
        label, data, sr = self.redo_stack.pop()
        self.undo_stack.append((label, None if self.audio is None else self.audio.copy(), self.sr))
        self.audio, self.sr = data, sr
        self.sr_combo.set(str(sr))
        self.selection = None
        self._refresh_all()
        self._status(f"Rehecho: {label}")

    def _sel_or_all(self):
        if self.audio is None:
            return 0, 0
        return self.selection if self.selection else (0, len(self.audio))

    # =====================================================================
    # Dibujo
    # =====================================================================
    def _refresh_all(self, keep_view=False):
        self._draw_wave(keep_view=keep_view)
        self._draw_analysis()
        self._update_info()

    def _update_info(self):
        if self.audio is None:
            self.info.config(text="Sin audio en el editor")
            self.peak_label.config(text="")
            self.sel_label.config(text="")
            self.dur_label.config(text="/ 0:00.000")
            return
        n, ch = self.audio.shape
        name = os.path.basename(self.path) if self.path else "sin título"
        self.info.config(text=f"{name}   ·   {n / self.sr:.3f} s   ·   {self.sr} Hz   ·   "
                              f"{'estéreo' if ch == 2 else 'mono' if ch == 1 else f'{ch} canales'}")
        self.dur_label.config(text=f"/ {fmt_time(n / self.sr)}")
        pk = float(np.max(np.abs(self.audio))) if n else 0.0
        db = 20 * np.log10(pk) if pk > 0 else -np.inf
        if pk > 1.0:
            self.peak_label.config(text=f"Pico {db:+.1f} dB  SATURA", foreground=COLORS["danger"])
        else:
            self.peak_label.config(text=f"Pico {db:+.1f} dBFS", foreground=COLORS["muted"])
        if self.selection:
            a, b = self.selection
            self.sel_label.config(text=f"Selección {(b - a) / self.sr:.2f} s", foreground=COLORS["sel"])
        else:
            self.sel_label.config(text="Sin selección", foreground=COLORS["muted"])

    def _draw_wave(self, keep_view=False):
        ax = self.ax_w
        xlim = ax.get_xlim() if keep_view else None
        for a in self._wave_artists:
            try:
                a.remove()
            except ValueError:
                pass
        self._wave_artists = []
        ax.grid(True, alpha=0.5)
        if self.audio is None or len(self.audio) == 0:
            ax.set_xlim(0, 1)
            ax.set_ylim(-1.05, 1.05)
            self._wave_artists.append(ax.text(
                0.5, 0.12, "El editor está vacío", ha="center", va="center", color=COLORS["fg"], fontsize=13,
                fontweight="bold"))
            self._wave_artists.append(ax.text(
                0.5, -0.18, "Elige un sonido en «Biblioteca», créalo en «Síntesis» y pulsa «Usar en el editor»,\n"
                            "o abre un archivo de audio (Ctrl+O).", ha="center", va="center",
                color=COLORS["muted"], fontsize=9.5, linespacing=1.6))
            self.span.set_visible(False)
            self.canvas_w.draw_idle()
            return
        dur = len(self.audio) / self.sr
        self._in_redraw = True
        if xlim and xlim[1] <= dur * 1.05 and xlim[0] >= 0:
            ax.set_xlim(*xlim)
        else:
            ax.set_xlim(0, dur)
        ax.set_ylim(-1.05, 1.05)
        self._in_redraw = False
        ax.set_xlabel("tiempo (s)")
        self._draw_wave_data()
        self.cursor_line.set_xdata([self.cursor / self.sr] * 2)
        if self.selection:
            self.span.extents = (self.selection[0] / self.sr, self.selection[1] / self.sr)
            self.span.set_visible(True)
        else:
            self.span.set_visible(False)
        self.canvas_w.draw_idle()

    def _draw_wave_data(self):
        ax = self.ax_w
        for a in self._wave_artists:
            try:
                a.remove()
            except ValueError:
                pass
        self._wave_artists = []
        x0, x1 = ax.get_xlim()
        n = len(self.audio)
        i0 = max(int(x0 * self.sr) - 1, 0)
        i1 = min(int(x1 * self.sr) + 2, n)
        if i1 <= i0:
            return
        seg = self.audio[i0:i1]
        width_px = max(int(self.canvas_w.get_tk_widget().winfo_width()), 400)
        colors = [COLORS["wave"], COLORS["wave2"]]
        ch = seg.shape[1]
        for c in range(min(ch, 2)):
            y = seg[:, c]
            alpha = 0.85 if ch == 1 else 0.6
            if len(y) > width_px * 3:
                bins = width_px * 2
                L = len(y) // bins
                yy = y[:L * bins].reshape(bins, L)
                t = (i0 + np.arange(bins) * L + L / 2) / self.sr
                art = ax.fill_between(t, yy.min(axis=1), yy.max(axis=1), color=colors[c], alpha=alpha, lw=0)
            else:
                t = (i0 + np.arange(len(y))) / self.sr
                art, = ax.plot(t, y, color=colors[c], lw=0.9, alpha=alpha)
            self._wave_artists.append(art)
        self._wave_artists.append(ax.axhline(0, color=COLORS["border"], lw=0.6))
        if ch == 2:
            self._wave_artists.append(ax.text(0.003, 0.97, "L", transform=ax.transAxes, color=colors[0],
                                              va="top", fontsize=8, fontweight="bold"))
            self._wave_artists.append(ax.text(0.015, 0.97, "R", transform=ax.transAxes, color=colors[1],
                                              va="top", fontsize=8, fontweight="bold"))

    def _on_xlim(self, ax):
        if getattr(self, "_in_redraw", False) or self.audio is None:
            return
        if getattr(self, "_xlim_job", None):
            self.root.after_cancel(self._xlim_job)
        self._xlim_job = self.root.after(60, self._redraw_zoom)

    def _redraw_zoom(self):
        self._xlim_job = None
        if self.audio is not None:
            self._draw_wave_data()
            self.canvas_w.draw_idle()

    def _on_draw_w(self, _):
        self._bg_cache = self.canvas_w.copy_from_bbox(self.ax_w.bbox)

    # ---------------- zoom ----------------
    def _set_view(self, x0, x1):
        if self.audio is None:
            return
        dur = len(self.audio) / self.sr
        w = max(x1 - x0, 64 / self.sr)
        w = min(w, dur)
        x0 = min(max(x0, 0), dur - w)
        self.ax_w.set_xlim(x0, x0 + w)
        self.canvas_w.draw_idle()

    def zoom_fit(self):
        if self.audio is not None:
            self._set_view(0, len(self.audio) / self.sr)

    def zoom(self, factor, center=None):
        if self.audio is None:
            return
        x0, x1 = self.ax_w.get_xlim()
        c = center if center is not None else (x0 + x1) / 2
        self._set_view(c - (c - x0) * factor, c + (x1 - c) * factor)

    def zoom_sel(self):
        if self.selection:
            a, b = self.selection
            pad = (b - a) / self.sr * 0.05
            self._set_view(a / self.sr - pad, b / self.sr + pad)

    def _on_scroll_w(self, e):
        if self.audio is None or e.inaxes is not self.ax_w:
            return
        if e.key == "shift":
            x0, x1 = self.ax_w.get_xlim()
            d = (x1 - x0) * 0.15 * (-1 if e.button == "up" else 1)
            self._set_view(x0 + d, x1 + d)
        else:
            self.zoom(0.8 if e.button == "up" else 1.25, center=e.xdata)

    # ---------------- análisis ----------------
    def _draw_analysis(self):
        self.fig_a.clf()
        ax = self.ax_a = self.fig_a.add_subplot(111)
        view = self.analysis_view.get()
        logf = self.log_freq.get()
        if view == "Respuesta del filtro":
            self._draw_response(ax)
        elif self.audio is None or len(self.audio) < 64:
            ax.set_xticks([])
            ax.set_yticks([])
            ax.text(0.5, 0.5, "Aquí verás el espectrograma o el espectro del audio del editor",
                    ha="center", va="center", color=COLORS["dim"], transform=ax.transAxes, fontsize=9.5)
        else:
            a, b = self._sel_or_all()
            x = self.audio[a:b].mean(axis=1)
            if len(x) < 64:
                x = self.audio.mean(axis=1)
            if view == "Espectrograma":
                self._draw_spectrogram(ax, x, logf, a / self.sr)
            else:
                self._draw_spectrum(ax, x, logf)
        self.canvas_a.draw_idle()

    def _draw_spectrogram(self, ax, x, logf, t0):
        sr = self.sr
        nper = 2048 if len(x) > 8192 else 256
        hop = max(nper // 4, len(x) // 1400)
        f, t, S = signal.spectrogram(x, sr, window="hann", nperseg=nper, noverlap=max(nper - hop, 0),
                                     mode="magnitude")
        if S.size == 0:
            return
        db = 20 * np.log10(S + 1e-10)
        vmax = db.max()
        if logf:
            keep = f >= 20
            f, db = f[keep], db[keep]
        ax.pcolormesh(t + t0, f, db, shading="auto", cmap="magma", vmin=vmax - 90, vmax=vmax, rasterized=True)
        if logf:
            ax.set_yscale("log")
            ax.set_ylim(20, sr / 2)
        else:
            ax.set_ylim(0, sr / 2)
        ax.set_title("Espectrograma" + ("  · selección" if self.selection else "") +
                     "   (brillo = energía de cada frecuencia en el tiempo)", loc="left")
        ax.set_xlabel("tiempo (s)")
        ax.set_ylabel("Hz")

    def _draw_spectrum(self, ax, x, logf):
        sr = self.sr
        N = min(len(x), 2 ** 20)
        x = x[:N]
        if N > 16384:
            f, P = signal.welch(x, sr, nperseg=8192)
            mag = 10 * np.log10(P + 1e-20)
            mag -= mag.max()
        else:
            X = np.abs(np.fft.rfft(x * np.hanning(N)))
            f = np.fft.rfftfreq(N, 1 / sr)
            mag = 20 * np.log10(X / (X.max() or 1) + 1e-10)
        ax.plot(f, mag, color=COLORS["accent"], lw=0.9)
        ax.fill_between(f, mag, -120, color=COLORS["accent"], alpha=0.15)
        if logf:
            ax.set_xscale("log")
            ax.set_xlim(20, sr / 2)
        else:
            ax.set_xlim(0, sr / 2)
        ax.set_ylim(-100, 3)
        ax.grid(True, which="both", alpha=0.5)
        ax.set_title("Espectro de magnitud" + ("  · selección" if self.selection else "") +
                     "   (cada pico es un armónico o componente)", loc="left")
        ax.set_xlabel("Hz")
        ax.set_ylabel("dB")

    def _draw_response(self, ax):
        sr = self.sr
        if self.chain_sel is None or self.chain_sel >= len(self.chain):
            ax.set_xticks([])
            ax.set_yticks([])
            ax.text(0.5, 0.5, "Selecciona un filtro de la cadena (pestaña «Efectos») para ver cómo afecta a cada frecuencia",
                    ha="center", va="center", color=COLORS["dim"], transform=ax.transAxes, fontsize=9.5)
            return
        item = self.chain[self.chain_sel]
        cls = PROCESSOR_BY_NAME[item["name"]]
        try:
            resp = cls.freq_response(cls.coerce(item["params"]), sr)
        except Exception as ex:
            resp = None
            print("respuesta:", ex)
        total, count = None, 0
        for c in self.chain:
            if c.get("bypass"):
                continue
            k = PROCESSOR_BY_NAME[c["name"]]
            try:
                r = k.freq_response(k.coerce(c["params"]), sr)
            except Exception:
                r = None
            if r is not None:
                fr, m = r
                m = np.interp(np.linspace(1, sr / 2, 4096), fr, m)
                total = m if total is None else total + m
                count += 1
        if resp is None:
            ax.set_xticks([])
            ax.set_yticks([])
            ax.text(0.5, 0.5, f"«{cls.name}» no es un filtro lineal fijo:\nno tiene una curva de respuesta en frecuencia.",
                    ha="center", va="center", color=COLORS["dim"], transform=ax.transAxes, fontsize=9.5)
            return
        f, m = resp
        if total is not None and count > 1:
            ax.plot(np.linspace(1, sr / 2, 4096), total, color=COLORS["accent2"], lw=1, alpha=0.7,
                    label="toda la cadena (filtros)")
        ax.plot(f, m, color=COLORS["accent"], lw=1.8, label=cls.name.split(" (")[0])
        ax.axhline(0, color=COLORS["border"], lw=0.8)
        if self.log_freq.get():
            ax.set_xscale("log")
            ax.set_xlim(20, sr / 2)
        else:
            ax.set_xlim(0, sr / 2)
        ax.set_ylim(max(min(np.min(m), -6) - 6, -120), max(np.max(m), 3) + 6)
        ax.grid(True, which="both", alpha=0.5)
        ax.legend(loc="lower left", fontsize=7.5, facecolor=COLORS["panel"], edgecolor=COLORS["border"])
        ax.set_title("Respuesta en frecuencia   (0 dB = sin cambio · negativo = atenuado)", loc="left")
        ax.set_xlabel("Hz")
        ax.set_ylabel("dB")

    # ---------------- selección con el ratón ----------------
    def _on_span(self, xmin, xmax):
        if self.audio is None:
            return
        n = len(self.audio)
        a = int(np.clip(xmin * self.sr, 0, n))
        b = int(np.clip(xmax * self.sr, 0, n))
        if b - a < max(int(0.002 * self.sr), 2):
            self.selection = None
            self.cursor = a
            self.span.set_visible(False)
        else:
            self.selection = (a, b)
            self.cursor = a
            self.scope.set("sel")
        self.cursor_line.set_xdata([self.cursor / self.sr] * 2)
        self.canvas_w.draw_idle()
        self._update_info()
        self._draw_analysis()

    def _on_press_w(self, e):
        self._press_x = e.xdata if (e.inaxes is self.ax_w and e.button == 1) else None

    def _on_release_w(self, e):
        px = getattr(self, "_press_x", None)
        self._press_x = None
        if px is None or self.audio is None or e.inaxes is not self.ax_w or e.xdata is None:
            return
        x0, x1 = self.ax_w.get_xlim()
        if abs(e.xdata - px) < (x1 - x0) * 0.003:
            self.selection = None
            self.scope.set("todo")
            self.span.set_visible(False)
            self.cursor = int(np.clip(e.xdata * self.sr, 0, len(self.audio)))
            self.cursor_line.set_xdata([self.cursor / self.sr] * 2)
            self.canvas_w.draw_idle()
            self._update_info()
            self._draw_analysis()

    def select_all(self):
        if self.audio is None:
            return
        self.selection = (0, len(self.audio))
        self._draw_wave(keep_view=True)
        self._update_info()
        self._draw_analysis()

    def clear_selection(self):
        self.selection = None
        self.scope.set("todo")
        self.span.set_visible(False)
        self.canvas_w.draw_idle()
        self._update_info()
        self._draw_analysis()

    # =====================================================================
    # Reproducción
    # =====================================================================
    def _play(self, data, offset_s=0.0, show_head=True):
        if data is None or len(data) == 0:
            return
        try:
            self.player.play(data, self.sr, offset_s if show_head else None, loop=self.loop_var.get(),
                             volume=self.volume.get())
        except Exception as ex:
            if not getattr(self, "_audio_error_shown", False):
                self._audio_error_shown = True
                messagebox.showerror("Audio", f"No se pudo reproducir el sonido:\n{ex}\n\n"
                                              "Revisa que haya una salida de audio disponible.")
            self._status(f"No se pudo reproducir: {ex}")

    def play_all(self):
        if self.audio is None:
            return self._status("El editor está vacío: genera un sonido o abre un archivo.")
        a, b = self._sel_or_all()
        if not self.selection and 0 < self.cursor < len(self.audio):
            a = self.cursor
        self._play(self.audio[a:b], a / self.sr)

    def toggle_play(self):
        if self.player.playing:
            self.stop()
        else:
            self.play_all()

    def stop(self):
        self.player.stop()

    def _tick(self):
        pos = self.player.position()
        ph = self.playhead
        try:
            if pos is not None and self.player.offset is not None:
                self.time_label.config(text=fmt_time(pos))
            elif self.audio is not None:
                self.time_label.config(text=fmt_time(self.cursor / self.sr))
            else:
                self.time_label.config(text="0:00.000")
            if pos is not None and self.player.offset is not None and self.audio is not None \
                    and self._bg_cache is not None:
                ph.set_xdata([pos, pos])
                ph.set_visible(True)
                self.canvas_w.restore_region(self._bg_cache)
                self.ax_w.draw_artist(ph)
                self.canvas_w.blit(self.ax_w.bbox)
            elif ph.get_visible():
                ph.set_visible(False)
                if self._bg_cache is not None:
                    self.canvas_w.restore_region(self._bg_cache)
                    self.canvas_w.blit(self.ax_w.bbox)
        except Exception:
            pass
        self.root.after(40, self._tick)

    # =====================================================================
    # Biblioteca
    # =====================================================================
    def _refresh_library(self):
        lib = []
        if os.path.isdir(PRESET_DIR):
            for fn in sorted(os.listdir(PRESET_DIR)):
                if not fn.lower().endswith(".json"):
                    continue
                path = os.path.join(PRESET_DIR, fn)
                try:
                    with open(path, encoding="utf-8") as fh:
                        d = json.load(fh)
                except Exception:
                    continue
                d.setdefault("title", fn[:-5])
                d.setdefault("category", "Cadenas de efectos" if d.get("type") == "chain" else "Mis sonidos")
                d["_path"] = path
                lib.append(d)
        self.library = lib
        self._fill_library_tree()
        self._fill_chain_menu()

    def _fill_library_tree(self):
        tree = self.lib_tree
        tree.delete(*tree.get_children())
        q = self.search.get().strip().lower()
        cats = {}
        for i, d in enumerate(self.library):
            hay = " ".join([d.get("title", ""), d.get("category", ""), d.get("synth", ""),
                            d.get("description", "")]).lower()
            if q and q not in hay:
                continue
            cats.setdefault(d["category"], []).append(i)
        order = [c for c in CATEGORY_ORDER if c in cats] + sorted(c for c in cats if c not in CATEGORY_ORDER)
        for ci, cat in enumerate(order):
            cid = f"cat:{cat}"
            tree.insert("", "end", iid=cid, text=f"{cat}  ({len(cats[cat])})", open=True, tags=("cat",))
            for i in cats[cat]:
                d = self.library[i]
                tags = ("chain",) if d.get("type") == "chain" else ()
                tree.insert(cid, "end", iid=f"p:{i}", text="   " + d["title"], tags=tags)
        if not tree.selection():
            n = sum(len(v) for v in cats.values())
            self.lib_info.show("Selecciona un sonido" if n else "Sin resultados", "",
                               "Aquí verás qué puedes esperar de cada sonido." if n
                               else "Prueba con otra palabra: «bajo», «pad», «campana», «FM», «voz»…")

    def _lib_selected(self):
        sel = self.lib_tree.selection()
        if not sel or not sel[0].startswith("p:"):
            return None
        return self.library[int(sel[0][2:])]

    def _on_lib_select(self):
        d = self._lib_selected()
        if d is None:
            sel = self.lib_tree.selection()
            if sel:
                cat = sel[0][4:]
                self.lib_info.show(cat, "", "Despliega la categoría y elige un sonido.")
            return
        if d.get("type") == "chain":
            names = " → ".join(c["name"].split(" (")[0] for c in d.get("chain", []))
            self.lib_info.show(d["title"], "Cadena de efectos", d.get("description", ""), f"Contiene: {names}")
            self.lib_listen_btn.configure(text="▶  Escuchar sobre el audio")
            self.lib_edit_btn.configure(text="Cargar en Efectos")
            self.lib_use_btn.state(["disabled"])
        else:
            cls = SYNTH_BY_NAME.get(d.get("synth"))
            tags = f"Método: {d.get('synth', '?')}"
            if cls is not None:
                tags += f"   ·   {cls.character}"
            notes = d.get("common", {}).get("sequence", "")
            self.lib_info.show(d["title"], tags, d.get("description", ""),
                               f"Notas de ejemplo: {notes}" if notes else "")
            self.lib_listen_btn.configure(text="▶  Escuchar")
            self.lib_edit_btn.configure(text="Editar en Síntesis")
            self.lib_use_btn.state(["!disabled"])

    def lib_listen(self):
        d = self._lib_selected()
        if d is None:
            return
        if d.get("type") == "chain":
            self.apply_preset(d, switch_tab=False)
            if self.audio is None:
                return self._status("La cadena se cargó; necesitas audio en el editor para escucharla.")
            self.chain_preview()
        else:
            self.apply_preset(d, switch_tab=False)
            self.synth_preview()

    def lib_edit(self):
        d = self._lib_selected()
        if d is not None:
            self.apply_preset(d, switch_tab=True)

    def lib_use(self, mode):
        d = self._lib_selected()
        if d is not None and d.get("type") != "chain":
            self.apply_preset(d, switch_tab=False)
            self.synth_commit(mode)

    def _fill_chain_menu(self):
        m = self.chain_menu
        m.delete(0, "end")
        chains = [d for d in self.library if d.get("type") == "chain"]
        for d in chains:
            m.add_command(label=d["title"], command=lambda d=d: self.apply_preset(d))
        if chains:
            m.add_separator()
        m.add_command(label="Guardar esta cadena…", command=self.save_chain)
        m.add_command(label="Cargar cadena desde archivo…", command=self.load_preset_file)
        m.add_separator()
        m.add_command(label="Vaciar la cadena", command=self.chain_clear)

    # =====================================================================
    # Síntesis
    # =====================================================================
    def _on_synth_changed(self, values=None):
        cls = SYNTH_BY_NAME[self.synth_combo.get()]
        self.synth_info.show(cls.name, f"{getattr(cls, 'character', '')}   ·   Ideal para: {getattr(cls, 'ideal', '')}",
                             getattr(cls, "sound", cls.description),
                             ("Prueba: " + cls.tips) if getattr(cls, "tips", "") else "")
        self.synth_panel.build(cls.params, values, collapsed=("LFO de filtro (wah)", "Modulación de pulso (PWM)"))
        self.synth_scroll.scroll_top()

    def _on_synth_params(self, _values):
        if self.auto_preview.get():
            self.synth_preview(quiet=True)

    def _reset_synth(self):
        self.synth_panel.reset()
        self.common_panel.reset()

    def _octave(self, d):
        self.piano.set_base(self.piano.base + d)
        self.oct_label.configure(text=f"C{self.piano.base} – C{self.piano.base + 2}")

    def _synth_job(self, override=None):
        cls = SYNTH_BY_NAME[self.synth_combo.get()]
        sp = self.synth_panel.get_values()
        cp = self.common_panel.get_values()
        if override:
            cp.update(override)
        sr = self.sr
        ctx = {"buffer": None if self.audio is None else self.audio.copy(), "buffer_sr": self.sr}
        if self.selection and self.audio is not None:
            a, b = self.selection
            ctx["buffer"] = self.audio[a:b].copy()
        return lambda: render_synth(cls, sp, cp, sr, ctx), cls.name

    def synth_preview(self, quiet=False):
        job, name = self._synth_job()

        def done(y):
            self._status(f"Escuchando: {name}  ({len(y) / self.sr:.2f} s)")
            self._play(y, show_head=False)
        self._run_bg(job, done, f"Generando {name}…", key="preview")

    def _piano_note(self, note):
        if self.write_notes.get():
            var = self.common_panel.entry_var("sequence")
            if var is not None:
                cur = var.get().strip()
                var.set((cur + " " + note).strip())
        dur = self.common_panel.get_values().get("note_dur", 1.0)
        job, name = self._synth_job({"sequence": note, "note_dur": min(float(dur), 4.0)})
        self._run_bg(job, lambda y: (self._play(y, show_head=False), self._status(f"{note}  ·  {name}")),
                     f"{note}…", key="note")

    def synth_commit(self, mode):
        job, name = self._synth_job()

        def done(y):
            if mode == "replace" or self.audio is None:
                self.path = None
                self.selection = None
                self.cursor = 0
                self.set_audio(y, f"Sonido «{name}» enviado al editor")
                return
            cur = self.audio
            ch = max(cur.shape[1], y.shape[1])
            cur2 = np.repeat(cur, ch, axis=1) if cur.shape[1] < ch else cur
            y2 = np.repeat(y, ch, axis=1) if y.shape[1] < ch else y
            c = self.cursor
            if mode == "append":
                new = np.vstack([cur2, y2])
            elif mode == "insert":
                new = np.vstack([cur2[:c], y2, cur2[c:]])
            else:
                new = np.vstack([cur2[:c], mix_to_length(cur2[c:], y2)])
            labels = dict((m, l) for l, m in USE_MODES)
            self.set_audio(new, f"{labels[mode]}: {name}")
        self._run_bg(job, done, f"Generando {name}…")

    # =====================================================================
    # Cadena de efectos
    # =====================================================================
    def _refresh_tree(self):
        self.tree.delete(*self.tree.get_children())
        for i, item in enumerate(self.chain):
            on = not item.get("bypass")
            self.tree.insert("", "end", iid=str(i), values=("●" if on else "○", f"{i + 1}.  {item['name']}"),
                             tags=() if on else ("off",))
        if self.chain_sel is not None and self.chain_sel < len(self.chain):
            self.tree.selection_set(str(self.chain_sel))
            self.tree.see(str(self.chain_sel))

    def _show_chain_empty(self):
        self.fx_panel.build([])
        self.fx_info.show("La cadena está vacía",
                          "",
                          "Pulsa «+ Añadir efecto» y elige un filtro o efecto, o carga una de las «Cadenas guardadas».",
                          "Los efectos procesan el audio del editor (la parte derecha). Primero lleva ahí un sonido o "
                          "abre un archivo.")

    def chain_add(self, name):
        cls = PROCESSOR_BY_NAME[name]
        self.chain.append({"name": name, "params": cls.defaults(), "bypass": False})
        self.chain_sel = len(self.chain) - 1
        self._refresh_tree()
        self._on_chain_select()
        self.nb.select(2)

    def _on_chain_select(self):
        sel = self.tree.selection()
        if not sel:
            return
        i = int(sel[0])
        self.chain_sel = i
        item = self.chain[i]
        cls = PROCESSOR_BY_NAME[item["name"]]
        self.fx_info.show(f"{i + 1}.  {cls.name}", cls.category,
                          getattr(cls, "sound", "") or cls.description,
                          cls.description if getattr(cls, "sound", "") else "")
        self.fx_panel.build(cls.params, item["params"])
        self.fx_scroll.scroll_top()
        if cls.category == "Filtros":
            self.analysis_view.set("Respuesta del filtro")
        self._draw_analysis()

    def _on_fx_params(self, values):
        if self.chain_sel is None or self.chain_sel >= len(self.chain):
            return
        self.chain[self.chain_sel]["params"] = values
        if self.analysis_view.get() == "Respuesta del filtro":
            self._draw_analysis()

    def _reset_fx(self):
        if self.chain_sel is not None and self.chain:
            self.fx_panel.reset()

    def chain_move(self, d):
        i = self.chain_sel
        if i is None:
            return
        j = i + d
        if 0 <= j < len(self.chain):
            self.chain[i], self.chain[j] = self.chain[j], self.chain[i]
            self.chain_sel = j
            self._refresh_tree()

    def chain_toggle(self):
        i = self.chain_sel
        if i is None or i >= len(self.chain):
            return
        self.chain[i]["bypass"] = not self.chain[i].get("bypass")
        self._refresh_tree()
        self._draw_analysis()

    def chain_duplicate(self):
        i = self.chain_sel
        if i is None or i >= len(self.chain):
            return
        self.chain.insert(i + 1, copy.deepcopy(self.chain[i]))
        self.chain_sel = i + 1
        self._refresh_tree()
        self._on_chain_select()

    def chain_remove(self):
        i = self.chain_sel
        if i is None or i >= len(self.chain):
            return
        self.chain.pop(i)
        self.chain_sel = min(i, len(self.chain) - 1) if self.chain else None
        self._refresh_tree()
        if self.chain_sel is not None:
            self._on_chain_select()
        else:
            self._show_chain_empty()
            self._draw_analysis()

    def chain_clear(self):
        if self.chain and messagebox.askyesno(APP_NAME, "¿Vaciar la cadena de efectos?"):
            self.chain.clear()
            self.chain_sel = None
            self._refresh_tree()
            self._show_chain_empty()
            self._draw_analysis()

    def _chain_segment(self):
        if self.audio is None:
            messagebox.showinfo(APP_NAME, "El editor está vacío.\nPrimero lleva un sonido al editor "
                                          "(«Usar en el editor») o abre un archivo.")
            return None
        if not any(not c.get("bypass") for c in self.chain):
            messagebox.showinfo(APP_NAME, "La cadena está vacía (o todo está desactivado).\n"
                                          "Pulsa «+ Añadir efecto».")
            return None
        if self.scope.get() == "sel" and self.selection:
            return self.selection
        return 0, len(self.audio)

    def chain_preview(self):
        r = self._chain_segment()
        if r is None:
            return
        a, b = r
        seg = self.audio[a:b].copy()
        chain, sr = copy.deepcopy(self.chain), self.sr
        self._run_bg(lambda: run_chain(seg, sr, chain),
                     lambda y: (self._play(y, show_head=False), self._status("Escuchando el resultado de la cadena")),
                     "Procesando la cadena…", key="chainpreview")

    def chain_apply(self):
        r = self._chain_segment()
        if r is None:
            return
        a, b = r
        seg = self.audio[a:b].copy()
        chain, sr = copy.deepcopy(self.chain), self.sr

        def done(y):
            cur = self.audio
            ch = max(cur.shape[1], y.shape[1])
            cur2 = np.repeat(cur, ch, axis=1) if cur.shape[1] < ch else cur
            y2 = np.repeat(y, ch, axis=1) if y.shape[1] < ch else y
            y2 = y2[:, :ch]
            new = np.vstack([cur2[:a], y2, cur2[b:]])
            if self.selection:
                self.selection = (a, a + len(y2))
            names = ", ".join(c["name"].split(" (")[0] for c in chain if not c.get("bypass"))
            self.set_audio(new, f"Aplicado: {names}", keep_view=(len(new) == len(cur)))
        self._run_bg(lambda: run_chain(seg, sr, chain), done, "Aplicando la cadena…")

    # =====================================================================
    # Archivo
    # =====================================================================
    def new_silence(self):
        d = simpledialog.askfloat(APP_NAME, "Duración del silencio (s):", initialvalue=2.0, minvalue=0.01,
                                  maxvalue=3600, parent=self.root)
        if d:
            self.path = None
            self.selection = None
            self.cursor = 0
            self.set_audio(np.zeros((int(d * self.sr), 1)), "Nuevo silencio")

    def open_file(self):
        f = filedialog.askopenfilename(filetypes=LOAD_TYPES)
        if not f:
            return

        def done(res):
            data, sr = res
            self.path = f
            self.selection = None
            self.cursor = 0
            self.set_audio(data, f"Abierto: {os.path.basename(f)}", sr=sr)
        self._run_bg(lambda: load_audio(f), done, f"Cargando {os.path.basename(f)}…")

    def insert_file(self, mix=False):
        f = filedialog.askopenfilename(filetypes=LOAD_TYPES)
        if not f:
            return
        data, sr = load_audio(f)
        data = resample(data, sr, self.sr)
        if self.audio is None:
            self.set_audio(data, "Archivo insertado", sr=self.sr)
            return
        c = self.cursor
        cur = self.audio
        ch = max(cur.shape[1], data.shape[1])
        cur = np.repeat(cur, ch, axis=1) if cur.shape[1] < ch else cur
        data = np.repeat(data, ch, axis=1) if data.shape[1] < ch else data
        new = np.vstack([cur[:c], mix_to_length(cur[c:], data)]) if mix else np.vstack([cur[:c], data, cur[c:]])
        self.set_audio(new, f"{'Mezclado' if mix else 'Insertado'}: {os.path.basename(f)}")

    def _ask_save_path(self):
        ext = SAVE_FORMATS[self.export_fmt.get()][2]
        return filedialog.asksaveasfilename(defaultextension=ext,
                                            filetypes=[(self.export_fmt.get(), "*" + ext), ("Todos", "*.*")])

    def save(self):
        if self.audio is None:
            return self._status("No hay audio que guardar.")
        if not self.path or os.path.splitext(self.path)[1].lower() not in (".wav", ".flac", ".ogg"):
            return self.save_as()
        self._write(self.path, self.audio)

    def save_as(self):
        if self.audio is None:
            return self._status("No hay audio que guardar.")
        f = self._ask_save_path()
        if f:
            self.path = self._write(f, self.audio)
            self._update_info()

    def export_selection(self):
        if self.audio is None or not self.selection:
            return messagebox.showinfo(APP_NAME, "No hay selección.")
        f = self._ask_save_path()
        if f:
            a, b = self.selection
            self._write(f, self.audio[a:b])

    def _write(self, path, data):
        ext = os.path.splitext(path)[1].lower()
        fmt = self.export_fmt.get()
        for k, (_, _, e) in SAVE_FORMATS.items():
            if e == ext and SAVE_FORMATS[fmt][2] != ext:
                fmt = k
                break
        if np.max(np.abs(data)) > 1.0:
            if messagebox.askyesno(APP_NAME, "El audio supera 0 dBFS y se recortará.\n"
                                             "¿Normalizar a -0.3 dBFS antes de guardar?"):
                data = data / np.max(np.abs(data)) * 10 ** (-0.3 / 20)
        p = save_audio(path, data, self.sr, fmt)
        self._status(f"Guardado: {p}  ({fmt})")
        return p

    # =====================================================================
    # Edición
    # =====================================================================
    def copy_sel(self):
        if self.audio is not None and self.selection:
            a, b = self.selection
            self.clipboard = self.audio[a:b].copy()
            self._status(f"Copiado {(b - a) / self.sr:.3f} s")

    def cut_sel(self):
        if self.audio is not None and self.selection:
            self.copy_sel()
            self.delete_sel()

    def paste(self, mix=False):
        if self.clipboard is None:
            return
        clip = self.clipboard
        if self.audio is None:
            return self.set_audio(clip.copy(), "Pegar")
        c = self.cursor
        cur = self.audio
        ch = max(cur.shape[1], clip.shape[1])
        cur = np.repeat(cur, ch, axis=1) if cur.shape[1] < ch else cur
        clip = np.repeat(clip, ch, axis=1) if clip.shape[1] < ch else clip
        new = np.vstack([cur[:c], mix_to_length(cur[c:], clip)]) if mix else np.vstack([cur[:c], clip, cur[c:]])
        self.set_audio(new, "Pegar mezclando" if mix else "Pegar")

    def crop_to_sel(self):
        if self.audio is not None and self.selection:
            a, b = self.selection
            self.selection = None
            self.cursor = 0
            self.set_audio(self.audio[a:b].copy(), "Recortar a la selección")

    def delete_sel(self):
        if self.audio is not None and self.selection:
            a, b = self.selection
            self.selection = None
            self.cursor = a
            self.set_audio(np.vstack([self.audio[:a], self.audio[b:]]), "Borrar selección")

    def silence_sel(self):
        if self.audio is not None and self.selection:
            a, b = self.selection
            new = self.audio.copy()
            new[a:b] = 0
            self.set_audio(new, "Silenciar selección", keep_view=True)

    def insert_silence(self):
        if self.audio is None:
            return self.new_silence()
        d = simpledialog.askfloat(APP_NAME, "Duración del silencio a insertar (s):", initialvalue=1.0,
                                  minvalue=0.001, parent=self.root)
        if d:
            c = self.cursor
            z = np.zeros((int(d * self.sr), self.audio.shape[1]))
            self.set_audio(np.vstack([self.audio[:c], z, self.audio[c:]]), "Insertar silencio")

    def _on_sr_combo(self, _=None):
        new = int(self.sr_combo.get())
        if new == self.sr:
            return
        if self.audio is None:
            self.sr = new
            self._status(f"Frecuencia de muestreo: {new} Hz")
            return
        if messagebox.askyesno(APP_NAME, f"¿Remuestrear el audio de {self.sr} Hz a {new} Hz?\n"
                                         f"(No = solo cambiar la frecuencia de reproducción, alterando velocidad y tono)"):
            data = resample(self.audio, self.sr, new)
            self.selection = None
            self.set_audio(data, f"Remuestreo {self.sr}→{new} Hz", sr=new)
        else:
            self._push_undo("Cambio de frecuencia de muestreo")
            self.sr = new
            self.selection = None
            self._refresh_all()

    def change_sr(self):
        v = simpledialog.askinteger(APP_NAME, "Nueva frecuencia de muestreo (Hz):", initialvalue=self.sr,
                                    minvalue=4000, maxvalue=384000, parent=self.root)
        if v:
            if str(v) not in self.sr_combo["values"]:
                self.sr_combo.config(values=list(self.sr_combo["values"]) + [str(v)])
            self.sr_combo.set(str(v))
            self._on_sr_combo()

    # =====================================================================
    # Presets
    # =====================================================================
    def apply_preset(self, d, switch_tab=True):
        if d.get("type", "synth") == "synth":
            if d.get("synth") not in SYNTH_BY_NAME:
                raise ValueError(f"Método de síntesis desconocido: {d.get('synth')}")
            cls = SYNTH_BY_NAME[d["synth"]]
            self.synth_combo.set(d["synth"])
            self._on_synth_changed({**cls.defaults(), **d.get("params", {})})
            common = {p.key: p.default for p in COMMON_PARAMS}
            common.update(d.get("common", {}))
            self.common_panel.set_values(common)
            if switch_tab:
                self.nb.select(1)
            self._status(f"Sonido cargado: {d.get('title', d['synth'])}")
        elif d.get("type") == "chain":
            chain = []
            for c in d.get("chain", []):
                if c.get("name") in PROCESSOR_BY_NAME:
                    cls = PROCESSOR_BY_NAME[c["name"]]
                    chain.append({"name": c["name"], "params": {**cls.defaults(), **c.get("params", {})},
                                  "bypass": bool(c.get("bypass"))})
            self.chain = chain
            self.chain_sel = 0 if chain else None
            self._refresh_tree()
            if chain:
                self._on_chain_select()
            else:
                self._show_chain_empty()
            if switch_tab:
                self.nb.select(2)
            self._status(f"Cadena cargada: {d.get('title', '')}")
        else:
            raise ValueError("Archivo de preset no reconocido")

    def _preset_dialog(self, kind):
        """Pide nombre, categoría y descripción. Devuelve dict o None."""
        dlg = tk.Toplevel(self.root)
        dlg.title("Guardar preset")
        dlg.configure(background=COLORS["panel"])
        dlg.transient(self.root)
        dlg.resizable(False, False)
        fr = ttk.Frame(dlg, style="Panel.TFrame", padding=16)
        fr.pack(fill="both", expand=True)
        ttk.Label(fr, text="Guardar sonido" if kind == "synth" else "Guardar cadena de efectos",
                  style="Title.TLabel").grid(row=0, column=0, columnspan=2, sticky="w", pady=(0, 10))
        name = tk.StringVar(value="Mi sonido" if kind == "synth" else "Mi cadena")
        cats = [c for c in CATEGORY_ORDER if c != "Cadenas de efectos"]
        cat = tk.StringVar(value="Mis sonidos" if kind == "synth" else "Cadenas de efectos")
        ttk.Label(fr, text="Nombre").grid(row=1, column=0, sticky="w", pady=4)
        e = ttk.Entry(fr, textvariable=name, width=40)
        e.grid(row=1, column=1, sticky="ew", pady=4)
        if kind == "synth":
            ttk.Label(fr, text="Categoría").grid(row=2, column=0, sticky="w", pady=4)
            ttk.Combobox(fr, textvariable=cat, values=cats).grid(row=2, column=1, sticky="ew", pady=4)
        ttk.Label(fr, text="Descripción\n(qué esperar)").grid(row=3, column=0, sticky="nw", pady=4)
        txt = tk.Text(fr, width=40, height=5, background=COLORS["panel2"], foreground=COLORS["fg"],
                      insertbackground=COLORS["fg"], relief="flat", font=(FONT, 10), wrap="word")
        txt.grid(row=3, column=1, sticky="ew", pady=4)
        res = {}

        def ok():
            res.update(title=name.get().strip() or "Sin nombre", category=cat.get().strip() or "Mis sonidos",
                       description=txt.get("1.0", "end").strip())
            dlg.destroy()
        bf = ttk.Frame(fr, style="Panel.TFrame")
        bf.grid(row=4, column=0, columnspan=2, sticky="e", pady=(10, 0))
        ttk.Button(bf, text="Cancelar", command=dlg.destroy).pack(side="right")
        ttk.Button(bf, text="Guardar", style="Accent.TButton", command=ok).pack(side="right", padx=6)
        e.focus_set()
        e.select_range(0, "end")
        dlg.bind("<Return>", lambda ev: ok() if ev.widget is not txt else None)
        dlg.grab_set()
        self.root.wait_window(dlg)
        return res or None

    def _save_json(self, d):
        os.makedirs(PRESET_DIR, exist_ok=True)
        safe = re.sub(r'[\\/:*?"<>|]+', "-", d["title"]).strip() or "preset"
        prefix = "Cadena - " if d.get("type") == "chain" else ""
        path = os.path.join(PRESET_DIR, prefix + safe + ".json")
        if os.path.exists(path) and not messagebox.askyesno(APP_NAME, f"Ya existe «{safe}». ¿Reemplazarlo?"):
            return
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(d, fh, ensure_ascii=False, indent=2)
        self._refresh_library()
        self._status(f"Guardado en la biblioteca: {d['title']}")

    def save_synth_preset(self):
        info = self._preset_dialog("synth")
        if info:
            d = {"type": "synth", **info, "synth": self.synth_combo.get(),
                 "params": self.synth_panel.get_values(), "common": self.common_panel.get_values()}
            self._save_json(d)

    def save_chain(self):
        if not self.chain:
            return messagebox.showinfo(APP_NAME, "La cadena está vacía.")
        info = self._preset_dialog("chain")
        if info:
            info["category"] = "Cadenas de efectos"
            self._save_json({"type": "chain", **info, "chain": self.chain})

    def load_preset_file(self):
        f = filedialog.askopenfilename(initialdir=PRESET_DIR, filetypes=[("Preset JSON", "*.json")])
        if f:
            with open(f, encoding="utf-8") as fh:
                self.apply_preset(json.load(fh))

    def open_preset_folder(self):
        os.makedirs(PRESET_DIR, exist_ok=True)
        try:
            if sys.platform == "win32":
                os.startfile(PRESET_DIR)  # noqa
            elif sys.platform == "darwin":
                subprocess.Popen(["open", PRESET_DIR])
            else:
                subprocess.Popen(["xdg-open", PRESET_DIR])
        except Exception as ex:
            messagebox.showinfo(APP_NAME, f"Carpeta de presets:\n{PRESET_DIR}\n\n({ex})")

    # =====================================================================
    def show_help(self):
        txt = (
            "CÓMO SE USA\n"
            "1. Biblioteca: elige un sonido (doble clic lo reproduce) y lee qué puedes esperar de él.\n"
            "2. Síntesis: ajusta el sonido. En «Osciladores + filtro» puedes añadir, duplicar, silenciar o quitar\n"
            "   osciladores. Toca el piano (o las teclas A W S E D F…) para probarlo; activa «Escucha automática»\n"
            "   para oír cada cambio al instante.\n"
            "3. «Usar en el editor» lleva el sonido a la derecha (reemplazar, añadir al final, insertar o mezclar).\n"
            "4. Efectos: «+ Añadir efecto», ordénalos, desactívalos con On/Off, «Escuchar resultado» y\n"
            "   «Aplicar al audio» (a todo o solo a la selección). Todo se puede deshacer con Ctrl+Z.\n"
            "5. Archivo → Guardar: WAV, FLAC u OGG. Presets → guarda tus sonidos y cadenas en la biblioteca.\n\n"
            "NOTAS\n"
            "  A4 · C4 E4 G4 · C4:0.5 R:0.25 G4:1 (segundos; R = silencio) · C4+E4+G4:2 (acorde)\n"
            "  Do4 Re4 Mi4 (solfeo) · 220 330:0.5 (Hz)\n\n"
            "EDITOR\n"
            "  Arrastra para seleccionar · clic para mover el cursor · rueda = zoom · Mayús+rueda = desplazar\n\n"
            "ATAJOS\n"
            "  Espacio reproducir/detener · Ctrl+Z / Ctrl+Y deshacer/rehacer · Ctrl+A seleccionar todo\n"
            "  Ctrl+C / X / V copiar/cortar/pegar · Supr borrar selección · Esc detener y quitar selección\n"
            "  En los deslizadores: rueda = ajuste fino, doble clic = valor por defecto; puedes escribir el valor.\n"
            "  Pasa el ratón sobre los nombres de los parámetros para ver qué hacen."
        )
        w = tk.Toplevel(self.root)
        w.title("Guía rápida")
        w.configure(background=COLORS["panel"])
        t = tk.Text(w, width=100, height=30, background=COLORS["panel"], foreground=COLORS["fg"],
                    relief="flat", font=(MONO, 10), padx=16, pady=14)
        t.insert("1.0", txt)
        t.config(state="disabled")
        t.pack(fill="both", expand=True)


def main():
    if sys.platform == "win32":  # nitidez en pantallas de alta resolución
        try:
            import ctypes
            ctypes.windll.shcore.SetProcessDpiAwareness(1)
        except Exception:
            pass
    root = tk.Tk()
    app = App(root)
    app.nb.select(0)
    if sys.platform == "win32":
        try:
            root.state("zoomed")  # ventana maximizada
        except tk.TclError:
            pass
    root.mainloop()
