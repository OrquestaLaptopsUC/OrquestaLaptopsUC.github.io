"""Tema oscuro para ttk y matplotlib."""
import sys
from tkinter import ttk

COLORS = {
    "bg": "#14161b",        # fondo general
    "panel": "#1c1f26",     # paneles
    "panel2": "#252a33",    # campos, tarjetas
    "card": "#20242c",
    "hover": "#2e3440",
    "fg": "#e8eaf0",
    "muted": "#98a1b3",
    "dim": "#6b7385",
    "accent": "#5ab4ff",
    "accent_dk": "#2f8ad8",
    "accent2": "#ff9154",
    "ok": "#4cd6a0",
    "warn": "#ffcc4d",
    "danger": "#ff6b6b",
    "border": "#343a46",
    "tip_bg": "#2b303b",
    "wave": "#5ab4ff",
    "wave2": "#ff9154",
    "sel": "#ffd166",
}

# un color por oscilador / categoría
PALETTE = ["#5ab4ff", "#ff9154", "#4cd6a0", "#c792ea", "#ffd166", "#ff6b9a", "#7fdbca", "#f78c6c"]

FONT = "Segoe UI" if sys.platform == "win32" else "DejaVu Sans"
MONO = "Consolas" if sys.platform == "win32" else "DejaVu Sans Mono"


def apply_theme(root):
    c = COLORS
    root.configure(background=c["bg"])
    st = ttk.Style(root)
    st.theme_use("clam")
    base = dict(background=c["panel"], foreground=c["fg"], fieldbackground=c["panel2"],
                bordercolor=c["border"], lightcolor=c["panel2"], darkcolor=c["panel"],
                troughcolor=c["bg"], arrowcolor=c["fg"], insertcolor=c["fg"],
                selectbackground=c["accent"], selectforeground="#000000")
    st.configure(".", **base, font=(FONT, 10))
    for name, bg in (("TFrame", c["panel"]), ("Panel.TFrame", c["panel"]), ("Bg.TFrame", c["bg"]),
                     ("Toolbar.TFrame", c["bg"]), ("Card.TFrame", c["card"]), ("Field.TFrame", c["panel2"])):
        st.configure(name, background=bg)
    st.configure("Card.TFrame", bordercolor=c["border"], relief="solid", borderwidth=1)

    def lab(name, bg, fg, font=None, **kw):
        st.configure(name, background=bg, foreground=fg, **({"font": font} if font else {}), **kw)
    lab("TLabel", c["panel"], c["fg"])
    lab("Panel.TLabel", c["panel"], c["fg"])
    lab("Unit.TLabel", c["panel"], c["dim"], (FONT, 8))
    lab("Muted.TLabel", c["panel"], c["muted"], (FONT, 9))
    lab("Hint.TLabel", c["panel"], c["dim"], (FONT, 9, "italic"))
    lab("Group.TLabel", c["panel"], c["accent"], (FONT, 10, "bold"))
    lab("Title.TLabel", c["panel"], c["fg"], (FONT, 13, "bold"))
    lab("Subtitle.TLabel", c["panel"], c["fg"], (FONT, 11, "bold"))
    lab("Tags.TLabel", c["panel"], c["accent2"], (FONT, 9, "bold"))
    lab("Status.TLabel", c["bg"], c["muted"])
    lab("Toolbar.TLabel", c["bg"], c["fg"])
    lab("ToolbarMuted.TLabel", c["bg"], c["muted"], (FONT, 9))
    lab("Brand.TLabel", c["bg"], c["accent"], (FONT, 13, "bold"))
    lab("Time.TLabel", c["bg"], c["ok"], (MONO, 14, "bold"))
    lab("Peak.TLabel", c["bg"], c["muted"], (MONO, 9))
    lab("Card.TLabel", c["card"], c["fg"])
    lab("CardMuted.TLabel", c["card"], c["muted"], (FONT, 9))
    lab("CardUnit.TLabel", c["card"], c["dim"], (FONT, 8))
    lab("CardTitle.TLabel", c["card"], c["fg"], (FONT, 10, "bold"))
    lab("Section.TLabel", c["panel2"], c["fg"], (FONT, 10, "bold"), padding=(8, 5))
    lab("InfoTitle.TLabel", c["card"], c["fg"], (FONT, 11, "bold"))
    lab("InfoTags.TLabel", c["card"], c["accent2"], (FONT, 9, "bold"))
    lab("InfoText.TLabel", c["card"], c["fg"], (FONT, 9))
    lab("InfoTip.TLabel", c["card"], c["muted"], (FONT, 9, "italic"))

    # botones
    st.configure("TButton", background=c["panel2"], foreground=c["fg"], padding=(10, 5), relief="flat",
                 bordercolor=c["border"], focuscolor=c["panel2"])
    st.map("TButton", background=[("disabled", c["panel"]), ("pressed", c["accent_dk"]), ("active", c["hover"])],
           foreground=[("disabled", c["dim"])])
    st.configure("Accent.TButton", background=c["accent"], foreground="#06121d", font=(FONT, 10, "bold"),
                 bordercolor=c["accent"])
    st.map("Accent.TButton", background=[("active", "#86c9ff"), ("pressed", c["accent_dk"])])
    st.configure("Warm.TButton", background=c["accent2"], foreground="#1d0c03", font=(FONT, 10, "bold"),
                 bordercolor=c["accent2"])
    st.map("Warm.TButton", background=[("active", "#ffb080"), ("pressed", "#e0703a")])
    st.configure("Play.TButton", background=c["ok"], foreground="#04140d", font=(FONT, 11, "bold"),
                 padding=(14, 5), bordercolor=c["ok"])
    st.map("Play.TButton", background=[("active", "#7ee8c0"), ("pressed", "#2fb383")])
    st.configure("Tool.TButton", background=c["bg"], foreground=c["fg"], padding=(8, 4), bordercolor=c["bg"])
    st.map("Tool.TButton", background=[("active", c["panel2"]), ("pressed", c["hover"])])
    st.configure("Small.TButton", padding=(6, 2), font=(FONT, 9))
    st.configure("CardSmall.TButton", background=c["card"], foreground=c["muted"], padding=(6, 1), font=(FONT, 9),
                 bordercolor=c["card"])
    st.map("CardSmall.TButton", background=[("active", c["hover"])], foreground=[("active", c["fg"])])
    st.configure("Danger.TButton", background=c["card"], foreground=c["danger"], padding=(6, 1), font=(FONT, 9),
                 bordercolor=c["card"])
    st.map("Danger.TButton", background=[("active", "#3a2426")])
    st.configure("Dashed.TButton", background=c["panel"], foreground=c["accent"], font=(FONT, 10, "bold"),
                 bordercolor=c["accent_dk"], padding=(10, 6))
    st.map("Dashed.TButton", background=[("active", c["panel2"])])
    st.configure("TMenubutton", background=c["panel2"], foreground=c["fg"], padding=(10, 5), arrowcolor=c["fg"],
                 bordercolor=c["border"])
    st.map("TMenubutton", background=[("active", c["hover"])])
    st.configure("Warm.TMenubutton", background=c["accent2"], foreground="#1d0c03", font=(FONT, 10, "bold"),
                 arrowcolor="#1d0c03", bordercolor=c["accent2"])
    st.map("Warm.TMenubutton", background=[("active", "#ffb080")])
    st.configure("Accent.TMenubutton", background=c["accent"], foreground="#06121d", font=(FONT, 10, "bold"),
                 arrowcolor="#06121d", bordercolor=c["accent"])
    st.map("Accent.TMenubutton", background=[("active", "#86c9ff")])

    # selección segmentada (radiobuttons con aspecto de botón)
    st.configure("Seg.Toolbutton", background=c["panel2"], foreground=c["muted"], padding=(10, 3),
                 bordercolor=c["border"], font=(FONT, 9))
    st.map("Seg.Toolbutton", background=[("selected", c["accent"]), ("active", c["hover"])],
           foreground=[("selected", "#06121d"), ("active", c["fg"])])
    st.configure("Toggle.Toolbutton", background=c["panel2"], foreground=c["muted"], padding=(8, 4),
                 bordercolor=c["border"])
    st.map("Toggle.Toolbutton", background=[("selected", c["ok"]), ("active", c["hover"])],
           foreground=[("selected", "#04140d")])
    st.configure("TbToggle.Toolbutton", background=c["bg"], foreground=c["muted"], padding=(8, 4),
                 bordercolor=c["border"])
    st.map("TbToggle.Toolbutton", background=[("selected", c["accent2"]), ("active", c["panel2"])],
           foreground=[("selected", "#1d0c03")])

    for name, bg in (("TCheckbutton", c["panel"]), ("Panel.TCheckbutton", c["panel"]),
                     ("Card.TCheckbutton", c["card"]), ("Toolbar.TCheckbutton", c["bg"])):
        st.configure(name, background=bg, foreground=c["fg"], indicatorbackground=c["panel2"],
                     indicatorforeground=c["accent"])
        st.map(name, background=[("active", bg)], indicatorbackground=[("selected", c["panel2"])])
    st.configure("TRadiobutton", background=c["panel"], foreground=c["fg"], indicatorbackground=c["panel2"])
    st.map("TRadiobutton", background=[("active", c["panel"])])
    st.configure("TEntry", fieldbackground=c["panel2"], foreground=c["fg"], padding=3)
    st.configure("Search.TEntry", fieldbackground=c["panel2"], foreground=c["fg"], padding=5)
    st.configure("TSpinbox", fieldbackground=c["panel2"], foreground=c["fg"], arrowsize=11, padding=2)
    st.configure("TCombobox", fieldbackground=c["panel2"], foreground=c["fg"], arrowsize=13, padding=3)
    st.map("TCombobox", fieldbackground=[("readonly", c["panel2"])], foreground=[("readonly", c["fg"])],
           selectbackground=[("readonly", c["panel2"])], selectforeground=[("readonly", c["fg"])],
           background=[("active", c["hover"])])
    root.option_add("*TCombobox*Listbox.background", c["panel2"])
    root.option_add("*TCombobox*Listbox.foreground", c["fg"])
    root.option_add("*TCombobox*Listbox.selectBackground", c["accent"])
    root.option_add("*TCombobox*Listbox.selectForeground", "#000")
    root.option_add("*TCombobox*Listbox.font", (FONT, 10))
    root.option_add("*Menu.background", c["panel2"])
    root.option_add("*Menu.foreground", c["fg"])
    root.option_add("*Menu.activeBackground", c["accent"])
    root.option_add("*Menu.activeForeground", "#000")
    root.option_add("*Menu.font", (FONT, 10))
    root.option_add("*Menu.relief", "flat")
    st.configure("Horizontal.TScale", background=c["accent"], troughcolor=c["bg"], sliderthickness=14,
                 bordercolor=c["border"], lightcolor=c["accent"], darkcolor=c["accent_dk"])
    st.configure("TNotebook", background=c["bg"], borderwidth=0, tabmargins=(0, 4, 0, 0))
    st.configure("TNotebook.Tab", background=c["panel2"], foreground=c["muted"], padding=(16, 7),
                 font=(FONT, 10, "bold"), bordercolor=c["border"])
    st.map("TNotebook.Tab", background=[("selected", c["panel"]), ("active", c["hover"])],
           foreground=[("selected", c["accent"]), ("active", c["fg"])])
    st.configure("Treeview", background=c["panel2"], fieldbackground=c["panel2"], foreground=c["fg"],
                 rowheight=26, bordercolor=c["border"], font=(FONT, 10))
    st.map("Treeview", background=[("selected", c["accent"])], foreground=[("selected", "#000")])
    st.configure("Treeview.Heading", background=c["panel"], foreground=c["muted"], font=(FONT, 9, "bold"),
                 relief="flat")
    st.configure("TPanedwindow", background=c["bg"])
    st.configure("Sash", sashthickness=6, gripcount=0, background=c["bg"])
    st.configure("Horizontal.TProgressbar", background=c["accent"], troughcolor=c["panel2"],
                 bordercolor=c["bg"], lightcolor=c["accent"], darkcolor=c["accent"])
    st.configure("TSeparator", background=c["border"])
    st.configure("Vertical.TScrollbar", background=c["panel2"], troughcolor=c["panel"], arrowcolor=c["muted"],
                 bordercolor=c["panel"])
    st.map("Vertical.TScrollbar", background=[("active", c["hover"])])
    return st


def mpl_style():
    c = COLORS
    return {
        "figure.facecolor": c["bg"], "axes.facecolor": "#0f1116", "axes.edgecolor": c["border"],
        "axes.labelcolor": c["muted"], "xtick.color": c["muted"], "ytick.color": c["muted"],
        "text.color": c["fg"], "grid.color": "#262b35", "font.size": 8,
        "axes.titlesize": 9, "axes.titlecolor": c["fg"], "axes.spines.top": False, "axes.spines.right": False,
    }
