# Estudio de Síntesis

Programa de escritorio en Python para **sintetizar sonidos**, **cargar audio** y procesarlo con una
**cadena de filtros y efectos** totalmente configurable, con forma de onda, espectrograma, espectro
y respuesta en frecuencia de los filtros.

## Instalación (Windows)

1. Doble clic en **`instalar.bat`**. Crea un entorno virtual (`.venv`) e instala:
   `numpy`, `scipy`, `matplotlib`, `sounddevice`, `soundfile` y `numba` (opcional, acelera los filtros).
   Si no tienes Python, intenta instalarlo con `winget`; si no, descárgalo de python.org
   (marca *Add python.exe to PATH*).
2. Doble clic en **`ejecutar.bat`** para abrir el programa
   (`ejecutar_con_consola.bat` hace lo mismo pero muestra los mensajes de error).

Instalación manual: `python -m pip install -r requirements.txt numba` y luego `python main.py`.

## Cómo se usa

1. **Biblioteca**: elige un sonido (doble clic para escucharlo). Cada uno trae una descripción de
   qué puedes esperar de él. Hay un buscador («campana», «pad», «FM»…).
2. **Síntesis**: ajusta el sonido. Cada método muestra su carácter, para qué es ideal y un consejo.
   En «Osciladores + filtro» puedes **añadir, duplicar, silenciar o quitar osciladores** (hasta 8),
   cada uno con forma de onda, nivel, paneo, octava, semitonos, afinación fina, voces de unísono y apertura estéreo.
   Pruébalo con el **piano** (clic o teclas A W S E D F T G Y H U J K, Z/X cambian de octava) o activa
   **Escucha automática** para oír cada cambio.
3. **Usar en el editor** lleva el sonido a la derecha (reemplazar, añadir al final, insertar o mezclar).
4. **Efectos**: «+ Añadir efecto», ordénalos, activa/desactiva, escucha y aplica (a todo o a la selección).
5. Guarda con Archivo → Guardar. Tus sonidos y cadenas se guardan en la biblioteca (Presets).

## Métodos de síntesis

| Método | Qué es |
|---|---|
| Osciladores + filtro (sustractiva) | Banco de 1 a 8 osciladores (sierra, cuadrada, pulso/PWM, triangular, seno, ruido blanco/rosa) con unísono y paneo propios → filtro SVF 12/24 dB o escalera Moog, con envolvente ADSR y LFO |
| Aditiva | Suma de parciales: espectros sierra/cuadrada/triangular/órgano, campana de Risset, amplitudes personalizadas, inarmonicidad, decaimiento por parcial |
| FM | Chowning/DX7 (modulación de fase) con 5 algoritmos de 2-3 operadores, realimentación y envolvente de índice |
| AM / Anillo | Modulación de amplitud y modulación en anillo, razón o frecuencia fija |
| Tabla de ondas | Morphing entre tablas (básica, armónicos, formantes vocales, PWM, aleatoria) modulado por envolvente y LFO |
| Granular | Nube de granos desde el audio cargado (o la selección) o fuentes internas: tamaño, densidad, posición, velocidad de lectura, dispersión, transposición, granos invertidos, ventanas |
| Karplus-Strong | Cuerda pulsada / tambor por modelado físico, con afinación fraccional y posición de pulsación |
| Distorsión de fase | Estilo Casio CZ, incluidas las formas resonantes |
| Waveshaping | Polinomios de Chebyshev (armónicos exactos), tanh, plegado, cúbica… |
| Formantes | Fuente-filtro (pulso glotal de Rosenberg + 5 formantes) con transición entre vocales |
| Ruido | Blanco, rosa, marrón, azul, violeta, con banda afinada que sigue la nota |

Todos comparten: **secuencia de notas** (`C4 E4 G4`, `C4:0.5 R:0.25 G4:1`, acordes `C4+E4+G4:2`,
solfeo `Do4`, o Hz `220`), **ADSR** con curvatura, **vibrato**, **barrido de tono**, transposición,
**voces al unísono** con desafinación y **ancho estéreo**.

## Filtros

IIR clásico (Butterworth, Chebyshev I/II, Elíptico, Bessel; paso bajo/alto/banda/rechaza banda,
orden 1-16, fase cero), Biquad RBJ (pico, estantes, notch, paso todo…), ecualizador paramétrico de 5 bandas,
FIR por ventanas (Hamming, Hann, Blackman, Kaiser…), filtro resonante SVF / Moog con modulación por LFO,
seguidor de envolvente (auto-wah) o barrido, filtro peine y filtro de formantes vocales.

## Efectos

Ganancia/normalizar, fundidos, invertir, polaridad, DC, mono/estéreo, paneo y ancho M/S ·
Distorsión (8 tipos), bitcrusher · Compresor/limitador, puerta de ruido ·
Delay (ping-pong), reverb algorítmica Freeverb, reverb por convolución (con IR propia o sintética) ·
Chorus, flanger, phaser, trémolo/auto-paneo, modulador en anillo, vibrato ·
Estiramiento temporal y transposición por vocoder de fase · Procesos espectrales
(robotización, susurro, puerta espectral, desenfoque, congelado, inversión, cuantización).

## Edición

Selección con el ratón, cursor, copiar/cortar/pegar (también mezclando), recortar, borrar, silenciar,
insertar silencio, insertar/mezclar otro archivo, remuestrear, deshacer/rehacer (40 niveles).
Exporta a WAV 16/24/32 bits, FLAC u OGG. Guarda y carga **presets** de sonidos y **cadenas** (JSON en
`presets/`, ya incluye 24 sonidos y 8 cadenas de ejemplo, con descripción).

## Ampliarlo

Cada sintetizador/efecto es una clase con una lista de `Param`; la interfaz se genera sola.
Para añadir uno nuevo, crea una clase en `dsp/synths.py` o `dsp/effects.py` y agrégala a `SYNTHS`
o `EFFECTS`.

```
main.py            punto de entrada
audio_io.py        carga, guardado y reproducción
dsp/core.py        parámetros, osciladores, ADSR, LFO, notas
dsp/kernels.py     bucles DSP (acelerados con numba si está instalado)
dsp/synths.py      métodos de síntesis y motor de notas
dsp/filters.py     filtros
dsp/effects.py     efectos y cadena de procesamiento
gui/               interfaz (tkinter + matplotlib)
presets/           presets JSON
```
