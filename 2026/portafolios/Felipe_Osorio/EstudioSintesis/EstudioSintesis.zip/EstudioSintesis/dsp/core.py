"""
Utilidades DSP básicas: parámetros, osciladores, envolventes, notas y aceleración opcional.
El audio se representa siempre como np.ndarray float64 de forma (muestras, canales).
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Callable, Optional

import numpy as np

# ---------------------------------------------------------------------------
# Aceleración opcional con numba (si no está instalada, se usa Python puro)
# ---------------------------------------------------------------------------
try:  # pragma: no cover
    from numba import njit as _njit
    HAS_NUMBA = True
except Exception:  # pragma: no cover
    _njit = None
    HAS_NUMBA = False


def jit(fn):
    """
    Compila con numba si está disponible. Si la compilación falla por cualquier motivo,
    se usa automáticamente la versión en Python puro (más lenta pero equivalente).
    """
    if _njit is None:
        return fn
    try:
        compiled = _njit(cache=True, fastmath=True)(fn)
    except Exception:
        return fn
    state = {"f": compiled}

    def wrapper(*args):
        f = state["f"]
        if f is fn:
            return fn(*args)
        try:
            return f(*args)
        except Exception as ex:
            if type(ex).__module__.split(".")[0] == "numba":
                print(f"[numba] {fn.__name__}: se usa Python puro ({type(ex).__name__})")
                state["f"] = fn
                return fn(*args)
            raise

    wrapper.__name__ = fn.__name__
    wrapper.py_func = fn
    return wrapper


TWO_PI = 2.0 * np.pi


# ---------------------------------------------------------------------------
# Definición de parámetros (la interfaz se genera automáticamente a partir de esto)
# ---------------------------------------------------------------------------
@dataclass
class Param:
    key: str
    label: str
    kind: str = "float"          # float | int | choice | bool | text | file
    default: Any = 0.0
    min: float = 0.0
    max: float = 1.0
    log: bool = False            # deslizador logarítmico (frecuencias, tiempos)
    choices: list = field(default_factory=list)
    unit: str = ""
    help: str = ""
    group: str = ""              # agrupa visualmente parámetros


class Processor:
    """Clase base para sintetizadores y efectos."""
    name: str = "Procesador"
    category: str = "General"
    description: str = ""
    params: list[Param] = []

    @classmethod
    def defaults(cls) -> dict:
        return {p.key: p.default for p in cls.params}

    @classmethod
    def coerce(cls, values: dict) -> dict:
        out = cls.defaults()
        for p in cls.params:
            if p.key not in values:
                continue
            v = values[p.key]
            try:
                if p.kind == "float":
                    v = float(v)
                elif p.kind == "int":
                    v = int(round(float(v)))
                elif p.kind == "bool":
                    v = bool(v) if not isinstance(v, str) else v.lower() in ("1", "true", "sí", "si", "yes")
                elif p.kind == "choice":
                    v = v if v in p.choices else p.default
                elif p.kind == "oscillators":
                    v = coerce_oscillators(v)
                else:
                    v = str(v)
            except (TypeError, ValueError):
                v = p.default
            out[p.key] = v
        return out


# ---------------------------------------------------------------------------
# Notas musicales
# ---------------------------------------------------------------------------
_NOTE_BASE = {"C": 0, "D": 2, "E": 4, "F": 5, "G": 7, "A": 9, "B": 11,
              "DO": 0, "RE": 2, "MI": 4, "FA": 5, "SOL": 7, "LA": 9, "SI": 11}
_NOTE_RE = re.compile(r"^(DO|RE|MI|FA|SOL|LA|SI|[A-G])([#B]*)(-?\d+)$", re.IGNORECASE)


def note_to_freq(token: str, a4: float = 440.0) -> float:
    """'A4' -> 440, 'C#3', 'Eb5', 'Sol4', o un número en Hz ('220' / '220hz')."""
    t = token.strip()
    try:
        return float(t.lower().replace("hz", ""))
    except ValueError:
        pass
    m = _NOTE_RE.match(t.upper())
    if not m:
        raise ValueError(f"Nota no reconocida: '{token}'")
    name, acc, octv = m.groups()
    semi = _NOTE_BASE[name.upper()]
    semi += acc.count("#") - acc.count("B")
    midi = 12 * (int(octv) + 1) + semi
    return a4 * 2.0 ** ((midi - 69) / 12.0)


def parse_sequence(text: str, default_dur: float) -> list[tuple[list[float], float]]:
    """
    Secuencia de notas separada por espacios o comas.
      'C4 E4 G4'              -> tres notas de duración por defecto
      'C4:0.5 E4:0.25 R:0.5'  -> duración en segundos por nota, R = silencio
      'C4+E4+G4:2'            -> acorde
      '440 660:1'             -> frecuencias en Hz
    Devuelve lista de (frecuencias, duración). Lista vacía de frecuencias = silencio.
    """
    events = []
    for tok in re.split(r"[\s,;]+", text.strip()):
        if not tok:
            continue
        if ":" in tok:
            n, d = tok.split(":", 1)
            dur = float(d)
        else:
            n, dur = tok, default_dur
        if n.upper() in ("R", "-", "_", "S"):
            events.append(([], dur))
        else:
            events.append(([note_to_freq(x) for x in n.split("+") if x], dur))
    return events


# ---------------------------------------------------------------------------
# Osciladores (con PolyBLEP para reducir aliasing en formas con discontinuidades)
# ---------------------------------------------------------------------------
def phase_from_freq(freq, n: int, sr: int, phase0: float = 0.0) -> np.ndarray:
    """Fase normalizada (ciclos, 0..1) a partir de una frecuencia constante o un array."""
    f = np.broadcast_to(np.asarray(freq, dtype=np.float64), (n,))
    ph = phase0 + np.cumsum(f) / sr
    ph = np.concatenate(([phase0], ph[:-1]))
    return ph


def _polyblep(t: np.ndarray, dt: np.ndarray) -> np.ndarray:
    dt = np.clip(dt, 1e-9, 0.5)
    out = np.zeros_like(t)
    m1 = t < dt
    x = t[m1] / dt[m1]
    out[m1] = x + x - x * x - 1.0
    m2 = t > 1.0 - dt
    x = (t[m2] - 1.0) / dt[m2]
    out[m2] = x * x + x + x + 1.0
    return out


WAVEFORMS = ["seno", "triangular", "sierra", "cuadrada", "pulso", "ruido blanco"]
OSC_SHAPES = ["sierra", "cuadrada", "pulso", "triangular", "seno", "ruido blanco", "ruido rosa"]

# Qué aporta cada forma de onda (se muestra en la interfaz)
SHAPE_INFO = {
    "seno": "Tono puro, sin armónicos. Suave y redondo; ideal como sub-grave o para reforzar la fundamental.",
    "triangular": "Suave y aflautado: pocos armónicos (solo impares, muy débiles).",
    "sierra": "Brillante y rica: todos los armónicos. La base de pads, cuerdas, metales y leads.",
    "cuadrada": "Hueca y 'de madera' (clarinete, videojuegos): solo armónicos impares.",
    "pulso": "Nasal; el timbre cambia con el ancho de pulso. Con PWM suena animado, tipo coro.",
    "ruido blanco": "Soplo brillante sin altura: aire, ataque percusivo, viento.",
    "ruido rosa": "Soplo más oscuro y natural que el blanco (como lluvia o mar).",
}

OSC_DEFAULT = {"shape": "sierra", "level": 0.8, "octave": 0, "semi": 0, "cents": 0.0, "pan": 0.0,
               "pw": 0.5, "voices": 1, "spread": 15.0, "width": 0.5, "mute": False}
MAX_OSCILLATORS = 8


def coerce_oscillators(v) -> list:
    """Normaliza una lista de osciladores (lista de dicts) completando valores por defecto."""
    out = []
    if not isinstance(v, (list, tuple)):
        return [dict(OSC_DEFAULT)]
    for o in list(v)[:MAX_OSCILLATORS]:
        if not isinstance(o, dict):
            continue
        d = dict(OSC_DEFAULT)
        for k, dv in OSC_DEFAULT.items():
            if k in o:
                try:
                    d[k] = type(dv)(o[k]) if not isinstance(dv, bool) else bool(o[k])
                except (TypeError, ValueError):
                    pass
        if d["shape"] not in OSC_SHAPES:
            d["shape"] = "sierra"
        d["voices"] = int(min(max(d["voices"], 1), 9))
        out.append(d)
    return out


def oscillator(shape: str, freq, n: int, sr: int, pw: float | np.ndarray = 0.5,
               phase0: float = 0.0, bandlimit: bool = True, rng=None) -> np.ndarray:
    if shape == "ruido blanco":
        rng = rng or np.random.default_rng()
        return rng.uniform(-1, 1, n)
    if shape == "ruido rosa":
        return colored_noise("rosa", n, rng)
    ph = phase_from_freq(freq, n, sr, phase0)
    t = ph % 1.0
    dt = np.abs(np.broadcast_to(np.asarray(freq, dtype=np.float64), (n,))) / sr
    if shape == "seno":
        return np.sin(TWO_PI * t)
    if shape == "sierra":
        y = 2.0 * t - 1.0
        if bandlimit:
            y -= _polyblep(t, dt)
        return y
    if shape in ("cuadrada", "pulso"):
        w = 0.5 if shape == "cuadrada" else np.clip(pw, 0.01, 0.99)
        w = np.broadcast_to(np.asarray(w, dtype=np.float64), (n,))
        y = np.where(t < w, 1.0, -1.0)
        if bandlimit:
            y = y + _polyblep(t, dt) - _polyblep((t - w) % 1.0, dt)
        return y
    if shape == "triangular":
        return 2.0 * np.abs(2.0 * t - 1.0) - 1.0
    raise ValueError(shape)


def colored_noise(color: str, n: int, rng=None) -> np.ndarray:
    rng = rng or np.random.default_rng()
    white = rng.standard_normal(n)
    if color == "blanco":
        y = white
    else:
        spec = np.fft.rfft(white)
        f = np.fft.rfftfreq(n)
        f[0] = f[1] if n > 1 else 1.0
        if color == "rosa":
            spec /= np.sqrt(f)
        elif color == "marrón":
            spec /= f
        elif color == "azul":
            spec *= np.sqrt(f)
        elif color == "violeta":
            spec *= f
        y = np.fft.irfft(spec, n)
    y = y - np.mean(y)
    peak = np.max(np.abs(y)) or 1.0
    return y / peak


# ---------------------------------------------------------------------------
# Envolventes y LFO
# ---------------------------------------------------------------------------
def adsr(n: int, sr: int, a: float, d: float, s: float, r: float, curve: float = 1.0) -> np.ndarray:
    """ADSR donde la fase de release ocupa el final de las n muestras."""
    a_n = int(max(a, 0) * sr)
    d_n = int(max(d, 0) * sr)
    r_n = min(int(max(r, 0) * sr), n)
    hold = max(n - r_n, 0)
    env = np.full(n, s, dtype=np.float64)
    idx = 0
    if a_n > 0:
        k = min(a_n, hold)
        env[:k] = (np.arange(k) / a_n) ** curve
        idx = k
    if d_n > 0 and idx < hold:
        k = min(d_n, hold - idx)
        x = np.arange(k) / d_n
        env[idx:idx + k] = 1.0 - (1.0 - s) * (x ** (1.0 / curve) if curve != 1 else x)
        idx += k
    if hold < n:
        level = env[hold - 1] if hold > 0 else (1.0 if a_n == 0 else 0.0)
        x = np.arange(n - hold) / max(r_n, 1)
        env[hold:] = level * (1.0 - x) ** curve
    return env


def lfo(shape: str, rate: float, n: int, sr: int, phase0: float = 0.0) -> np.ndarray:
    """LFO bipolar -1..1."""
    if shape == "aleatorio (S&H)":
        step = max(int(sr / max(rate, 1e-3)), 1)
        vals = np.random.default_rng(1).uniform(-1, 1, n // step + 2)
        return np.repeat(vals, step)[:n]
    return oscillator(shape, rate, n, sr, phase0=phase0, bandlimit=False)


LFO_SHAPES = ["seno", "triangular", "sierra", "cuadrada", "aleatorio (S&H)"]


# ---------------------------------------------------------------------------
# Utilidades de buffer
# ---------------------------------------------------------------------------
def as_2d(x: np.ndarray) -> np.ndarray:
    x = np.asarray(x, dtype=np.float64)
    return x[:, None] if x.ndim == 1 else x


def per_channel(fn: Callable[[np.ndarray, int], np.ndarray]):
    """Decorador: aplica una función mono a cada canal."""
    def wrapper(x: np.ndarray, ch_index: Optional[int] = None):
        x = as_2d(x)
        cols = [fn(x[:, c], c) for c in range(x.shape[1])]
        m = max(len(c) for c in cols)
        cols = [np.pad(c, (0, m - len(c))) for c in cols]
        return np.stack(cols, axis=1)
    return wrapper


def db_to_lin(db: float) -> float:
    return 10.0 ** (db / 20.0)


def lin_to_db(x):
    return 20.0 * np.log10(np.maximum(np.abs(x), 1e-12))


def mix_to_length(a: np.ndarray, b: np.ndarray, gain_b: float = 1.0) -> np.ndarray:
    a, b = as_2d(a), as_2d(b)
    ch = max(a.shape[1], b.shape[1])
    if a.shape[1] < ch:
        a = np.repeat(a, ch, axis=1)
    if b.shape[1] < ch:
        b = np.repeat(b, ch, axis=1)
    n = max(len(a), len(b))
    out = np.zeros((n, ch))
    out[:len(a)] += a
    out[:len(b)] += gain_b * b
    return out
