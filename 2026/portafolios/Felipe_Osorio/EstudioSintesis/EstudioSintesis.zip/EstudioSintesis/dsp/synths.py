"""
Métodos de síntesis. Cada sintetizador define sus parámetros (Param) y un método
render(freq, n, sr, p, ctx) que devuelve un array mono de n muestras.

`freq` es un array de n valores en Hz (ya incluye vibrato del motor común).
`ctx` es un diccionario con información adicional (p.ej. el audio actual para granular).
"""
from __future__ import annotations

import numpy as np
from numpy.polynomial import chebyshev as C
from scipy import signal

from .core import (Param, Processor, WAVEFORMS, LFO_SHAPES, TWO_PI, adsr, colored_noise, OSC_DEFAULT,
                   coerce_oscillators,
                   lfo, oscillator, phase_from_freq, parse_sequence, as_2d)
from . import kernels as K

# Formantes vocales (F1..F5 Hz, anchos de banda Hz, ganancias dB) - voz de bajo/soprano simplificadas
FORMANTS = {
    "a": ([800, 1150, 2900, 3900, 4950], [80, 90, 120, 130, 140], [0, -6, -32, -20, -50]),
    "e": ([400, 1600, 2700, 3300, 4950], [60, 80, 120, 150, 200], [0, -24, -30, -35, -60]),
    "i": ([350, 1700, 2700, 3700, 4950], [50, 100, 120, 150, 200], [0, -20, -30, -36, -60]),
    "o": ([450, 800, 2830, 3500, 4950], [70, 80, 100, 130, 135], [0, -9, -16, -28, -55]),
    "u": ([325, 700, 2530, 3500, 4950], [50, 60, 170, 180, 200], [0, -12, -30, -40, -64]),
}
VOWELS = list(FORMANTS.keys())


def _env_decay(n, sr, decay_s, floor):
    """Envolvente exponencial de 1 a `floor` con constante de tiempo decay_s."""
    t = np.arange(n) / sr
    return floor + (1.0 - floor) * np.exp(-t / max(decay_s, 1e-4))


# ===========================================================================
class Additive(Processor):
    name = "Aditiva"
    category = "Síntesis"
    description = ("Suma de parciales senoidales (Fourier). Controla número de armónicos, "
                   "espectro, inarmonicidad y el decaimiento independiente de cada parcial.")
    params = [
        Param("spectrum", "Espectro", "choice", "sierra (1/n)",
              choices=["sierra (1/n)", "cuadrada (impares 1/n)", "triangular (impares 1/n²)",
                       "órgano (1/n²)", "campana (Risset)", "todos iguales", "personalizado"]),
        Param("n_harm", "Nº de parciales", "int", 16, 1, 128),
        Param("custom", "Amplitudes personalizadas", "text", "1 0.5 0.33 0.25 0.2 0.16",
              help="Amplitud de cada armónico separada por espacios (espectro 'personalizado')"),
        Param("inharm", "Inarmonicidad (B)", "float", 0.0, 0.0, 0.01,
              help="f_n = n·f0·√(1+B·n²), como en cuerdas de piano"),
        Param("tilt", "Brillo (inclinación dB/oct)", "float", 0.0, -12.0, 12.0, unit="dB/oct"),
        Param("partial_decay", "Decaimiento de agudos", "float", 0.0, 0.0, 20.0,
              help="Los parciales altos decaen más rápido (0 = sin efecto)"),
        Param("random_phase", "Fases aleatorias", "bool", False),
        Param("detune", "Desafinación aleatoria de parciales", "float", 0.0, 0.0, 50.0, unit="cents"),
    ]

    @staticmethod
    def render(freq, n, sr, p, ctx):
        rng = np.random.default_rng(7)
        f0 = freq
        t = np.arange(n) / sr
        spec = p["spectrum"]
        out = np.zeros(n)
        if spec == "campana (Risset)":
            ratios = [0.56, 0.56, 0.92, 0.92, 1.19, 1.7, 2.0, 2.74, 3.0, 3.76, 4.07]
            offs = [0, 1, 0, 1.7, 0, 0, 0, 0, 0, 0, 0]
            amps = [1, 0.67, 1, 1.8, 2.67, 1.67, 1.46, 1.33, 1.33, 1, 1.33]
            durs = [1, 0.9, 0.65, 0.55, 0.325, 0.35, 0.25, 0.2, 0.15, 0.1, 0.075]
            total = n / sr
            for r, o, a, d in zip(ratios, offs, amps, durs):
                ph = phase_from_freq(f0 * r + o, n, sr)
                out += a * np.sin(TWO_PI * ph) * np.exp(-t / (d * total / 4 + 1e-3))
            return out / 8.0
        nh = p["n_harm"]
        if spec == "personalizado":
            try:
                amps = [float(v) for v in p["custom"].replace(",", " ").split()]
            except ValueError:
                amps = [1.0]
            harmonics = np.arange(1, len(amps) + 1)
            amps = np.array(amps)
        else:
            harmonics = np.arange(1, nh + 1)
            if spec == "sierra (1/n)":
                amps = 1.0 / harmonics
            elif spec == "cuadrada (impares 1/n)":
                amps = np.where(harmonics % 2 == 1, 1.0 / harmonics, 0.0)
            elif spec == "triangular (impares 1/n²)":
                amps = np.where(harmonics % 2 == 1, 1.0 / harmonics ** 2, 0.0)
                amps *= np.where(((harmonics - 1) // 2) % 2 == 0, 1.0, -1.0)
            elif spec == "órgano (1/n²)":
                amps = 1.0 / harmonics ** 2
            else:
                amps = np.ones(nh)
        amps = amps * 10 ** (p["tilt"] * np.log2(harmonics) / 20.0)
        nyq = sr / 2
        fmax = float(np.max(f0))
        for h, a in zip(harmonics, amps):
            if a == 0:
                continue
            fh_ratio = h * np.sqrt(1.0 + p["inharm"] * h * h)
            if p["detune"] > 0:
                fh_ratio *= 2 ** (rng.uniform(-1, 1) * p["detune"] / 1200)
            if fmax * fh_ratio >= nyq:
                break
            ph0 = rng.uniform(0, 1) if p["random_phase"] else 0.0
            ph = phase_from_freq(f0 * fh_ratio, n, sr, ph0)
            partial = a * np.sin(TWO_PI * ph)
            if p["partial_decay"] > 0 and h > 1:
                partial *= np.exp(-t * p["partial_decay"] * (h - 1) / 4.0)
            out += partial
        peak = np.max(np.abs(out)) or 1.0
        return out / peak


# ===========================================================================
FILTER_MODES = ["paso bajo 12 dB", "paso bajo 24 dB", "Moog escalera 24 dB",
                "paso alto 12 dB", "paso banda", "rechaza banda", "sin filtro"]


def apply_synth_filter(x, cutoff_arr, res, sr, mode, drive):
    if mode == "sin filtro":
        return x
    if mode == "Moog escalera 24 dB":
        return K.moog_ladder(x, cutoff_arr, res, float(sr), drive)
    m = {"paso bajo 12 dB": 0, "paso bajo 24 dB": 0, "paso banda": 1,
         "paso alto 12 dB": 2, "rechaza banda": 3}[mode]
    y = K.svf_tv(x, cutoff_arr, res, float(sr), m, drive)
    if mode == "paso bajo 24 dB":
        y = K.svf_tv(y, cutoff_arr, res * 0.5, float(sr), 0, 0.0)
    return y


class Subtractive(Processor):
    name = "Osciladores + filtro (sustractiva)"
    category = "Síntesis"
    character = "Cálido · grueso · analógico"
    ideal = "bajos, leads, pads, cuerdas y metales sintéticos"
    sound = ("El sonido clásico de los sintetizadores analógicos (Moog, Prophet, Juno). Los osciladores "
             "generan un timbre rico que el filtro va 'esculpiendo': con el corte bajo suena oscuro y redondo, "
             "abierto suena brillante y la resonancia añade un pico silbante característico.")
    tips = ("Añade varios osciladores de sierra con pocos cents de diferencia para un sonido ancho; "
            "un oscilador una octava abajo (seno o cuadrada) da peso. Sube 'Envolvente → corte' para el típico "
            "ataque 'wow'.")
    description = ("Banco de osciladores (añade o quita los que quieras) → filtro resonante con envolvente y LFO.")
    params = [
        Param("oscillators", "Osciladores", "oscillators",
              [dict(OSC_DEFAULT, shape="sierra", level=0.8),
               dict(OSC_DEFAULT, shape="sierra", level=0.6, cents=8.0)],
              group="Osciladores"),
        Param("pwm_rate", "PWM velocidad", "float", 0.0, 0.0, 20.0, unit="Hz", group="Modulación de pulso (PWM)",
              help="Mueve el ancho de los osciladores 'pulso': sonido animado, tipo coro"),
        Param("pwm_depth", "PWM profundidad", "float", 0.0, 0.0, 0.45, group="Modulación de pulso (PWM)"),
        Param("fmode", "Tipo de filtro", "choice", "paso bajo 24 dB", choices=FILTER_MODES, group="Filtro",
              help="Paso bajo: quita agudos (lo más común). Paso alto: quita graves. Paso banda: deja una franja."),
        Param("cutoff", "Corte", "float", 1200.0, 20.0, 20000.0, log=True, unit="Hz", group="Filtro",
              help="Frecuencia a partir de la cual el filtro actúa. Más bajo = más oscuro"),
        Param("res", "Resonancia", "float", 0.3, 0.0, 1.0, group="Filtro",
              help="Realza la zona del corte: de suave a silbante y 'chillón'"),
        Param("keytrack", "Seguimiento de teclado", "float", 0.0, 0.0, 1.0, group="Filtro",
              help="1 = el corte sube con la nota, así las notas agudas no suenan apagadas"),
        Param("drive", "Saturación", "float", 0.0, 0.0, 1.0, group="Filtro", help="Calienta y ensucia el sonido"),
        Param("fenv_amt", "Envolvente → corte", "float", 3.0, -6.0, 6.0, unit="oct", group="Envolvente de filtro",
              help="Cuántas octavas abre el filtro la envolvente"),
        Param("f_a", "Ataque", "float", 0.005, 0.0, 5.0, log=True, unit="s", group="Envolvente de filtro"),
        Param("f_d", "Decaimiento", "float", 0.3, 0.001, 5.0, log=True, unit="s", group="Envolvente de filtro"),
        Param("f_s", "Sostenido", "float", 0.2, 0.0, 1.0, group="Envolvente de filtro"),
        Param("f_r", "Relajación", "float", 0.3, 0.001, 5.0, log=True, unit="s", group="Envolvente de filtro"),
        Param("lfo_shape", "Forma", "choice", "seno", choices=LFO_SHAPES, group="LFO de filtro (wah)"),
        Param("lfo_rate", "Velocidad", "float", 0.0, 0.0, 20.0, unit="Hz", group="LFO de filtro (wah)"),
        Param("lfo_depth", "Profundidad", "float", 0.0, 0.0, 4.0, unit="oct", group="LFO de filtro (wah)"),
    ]

    @staticmethod
    def is_stereo(p):
        for o in coerce_oscillators(p.get("oscillators", [])):
            if o["mute"]:
                continue
            if abs(o["pan"]) > 1e-3 or (o["voices"] > 1 and o["width"] > 0):
                return True
        return False

    @classmethod
    def render(cls, freq, n, sr, p, ctx):
        oscs = [o for o in coerce_oscillators(p["oscillators"]) if not o["mute"] and o["level"] > 0]
        stereo = cls.is_stereo(p)
        L = np.zeros(n)
        R = np.zeros(n)
        pwm = 0.0
        if p["pwm_rate"] > 0 and p["pwm_depth"] > 0:
            pwm = p["pwm_depth"] * lfo("triangular", p["pwm_rate"], n, sr)
        total = 0.0
        for i, o in enumerate(oscs):
            base = freq * 2.0 ** (o["octave"] + (o["semi"] * 100 + o["cents"]) / 1200.0)
            V = o["voices"]
            g = o["level"] / np.sqrt(V)
            total += o["level"]
            for v in range(V):
                off = 0.0 if V == 1 else (v / (V - 1) - 0.5) * 2 * o["spread"]
                ph0 = (0.618034 * (i * 7 + v + 1)) % 1.0
                y = oscillator(o["shape"], base * 2 ** (off / 1200), n, sr, pw=o["pw"] + pwm, phase0=ph0,
                               rng=np.random.default_rng(100 + i * 10 + v))
                if stereo:
                    pan = o["pan"] if V == 1 else o["pan"] + (v / (V - 1) - 0.5) * 2 * o["width"]
                    th = (np.clip(pan, -1, 1) + 1) * np.pi / 4
                    L += g * y * np.cos(th) * np.sqrt(2)
                    R += g * y * np.sin(th) * np.sqrt(2)
                else:
                    L += g * y
        norm = max(total, 1.0)
        env = adsr(n, sr, p["f_a"], p["f_d"], p["f_s"], p["f_r"])
        octs = p["fenv_amt"] * env
        if p["lfo_rate"] > 0 and p["lfo_depth"] > 0:
            octs = octs + p["lfo_depth"] * lfo(p["lfo_shape"], p["lfo_rate"], n, sr)
        cutoff = p["cutoff"] * (freq / 261.63) ** p["keytrack"] * 2.0 ** octs
        yl = apply_synth_filter(L / norm, cutoff, p["res"], sr, p["fmode"], p["drive"])
        if not stereo:
            return yl
        yr = apply_synth_filter(R / norm, cutoff, p["res"], sr, p["fmode"], p["drive"])
        return np.stack([yl, yr], axis=1)


# ===========================================================================
class FM(Processor):
    name = "FM (frecuencia modulada)"
    category = "Síntesis"
    description = ("Síntesis FM de Chowning (implementada como modulación de fase, igual que el "
                   "Yamaha DX7). Varios algoritmos de 2-3 operadores, realimentación y envolvente de índice.")
    params = [
        Param("algo", "Algoritmo", "choice", "M1 → C",
              choices=["M1 → C", "M2 → M1 → C", "(M1 + M2) → C", "M1 → C  +  M2 → C2 (paralelo)",
                       "M1 (realimentado) → C"]),
        Param("c_ratio", "Portadora: razón", "float", 1.0, 0.125, 16.0, log=True),
        Param("m1_ratio", "M1: razón", "float", 1.0, 0.125, 16.0, log=True),
        Param("m1_index", "M1: índice", "float", 3.0, 0.0, 20.0),
        Param("m2_ratio", "M2: razón", "float", 3.5, 0.125, 16.0, log=True),
        Param("m2_index", "M2: índice", "float", 1.0, 0.0, 20.0),
        Param("m_fixed", "M1 frecuencia fija (0 = razón)", "float", 0.0, 0.0, 5000.0, unit="Hz"),
        Param("feedback", "Realimentación", "float", 0.0, 0.0, 3.0),
        Param("idx_decay", "Decaimiento del índice", "float", 0.8, 0.01, 10.0, log=True, unit="s"),
        Param("idx_floor", "Índice sostenido (%)", "float", 0.2, 0.0, 1.0),
        Param("idx_attack", "Ataque del índice", "float", 0.0, 0.0, 2.0, unit="s"),
    ]

    @staticmethod
    def render(freq, n, sr, p, ctx):
        env = _env_decay(n, sr, p["idx_decay"], p["idx_floor"])
        if p["idx_attack"] > 0:
            env *= np.clip(np.arange(n) / (p["idx_attack"] * sr), 0, 1)
        pc = phase_from_freq(freq * p["c_ratio"], n, sr)
        f_m1 = p["m_fixed"] if p["m_fixed"] > 0 else freq * p["m1_ratio"]
        pm1 = phase_from_freq(f_m1, n, sr)
        pm2 = phase_from_freq(freq * p["m2_ratio"], n, sr)
        i1 = p["m1_index"] * env
        i2 = p["m2_index"] * env
        algo = p["algo"]
        if algo == "M1 → C":
            return np.sin(TWO_PI * pc + i1 * np.sin(TWO_PI * pm1))
        if algo == "M2 → M1 → C":
            m1 = np.sin(TWO_PI * pm1 + i2 * np.sin(TWO_PI * pm2))
            return np.sin(TWO_PI * pc + i1 * m1)
        if algo == "(M1 + M2) → C":
            return np.sin(TWO_PI * pc + i1 * np.sin(TWO_PI * pm1) + i2 * np.sin(TWO_PI * pm2))
        if algo.startswith("M1 → C  +"):
            c2 = phase_from_freq(freq * p["c_ratio"] * 2, n, sr)
            a = np.sin(TWO_PI * pc + i1 * np.sin(TWO_PI * pm1))
            b = np.sin(TWO_PI * c2 + i2 * np.sin(TWO_PI * pm2))
            return 0.5 * (a + b)
        return K.fm_feedback(pc, pm1, i1, p["feedback"])


# ===========================================================================
class AMRing(Processor):
    name = "AM / Modulación en anillo"
    category = "Síntesis"
    description = ("Modulación de amplitud (portadora + bandas laterales) o en anillo "
                   "(solo bandas laterales f_c ± f_m). Base de muchos sonidos metálicos y electroacústicos.")
    params = [
        Param("mode", "Modo", "choice", "AM", choices=["AM", "Anillo (ring)"]),
        Param("carrier", "Forma portadora", "choice", "seno", choices=WAVEFORMS[:5]),
        Param("modw", "Forma moduladora", "choice", "seno", choices=WAVEFORMS[:5]),
        Param("ratio_mode", "Frecuencia moduladora", "choice", "razón", choices=["razón", "Hz fijos"]),
        Param("ratio", "Razón f_m / f_c", "float", 1.5, 0.01, 16.0, log=True),
        Param("mod_hz", "f_m (Hz fijos)", "float", 30.0, 0.1, 5000.0, log=True, unit="Hz"),
        Param("depth", "Profundidad", "float", 1.0, 0.0, 1.0),
    ]

    @staticmethod
    def render(freq, n, sr, p, ctx):
        c = oscillator(p["carrier"], freq, n, sr)
        fm = freq * p["ratio"] if p["ratio_mode"] == "razón" else p["mod_hz"]
        m = oscillator(p["modw"], fm, n, sr)
        d = p["depth"]
        if p["mode"] == "AM":
            return c * (1 - d + d * (0.5 + 0.5 * m))
        return c * (1 - d + d * m)


# ===========================================================================
def _build_wavetable(kind: str, frames: int, size: int, max_h: int) -> np.ndarray:
    """Construye una tabla (frames x size) por síntesis aditiva limitada en banda."""
    rng = np.random.default_rng(11)
    t = np.arange(size) / size
    h = np.arange(1, max_h + 1)
    S = np.sin(TWO_PI * np.outer(h, t))  # (H, size)
    tables = np.zeros((frames, size))
    for k in range(frames):
        pos = k / max(frames - 1, 1)
        if kind.startswith("básica"):
            saw = 1 / h
            sq = np.where(h % 2 == 1, 1 / h, 0)
            tri = np.where(h % 2 == 1, 1 / h ** 2, 0) * np.where(((h - 1) // 2) % 2 == 0, 1, -1)
            sine = (h == 1).astype(float)
            seq = [sine, tri, saw, sq]
            x = pos * 3
            i = min(int(x), 2)
            fr = x - i
            amps = (1 - fr) * seq[i] + fr * seq[i + 1]
        elif kind.startswith("armónicos"):
            nh = 1 + pos * (max_h - 1)
            amps = np.clip(nh - h + 1, 0, 1) / np.sqrt(h)
        elif kind.startswith("formantes"):
            v = VOWELS
            x = pos * (len(v) - 1)
            i = min(int(x), len(v) - 2)
            fr = x - i
            amps = np.zeros(max_h)
            for vi, w in ((v[i], 1 - fr), (v[i + 1], fr)):
                fs, bws, gs = FORMANTS[vi]
                f0 = 110.0
                for F, B, G in zip(fs, bws, gs):
                    amps += w * 10 ** (G / 20) * np.exp(-0.5 * ((h * f0 - F) / (B * 1.5)) ** 2)
            amps /= np.maximum(h, 1) ** 0.3
        elif kind.startswith("PWM"):
            wdt = 0.5 - 0.45 * pos
            amps = (2 / (np.pi * h)) * np.sin(np.pi * h * wdt)
        else:  # aleatoria
            base = rng.uniform(0, 1, max_h) / h
            amps = base * (1 + pos * rng.uniform(-1, 1, max_h))
        tables[k] = amps @ S
        m = np.max(np.abs(tables[k])) or 1
        tables[k] /= m
    return tables


class Wavetable(Processor):
    name = "Tabla de ondas (wavetable)"
    category = "Síntesis"
    description = ("Lectura de ciclos de onda almacenados con morphing continuo entre tablas "
                   "(estilo PPG / Serum). La posición puede modularse por envolvente y LFO.")
    params = [
        Param("table", "Banco de tablas", "choice", "básica (seno→tri→sierra→cuadrada)",
              choices=["básica (seno→tri→sierra→cuadrada)", "armónicos crecientes",
                       "formantes vocales (a-e-i-o-u)", "PWM", "aleatoria"]),
        Param("pos", "Posición", "float", 0.0, 0.0, 1.0),
        Param("env_amt", "Envolvente → posición", "float", 0.7, -1.0, 1.0),
        Param("env_time", "Tiempo de envolvente", "float", 1.0, 0.01, 10.0, log=True, unit="s"),
        Param("lfo_rate", "LFO velocidad", "float", 0.0, 0.0, 20.0, unit="Hz"),
        Param("lfo_depth", "LFO profundidad", "float", 0.0, 0.0, 0.5),
        Param("frames", "Nº de tablas", "int", 32, 2, 128),
    ]

    @staticmethod
    def render(freq, n, sr, p, ctx):
        size = 2048
        max_h = int(min(256, max(1, sr / 2 / max(float(np.max(freq)), 1.0))))
        tables = _build_wavetable(p["table"], p["frames"], size, max_h)
        t = np.arange(n) / sr
        pos = p["pos"] + p["env_amt"] * (1 - np.exp(-t / p["env_time"]))
        if p["lfo_rate"] > 0:
            pos = pos + p["lfo_depth"] * lfo("seno", p["lfo_rate"], n, sr)
        pos = np.clip(pos, 0, 1) * (p["frames"] - 1)
        ph = (phase_from_freq(freq, n, sr) % 1.0) * size
        i0 = ph.astype(int) % size
        i1 = (i0 + 1) % size
        fr = ph - np.floor(ph)
        f0 = np.minimum(pos.astype(int), p["frames"] - 2) if p["frames"] > 1 else np.zeros(n, int)
        ff = pos - f0
        a = tables[f0, i0] * (1 - fr) + tables[f0, i1] * fr
        b = tables[f0 + 1, i0] * (1 - fr) + tables[f0 + 1, i1] * fr
        return a * (1 - ff) + b * ff


# ===========================================================================
WINDOWS = {"hann": "hann", "gauss": ("gaussian", None), "triangular": "triang",
           "tukey": ("tukey", 0.5), "rectangular": "boxcar", "blackman": "blackman"}


def grain_window(kind, L):
    if kind == "gauss":
        return signal.windows.gaussian(L, L / 6)
    w = WINDOWS[kind]
    return signal.get_window(w, L, fftbins=False)


class Granular(Processor):
    name = "Granular"
    category = "Síntesis"
    description = ("Nube de granos (Xenakis, Roads, Truax): pequeños fragmentos enventanados "
                   "de una fuente, con control de densidad, tamaño, posición, dispersión y transposición. "
                   "Puede usar el audio actualmente cargado como fuente.")
    params = [
        Param("source", "Fuente", "choice", "audio actual",
              choices=["audio actual", "seno", "sierra", "ruido rosa", "barrido (chirp)"]),
        Param("grain_ms", "Tamaño de grano", "float", 80.0, 2.0, 1000.0, log=True, unit="ms"),
        Param("size_jitter", "Variación de tamaño", "float", 0.2, 0.0, 1.0),
        Param("density", "Densidad", "float", 40.0, 1.0, 1000.0, log=True, unit="granos/s"),
        Param("position", "Posición inicial", "float", 0.2, 0.0, 1.0),
        Param("scan", "Velocidad de lectura", "float", 0.2, -2.0, 2.0,
              help="Avance de la posición en la fuente (1 = tiempo real, 0 = congelado)"),
        Param("pos_jitter", "Dispersión de posición", "float", 0.05, 0.0, 1.0),
        Param("transpose", "Transposición", "float", 0.0, -36.0, 36.0, unit="st"),
        Param("pitch_jitter", "Dispersión de tono", "float", 0.0, 0.0, 12.0, unit="st"),
        Param("follow_note", "Seguir la nota (C4 = original)", "bool", False),
        Param("reverse_prob", "Probabilidad de grano invertido", "float", 0.0, 0.0, 1.0),
        Param("window", "Ventana", "choice", "hann", choices=list(WINDOWS.keys())),
        Param("seed", "Semilla aleatoria", "int", 1, 0, 9999),
    ]

    @staticmethod
    def render(freq, n, sr, p, ctx):
        rng = np.random.default_rng(p["seed"])
        f0 = float(np.mean(freq))
        src_kind = p["source"]
        src = None
        if src_kind == "audio actual":
            buf = ctx.get("buffer")
            if buf is not None and len(buf) > 0:
                src = as_2d(buf).mean(axis=1)
                if ctx.get("buffer_sr", sr) != sr:
                    src = signal.resample_poly(src, sr, ctx["buffer_sr"])
        if src is None:
            L = sr * 2
            if src_kind == "sierra":
                src = oscillator("sierra", f0, L, sr)
            elif src_kind == "ruido rosa":
                src = colored_noise("rosa", L, rng)
            elif src_kind == "barrido (chirp)":
                src = signal.chirp(np.arange(L) / sr, 50, 2.0, 8000, method="logarithmic")
            else:
                src = oscillator("seno", f0, L, sr)
            base_ratio = 1.0
        else:
            base_ratio = f0 / 261.63 if p["follow_note"] else 1.0
        S = len(src)
        out = np.zeros(n + int(sr * 2.2))
        n_grains = max(1, int(p["density"] * n / sr))
        onsets = np.sort(rng.uniform(0, n, n_grains)).astype(int)
        for on in onsets:
            gl = p["grain_ms"] / 1000 * (1 + p["size_jitter"] * rng.uniform(-0.8, 0.8))
            semis = p["transpose"] + p["pitch_jitter"] * rng.uniform(-1, 1)
            ratio = base_ratio * 2 ** (semis / 12)
            L_out = max(int(gl * sr), 8)
            L_in = int(L_out * ratio) + 2
            pos = p["position"] + p["scan"] * (on / sr) * sr / max(S, 1) \
                + p["pos_jitter"] * rng.uniform(-1, 1)
            start = int((pos % 1.0) * S)
            idx = (start + np.arange(L_in)) % S
            seg = src[idx]
            if rng.uniform() < p["reverse_prob"]:
                seg = seg[::-1]
            xs = np.arange(L_out) * ratio
            g = np.interp(xs, np.arange(L_in), seg) * grain_window(p["window"], L_out)
            out[on:on + L_out] += g
        out = out[:n]
        # normalización aproximada por solapamiento
        overlap = max(p["density"] * p["grain_ms"] / 1000, 1.0)
        return out / np.sqrt(overlap)


# ===========================================================================
class KarplusStrong(Processor):
    name = "Karplus-Strong (cuerda pulsada)"
    category = "Síntesis"
    description = ("Modelado físico: una ráfaga de ruido recircula en una línea de retardo con "
                   "filtro de amortiguamiento, simulando una cuerda pulsada o un tambor. "
                   "Consejo: usa sostenido = 1 en la envolvente común.")
    params = [
        Param("decay", "Tiempo de decaimiento (-60 dB)", "float", 3.0, 0.05, 30.0, log=True, unit="s"),
        Param("damping", "Amortiguamiento de agudos", "float", 0.5, 0.0, 1.0),
        Param("excitation", "Excitación", "choice", "ruido", choices=["ruido", "ruido filtrado", "impulso",
                                                                     "sierra", "audio actual"]),
        Param("brightness", "Brillo de la excitación", "float", 0.8, 0.0, 1.0),
        Param("pluck_pos", "Posición de pulsación", "float", 0.0, 0.0, 0.5,
              help="Filtro peine sobre la excitación (0 = desactivado)"),
        Param("drum", "Mezcla de tambor", "float", 0.0, 0.0, 0.5,
              help="Probabilidad de invertir el signo (variante de tambor de Karplus-Strong)"),
        Param("seed", "Semilla", "int", 1, 0, 9999),
    ]

    @staticmethod
    def render(freq, n, sr, p, ctx):
        f0 = float(np.mean(freq))
        period = sr / f0
        N = int(period) + 2
        rng = np.random.default_rng(p["seed"])
        kind = p["excitation"]
        if kind == "impulso":
            ex = np.zeros(N)
            ex[0] = 1.0
        elif kind == "sierra":
            ex = np.linspace(1, -1, N)
        elif kind == "audio actual" and ctx.get("buffer") is not None and len(ctx["buffer"]) > 0:
            b = as_2d(ctx["buffer"]).mean(axis=1)
            ex = np.resize(b, N)
        else:
            ex = rng.uniform(-1, 1, N)
        if kind == "ruido filtrado" or p["brightness"] < 1:
            a = 1 - p["brightness"] * 0.98 if kind != "ruido filtrado" else 0.7
            ex = signal.lfilter([1 - a], [1, -a], ex)
        if p["pluck_pos"] > 0:
            d = max(int(p["pluck_pos"] * N), 1)
            ex = ex - np.concatenate((np.zeros(d), ex[:-d]))
        ex = ex - ex.mean()
        ex /= (np.max(np.abs(ex)) or 1)
        loss = 10 ** (-3.0 / (p["decay"] * f0))
        y = K.karplus_strong(ex.astype(np.float64), n, float(period), float(loss),
                             float(p["damping"]), float(p["drum"]), int(p["seed"]))
        return y


# ===========================================================================
class PhaseDistortion(Processor):
    name = "Distorsión de fase (Casio CZ)"
    category = "Síntesis"
    description = ("Se deforma la fase de un coseno para obtener formas ricas en armónicos; "
                   "la cantidad de distorsión actúa como un 'filtro' dinámico.")
    params = [
        Param("shape", "Forma", "choice", "sierra",
              choices=["sierra", "cuadrada", "pulso", "resonante (sierra)", "resonante (triángulo)",
                       "resonante (trapecio)"]),
        Param("amount", "Cantidad", "float", 0.8, 0.0, 1.0),
        Param("env_decay", "Decaimiento de la cantidad", "float", 0.6, 0.01, 10.0, log=True, unit="s"),
        Param("env_floor", "Cantidad sostenida (%)", "float", 0.3, 0.0, 1.0),
    ]

    @staticmethod
    def render(freq, n, sr, p, ctx):
        amt = p["amount"] * _env_decay(n, sr, p["env_decay"], p["env_floor"])
        t = phase_from_freq(freq, n, sr) % 1.0
        sh = p["shape"]
        if sh == "sierra":
            d = 0.5 - 0.49 * amt
            ph = np.where(t < d, 0.5 * t / d, 0.5 + 0.5 * (t - d) / (1 - d))
            return np.cos(TWO_PI * ph)
        if sh == "cuadrada":
            d = 0.5 - 0.49 * amt
            tt = (2 * t) % 1.0
            ph = np.where(tt < d, 0.5 * tt / d, 0.5)
            y = np.cos(TWO_PI * ph)
            return np.where(t < 0.5, y, -y)
        if sh == "pulso":
            d = 1 - 0.95 * amt
            ph = np.where(t < d, t / d, 1.0)
            return np.cos(TWO_PI * ph)
        res = 1 + amt * 15
        wave = np.cos(TWO_PI * ((t * res) % 1.0))
        if sh == "resonante (sierra)":
            win = 1 - t
        elif sh == "resonante (triángulo)":
            win = 1 - np.abs(2 * t - 1)
        else:
            win = np.clip(2 - 2 * np.abs(2 * t - 1) * 1.0, 0, 1)
        y = wave * win
        return y - np.mean(y)


# ===========================================================================
class Waveshaping(Processor):
    name = "Waveshaping (función de transferencia)"
    category = "Síntesis"
    description = ("Síntesis por distorsión no lineal (Le Brun, Arfib): una senoide pasa por una "
                   "función de transferencia. Con polinomios de Chebyshev se obtienen exactamente los "
                   "armónicos deseados; la amplitud de entrada controla el brillo.")
    params = [
        Param("func", "Función", "choice", "Chebyshev (armónicos)",
              choices=["Chebyshev (armónicos)", "tanh", "seno (plegado)", "cúbica", "exponencial"]),
        Param("weights", "Pesos armónicos (Chebyshev)", "text", "1 0.6 0.4 0.3 0.2 0.15 0.1",
              help="Amplitud de los armónicos 1, 2, 3... en la función de Chebyshev"),
        Param("drive", "Índice / ganancia de entrada", "float", 1.0, 0.0, 10.0),
        Param("env_decay", "Decaimiento del índice", "float", 1.0, 0.01, 10.0, log=True, unit="s"),
        Param("env_floor", "Índice sostenido (%)", "float", 0.3, 0.0, 1.0),
    ]

    @staticmethod
    def render(freq, n, sr, p, ctx):
        idx = p["drive"] * _env_decay(n, sr, p["env_decay"], p["env_floor"])
        x = np.sin(TWO_PI * phase_from_freq(freq, n, sr))
        fn = p["func"]
        if fn.startswith("Chebyshev"):
            try:
                w = [float(v) for v in p["weights"].replace(",", " ").split()]
            except ValueError:
                w = [1.0]
            xi = np.clip(x * np.minimum(idx, 1.0), -1, 1)
            y = C.chebval(xi, np.concatenate(([0.0], w)))
        elif fn == "tanh":
            y = np.tanh(x * idx * 2)
        elif fn.startswith("seno"):
            y = np.sin(x * idx * np.pi)
        elif fn == "cúbica":
            xi = np.clip(x * idx, -1.5, 1.5)
            y = xi - xi ** 3 / 3
        else:
            y = np.sign(x) * (1 - np.exp(-np.abs(x) * idx * 3))
        y = y - np.mean(y)
        return y / (np.max(np.abs(y)) or 1)


# ===========================================================================
class Formant(Processor):
    name = "Formantes (voz, fuente-filtro)"
    category = "Síntesis"
    description = ("Modelo fuente-filtro del tracto vocal: un tren de pulsos glotales pasa por "
                   "resonadores en las frecuencias de formantes de una vocal, con morphing entre vocales.")
    params = [
        Param("vowel_a", "Vocal inicial", "choice", "a", choices=VOWELS),
        Param("vowel_b", "Vocal final", "choice", "o", choices=VOWELS),
        Param("morph_time", "Tiempo de transición", "float", 1.0, 0.01, 10.0, log=True, unit="s"),
        Param("source", "Fuente", "choice", "pulso glotal", choices=["pulso glotal", "sierra", "ruido (susurro)"]),
        Param("breath", "Aspiración (ruido)", "float", 0.05, 0.0, 1.0),
        Param("shift", "Desplazamiento de formantes", "float", 1.0, 0.5, 2.0,
              help="<1 voz más grave/grande, >1 voz más aguda/pequeña"),
        Param("bw_scale", "Escala de ancho de banda", "float", 1.0, 0.3, 4.0),
    ]

    @staticmethod
    def render(freq, n, sr, p, ctx):
        rng = np.random.default_rng(5)
        t = phase_from_freq(freq, n, sr) % 1.0
        if p["source"] == "pulso glotal":
            # modelo de Rosenberg
            op = 0.4
            cl = 0.16
            src = np.where(t < op, 0.5 * (1 - np.cos(np.pi * t / op)),
                           np.where(t < op + cl, np.cos(0.5 * np.pi * (t - op) / cl), 0.0))
            src = np.diff(src, prepend=src[0])
        elif p["source"] == "sierra":
            src = oscillator("sierra", freq, n, sr)
        else:
            src = rng.uniform(-1, 1, n) * 0.3
        src = src + p["breath"] * rng.uniform(-1, 1, n) * 0.2
        fa, ba, ga = FORMANTS[p["vowel_a"]]
        fb, bb, gb = FORMANTS[p["vowel_b"]]
        tt = np.arange(n) / sr
        m = np.clip(tt / p["morph_time"], 0, 1)
        out = np.zeros(n)
        for i in range(5):
            F = ((1 - m) * fa[i] + m * fb[i]) * p["shift"]
            B = ((1 - m) * ba[i] + m * bb[i]) * p["bw_scale"]
            G = 10 ** (((1 - m) * ga[i] + m * gb[i]) / 20)
            k = float(np.clip(np.mean(B) / max(np.mean(F), 1.0), 0.02, 2.0))
            res = (2.0 - k) / 1.98
            out += G * k * K.svf_tv(src, F, res, float(sr), 1, 0.0)
        return out / (np.max(np.abs(out)) or 1)


# ===========================================================================
class Noise(Processor):
    name = "Ruido (coloreado / afinado)"
    category = "Síntesis"
    description = "Generador de ruido blanco, rosa, marrón, azul o violeta con filtro paso banda opcional que puede seguir la nota."
    params = [
        Param("color", "Color", "choice", "rosa", choices=["blanco", "rosa", "marrón", "azul", "violeta"]),
        Param("band", "Filtro de banda", "bool", False),
        Param("follow", "La banda sigue la nota", "bool", True),
        Param("center", "Centro (si no sigue la nota)", "float", 1000.0, 20.0, 20000.0, log=True, unit="Hz"),
        Param("res", "Resonancia (estrechez)", "float", 0.9, 0.0, 0.999),
        Param("seed", "Semilla", "int", 1, 0, 9999),
    ]

    @staticmethod
    def render(freq, n, sr, p, ctx):
        y = colored_noise(p["color"], n, np.random.default_rng(p["seed"]))
        if p["band"]:
            c = freq if p["follow"] else np.full(n, p["center"])
            y = K.svf_tv(y, np.asarray(c, float), p["res"], float(sr), 1, 0.0)
            y /= (np.max(np.abs(y)) or 1)
        return y


# ---------------------------------------------------------------------------
# Qué esperar de cada método (se muestra en la interfaz)
# ---------------------------------------------------------------------------
_SOUND_INFO = {
    Additive: ("Puro · cristalino · controlado", "órganos, campanas, tonos limpios, estudiar la serie armónica",
               "Sonidos claros que se construyen parcial a parcial: desde un seno puro hasta órganos, flautas y "
               "campanas (preset Risset). No tiene el 'calor' de un filtro: suena preciso y transparente.",
               "Sube 'Decaimiento de agudos' para que el sonido se oscurezca al apagarse, como una cuerda real. "
               "Un poco de inarmonicidad lo acerca a un piano."),
    FM: ("Metálico · brillante · percusivo", "campanas, pianos eléctricos, bajos de los 80, metales, sonidos inarmónicos",
         "Timbres complejos y vivos que cambian mientras suenan. Con razones enteras (1, 2, 3…) suena armónico "
         "(pianos eléctricos, metales); con razones no enteras (1.4, 3.5) aparecen campanas y metales inarmónicos.",
         "El índice es el 'brillo': más índice = más armónicos. Que el índice decaiga rápido da ataques "
         "percusivos como de piano eléctrico."),
    AMRing: ("Metálico · robótico · pulsante", "trémolos, campanas extrañas, voces de robot, ciencia ficción",
             "Con moduladora lenta (pocos Hz) se oye un trémolo. Con moduladora audible aparecen frecuencias nuevas "
             "(suma y diferencia): en modo anillo la nota original desaparece y queda un timbre metálico, 'marciano'.",
             "Prueba el modo anillo con razón 1.618 (proporción áurea) o con frecuencia fija de 30–80 Hz."),
    Wavetable: ("Evolutivo · moderno · digital", "pads que 'respiran', leads con movimiento, EDM, voces sintéticas",
                "El timbre se transforma de forma continua mientras la nota suena, pasando de suave a brillante "
                "(o entre vocales, con el banco de formantes). Suena moderno y con mucho movimiento.",
                "Usa 'Envolvente → posición' para que el sonido se abra al tocar y un LFO lento para que ondule."),
    Granular: ("Nubes · texturas · atmósferas", "texturas electroacústicas, atmósferas, congelados, transformar grabaciones",
               "Descompone un sonido en miles de micro-fragmentos y los redistribuye: nubes, lluvia sonora, "
               "texturas congeladas o estiradas. Con 'audio actual' como fuente transforma radicalmente lo que "
               "hayas cargado o seleccionado.",
               "Granos grandes (100–300 ms) conservan el sonido original; granos pequeños (5–20 ms) lo convierten en "
               "textura. Velocidad de lectura 0 = sonido congelado."),
    KarplusStrong: ("Acústico · pulsado · natural", "guitarra, arpa, koto, clave, pizzicato, tambores",
                    "Cuerdas pulsadas sorprendentemente realistas que decaen de forma natural. Con 'Mezcla de "
                    "tambor' se vuelve un golpe de membrana.",
                    "Pon la envolvente común con sostenido = 1 y deja que la cuerda decaiga sola. Poco "
                    "amortiguamiento = cuerda de acero brillante; mucho = nylon o laúd."),
    PhaseDistortion: ("Digital vintage · resonante · años 80", "bajos y leads 'retro', teclados CZ, sonidos resonantes",
                      "El sonido del Casio CZ: parecido a un filtro analógico que se abre, pero con un brillo más "
                      "digital. Las formas 'resonantes' suenan como un filtro con mucha resonancia barriendo.",
                      "Deja que la cantidad decaiga rápido para un ataque tipo 'pluck'."),
    Waveshaping: ("De dulce a saturado · armónicos a medida", "flautas y metales que se abren, tonos saturados",
                  "Una senoide que se 'enriquece' al aumentar la intensidad: de flauta suave a metal brillante. "
                  "Con Chebyshev decides exactamente qué armónicos aparecen.",
                  "Pesos solo en posiciones impares (1 0 0.5 0 0.3) dan un sonido hueco tipo clarinete."),
    Formant: ("Vocal · humano · coral", "voces sintéticas, coros, vocales cantadas, efectos 'talk box'",
              "Vocales cantadas (a, e, i, o, u) y transiciones entre ellas: suena como una voz o coro sintético; "
              "con fuente de ruido, como un susurro.",
              "Añade vibrato (Notas y envolvente → Tono) y unísono con varias voces para un coro."),
    Noise: ("Aire · viento · percusión", "viento, mar, platillos, hi-hats, efectos, silbidos afinados",
            "Soplos y texturas sin altura: viento, olas, platillos. Con el filtro de banda estrecho y siguiendo "
            "la nota se convierte en un silbido con altura, como soplar una botella.",
            "Ruido rosa + banda con resonancia alta + vibrato lento = viento muy convincente."),
}
for _cls, (_ch, _ideal, _snd, _tips) in _SOUND_INFO.items():
    _cls.character, _cls.ideal, _cls.sound, _cls.tips = _ch, _ideal, _snd, _tips


SYNTHS = [Subtractive, Additive, FM, AMRing, Wavetable, Granular, KarplusStrong,
          PhaseDistortion, Waveshaping, Formant, Noise]
SYNTH_BY_NAME = {s.name: s for s in SYNTHS}

# ---------------------------------------------------------------------------
# Motor común: secuencia de notas, envolvente de amplitud, vibrato, unísono, estéreo
# ---------------------------------------------------------------------------
G_NOTES = "Notas y duración"
G_ENV = "Envolvente de volumen (ADSR)"
G_PITCH = "Tono y vibrato"
G_UNI = "Unísono y estéreo (global)"
COMMON_PARAMS = [
    Param("sequence", "Notas", "text", "A3", group=G_NOTES,
          help="Ej.: A4  ·  C4 E4 G4  ·  C4:0.5 R:0.25 G4:1 (duración en s, R = silencio)  ·  acorde C4+E4+G4:2  ·  "
               "Do4 Re4  ·  220 (Hz). También puedes tocar el piano de abajo."),
    Param("note_dur", "Duración por nota", "float", 1.5, 0.02, 30.0, log=True, unit="s", group=G_NOTES,
          help="Duración de las notas que no indican ':segundos'"),
    Param("gap", "Superposición / separación", "float", 0.0, -2.0, 2.0, unit="s", group=G_NOTES,
          help="Negativo = cada nota empieza antes de que acabe la anterior (su cola se superpone)"),
    Param("volume", "Volumen final", "float", -6.0, -48.0, 6.0, unit="dB", group=G_NOTES),
    Param("a", "Ataque", "float", 0.01, 0.0, 10.0, log=True, unit="s", group=G_ENV,
          help="Tiempo que tarda en alcanzar el máximo: corto = golpe, largo = entrada suave"),
    Param("d", "Decaimiento", "float", 0.2, 0.001, 10.0, log=True, unit="s", group=G_ENV,
          help="Tiempo en bajar del máximo al nivel de sostenido"),
    Param("s", "Sostenido", "float", 0.7, 0.0, 1.0, group=G_ENV,
          help="Nivel mientras la nota se mantiene (0 = sonido percusivo que se apaga)"),
    Param("r", "Relajación", "float", 0.3, 0.001, 10.0, log=True, unit="s", group=G_ENV,
          help="Cola al soltar la nota"),
    Param("curve", "Curvatura", "float", 1.0, 0.2, 5.0, group=G_ENV,
          help="1 = lineal; mayor = ataques y caídas más exponenciales, naturales"),
    Param("vib_rate", "Vibrato: velocidad", "float", 5.0, 0.0, 20.0, unit="Hz", group=G_PITCH),
    Param("vib_depth", "Vibrato: profundidad", "float", 0.0, 0.0, 200.0, unit="cents", group=G_PITCH,
          help="0 = sin vibrato; 10–30 cents es natural, 100 = un semitono"),
    Param("vib_delay", "Vibrato: retardo", "float", 0.2, 0.0, 5.0, unit="s", group=G_PITCH,
          help="El vibrato entra después de este tiempo, como en un cantante"),
    Param("glide", "Barrido de tono inicial", "float", 0.0, -24.0, 24.0, unit="st", group=G_PITCH,
          help="La nota empieza desplazada estos semitonos y se desliza hasta su altura"),
    Param("glide_time", "Tiempo de barrido", "float", 0.1, 0.001, 5.0, log=True, unit="s", group=G_PITCH),
    Param("transpose", "Transposición global", "float", 0.0, -48.0, 48.0, unit="st", group=G_PITCH),
    Param("voices", "Voces al unísono", "int", 1, 1, 9, group=G_UNI,
          help="Repite todo el sonido varias veces ligeramente desafinado (más grueso)"),
    Param("spread", "Desafinación del unísono", "float", 12.0, 0.0, 100.0, unit="cents", group=G_UNI),
    Param("width", "Ancho estéreo", "float", 0.0, 0.0, 1.0, group=G_UNI,
          help="Reparte las voces de unísono entre los dos altavoces"),
]


def _note_freq_curve(f, n, sr, cp):
    t = np.arange(n) / sr
    semis = np.full(n, cp["transpose"])
    if cp["glide"] != 0:
        semis += cp["glide"] * np.exp(-t / max(cp["glide_time"] / 3, 1e-4))
    if cp["vib_depth"] > 0 and cp["vib_rate"] > 0:
        ramp = np.clip((t - cp["vib_delay"]) / 0.3, 0, 1)
        semis += ramp * cp["vib_depth"] / 100 * np.sin(TWO_PI * cp["vib_rate"] * t)
    return f * 2 ** (semis / 12)


def render_synth(synth_cls, sp: dict, cp: dict, sr: int, ctx=None) -> np.ndarray:
    """Renderiza la secuencia completa. Devuelve (muestras, canales)."""
    ctx = ctx or {}
    sp = synth_cls.coerce(sp)
    cp = {**{p.key: p.default for p in COMMON_PARAMS}, **cp}
    events = parse_sequence(cp["sequence"] or "A4", cp["note_dur"])
    if not events:
        events = [([440.0], cp["note_dur"])]
    synth_stereo = bool(getattr(synth_cls, "is_stereo", lambda _p: False)(sp))
    stereo = (cp["width"] > 0 and cp["voices"] > 1) or synth_stereo
    ch = 2 if stereo else 1
    total = sum(max(d + cp["gap"], 0) for _, d in events) + max(d for _, d in events) + 0.1
    out = np.zeros((int(total * sr) + 1, ch))
    pos = 0
    V = max(1, cp["voices"])
    for freqs, dur in events:
        n = max(int(dur * sr), 16)
        env = adsr(n, sr, cp["a"], cp["d"], cp["s"], cp["r"], cp["curve"])
        for f in freqs:
            for v in range(V):
                off = 0.0 if V == 1 else (v / (V - 1) - 0.5) * 2 * cp["spread"]
                fc = _note_freq_curve(f * 2 ** (off / 1200), n, sr, cp)
                y = synth_cls.render(fc, n, sr, sp, ctx)
                y = np.nan_to_num(np.asarray(y, float)[:n])
                g = env / (np.sqrt(V) * max(len(freqs), 1) ** 0.5)
                if y.ndim == 2:  # el sintetizador ya produce estéreo
                    pan = 0.0 if V == 1 else (v / (V - 1) - 0.5) * 2 * cp["width"]
                    out[pos:pos + n, 0] += y[:, 0] * g * (1 - max(pan, 0))
                    out[pos:pos + n, 1] += y[:, 1] * g * (1 + min(pan, 0))
                    continue
                y = y * g
                if ch == 2:
                    pan = 0.0 if V == 1 else (v / (V - 1) - 0.5) * 2 * cp["width"]
                    th = (pan + 1) * np.pi / 4
                    out[pos:pos + n, 0] += y * np.cos(th)
                    out[pos:pos + n, 1] += y * np.sin(th)
                else:
                    out[pos:pos + n, 0] += y
        pos += max(int((dur + cp["gap"]) * sr), 0)
    # recortar silencio final
    nz = np.nonzero(np.max(np.abs(out), axis=1) > 1e-6)[0]
    end = (nz[-1] + 1) if len(nz) else len(out)
    out = out[:max(end, pos)]
    peak = np.max(np.abs(out)) or 1.0
    out = out / peak * 10 ** (cp["volume"] / 20)
    return out
