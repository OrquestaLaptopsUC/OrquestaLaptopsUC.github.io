"""
Núcleos de procesamiento muestra-a-muestra (bucles). Se aceleran con numba si está instalado.
"""
import numpy as np

from .core import jit, HAS_NUMBA


@jit
def _svf_tv_loop(x, cutoff, res, sr, mode, drive):
    """
    Filtro de estado variable TPT (Zavalishin) con frecuencia de corte variable en el tiempo.
    mode: 0=LP 1=BP 2=HP 3=notch 4=peak 5=allpass
    cutoff: array Hz (misma longitud que x); res: 0..1
    """
    n = x.shape[0]
    y = np.zeros(n)
    ic1 = 0.0
    ic2 = 0.0
    k = 2.0 - 1.98 * min(max(res, 0.0), 1.0)
    nyq = sr * 0.49
    for i in range(n):
        fc = cutoff[i]
        if fc < 5.0:
            fc = 5.0
        elif fc > nyq:
            fc = nyq
        g = np.tan(np.pi * fc / sr)
        a1 = 1.0 / (1.0 + g * (g + k))
        a2 = g * a1
        a3 = g * a2
        v0 = x[i]
        if drive > 0.0:
            v0 = np.tanh(v0 * (1.0 + drive * 4.0)) / (1.0 + drive)
        v3 = v0 - ic2
        v1 = a1 * ic1 + a2 * v3
        v2 = ic2 + a2 * ic1 + a3 * v3
        ic1 = 2.0 * v1 - ic1
        ic2 = 2.0 * v2 - ic2
        if mode == 0:
            y[i] = v2
        elif mode == 1:
            y[i] = v1
        elif mode == 2:
            y[i] = v0 - k * v1 - v2
        elif mode == 3:
            y[i] = v0 - k * v1
        elif mode == 4:
            y[i] = v0 - k * v1 - 2.0 * v2
        else:
            y[i] = v0 - 2.0 * k * v1
    return y


def _svf_tv_blocks(x, cutoff, res, sr, mode, drive, block=128):
    """
    Versión sin numba del SVF: transformada bilineal del prototipo analógico (idéntica respuesta
    que el SVF TPT) con coeficientes actualizados cada `block` muestras. Rápida en Python puro.
    """
    from scipy.signal import lfilter
    x = np.asarray(x, dtype=np.float64)
    if drive > 0.0:
        x = np.tanh(x * (1.0 + drive * 4.0)) / (1.0 + drive)
    n = len(x)
    k = 2.0 - 1.98 * min(max(res, 0.0), 1.0)
    nb = (n + block - 1) // block
    c = np.asarray(cutoff, dtype=np.float64)
    pad = nb * block - n
    cm = np.pad(c, (0, pad), mode="edge").reshape(nb, block).mean(axis=1)
    g = np.tan(np.pi * np.clip(cm, 5.0, sr * 0.49) / sr)
    g2 = g * g
    a0 = 1 + k * g + g2
    a1 = (-2 + 2 * g2) / a0
    a2 = (1 - k * g + g2) / a0
    one = np.ones_like(g)
    if mode == 0:
        B = np.stack([g2, 2 * g2, g2], 1)
    elif mode == 1:
        B = np.stack([g, 0 * g, -g], 1)
    elif mode == 2:
        B = np.stack([one, -2 * one, one], 1)
    elif mode == 3:
        B = np.stack([1 + g2, -2 + 2 * g2, 1 + g2], 1)
    elif mode == 4:
        B = np.stack([1 - g2, -2 - 2 * g2, 1 - g2], 1)
    else:
        B = np.stack([1 - k * g + g2, -2 + 2 * g2, 1 + k * g + g2], 1)
    B = B / a0[:, None]
    y = np.empty(n)
    zi = np.zeros(2)
    for i in range(nb):
        s0, s1 = i * block, min((i + 1) * block, n)
        y[s0:s1], zi = lfilter(B[i], [1.0, a1[i], a2[i]], x[s0:s1], zi=zi)
    return y


def svf_tv(x, cutoff, res, sr, mode, drive):
    """Filtro de estado variable con corte variable (ver _svf_tv_loop)."""
    x = np.ascontiguousarray(x, dtype=np.float64)
    cutoff = np.ascontiguousarray(np.broadcast_to(np.asarray(cutoff, dtype=np.float64), x.shape))
    if HAS_NUMBA:
        return _svf_tv_loop(x, cutoff, float(res), float(sr), int(mode), float(drive))
    return _svf_tv_blocks(x, cutoff, float(res), float(sr), int(mode), float(drive))


@jit
def moog_ladder(x, cutoff, res, sr, drive):
    """Filtro escalera tipo Moog (modelo de Huovilainen simplificado, 24 dB/oct)."""
    n = x.shape[0]
    y = np.zeros(n)
    s0 = 0.0
    s1 = 0.0
    s2 = 0.0
    s3 = 0.0
    r = min(max(res, 0.0), 1.0) * 4.0
    for i in range(n):
        fc = min(max(cutoff[i], 10.0), sr * 0.45)
        g = 1.0 - np.exp(-2.0 * np.pi * fc / sr)
        inp = x[i] * (1.0 + drive * 3.0)
        u = np.tanh(inp - r * s3)
        s0 += g * (u - s0)
        s1 += g * (s0 - s1)
        s2 += g * (s1 - s2)
        s3 += g * (s2 - s3)
        y[i] = s3 * (1.0 + r * 0.5) / (1.0 + drive)
    return y


@jit
def fm_feedback(phase_c, phase_m, index_env, fb):
    """Operador modulador con realimentación sobre sí mismo -> portadora (DX7)."""
    n = phase_c.shape[0]
    out = np.zeros(n)
    prev1 = 0.0
    prev2 = 0.0
    for i in range(n):
        m = np.sin(2.0 * np.pi * phase_m[i] + fb * 0.5 * (prev1 + prev2))
        prev2 = prev1
        prev1 = m
        out[i] = np.sin(2.0 * np.pi * phase_c[i] + index_env[i] * m)
    return out


@jit
def karplus_strong(excitation, n, period, loss, damping, drum_blend, seed):
    """
    Karplus-Strong extendido: línea de retardo con afinación fraccional (paso-todo),
    filtro de amortiguamiento y mezcla de tambor.
    """
    np.random.seed(seed)
    N = int(np.floor(period - 0.5))
    if N < 2:
        N = 2
    frac = period - N - 0.5
    if frac < 0.0:
        frac = 0.0
    c = (1.0 - frac) / (1.0 + frac)
    buf = np.zeros(N)
    for i in range(min(N, excitation.shape[0])):
        buf[i] = excitation[i]
    y = np.zeros(n)
    idx = 0
    last = 0.0
    ap_x1 = 0.0
    ap_y1 = 0.0
    for i in range(n):
        cur = buf[idx]
        y[i] = cur
        # filtro de promedio ponderado (amortiguamiento de agudos)
        avg = (1.0 - damping * 0.5) * cur + damping * 0.5 * last
        last = cur
        v = loss * avg
        if drum_blend > 0.0 and np.random.random() < drum_blend:
            v = -v
        # paso-todo para afinación fraccional
        ap = c * v + ap_x1 - c * ap_y1
        ap_x1 = v
        ap_y1 = ap
        buf[idx] = ap
        idx += 1
        if idx >= N:
            idx = 0
    return y


@jit
def modulated_delay(x, delay_samples, feedback, mix):
    """Retardo modulado con interpolación lineal y realimentación (chorus / flanger / vibrato)."""
    n = x.shape[0]
    maxd = 0.0
    for i in range(n):
        if delay_samples[i] > maxd:
            maxd = delay_samples[i]
    size = int(maxd) + 4
    buf = np.zeros(size)
    w = 0
    y = np.zeros(n)
    for i in range(n):
        d = delay_samples[i]
        rp = w - d
        while rp < 0:
            rp += size
        i0 = int(rp)
        fr = rp - i0
        i1 = i0 + 1
        if i1 >= size:
            i1 = 0
        delayed = buf[i0] * (1.0 - fr) + buf[i1] * fr
        buf[w] = x[i] + feedback * delayed
        w += 1
        if w >= size:
            w = 0
        y[i] = (1.0 - mix) * x[i] + mix * delayed
    return y


@jit
def phaser(x, sweep, stages, feedback, mix):
    """Phaser: cascada de filtros paso-todo de primer orden con coeficiente modulado."""
    n = x.shape[0]
    zx = np.zeros(stages)
    zy = np.zeros(stages)
    y = np.zeros(n)
    fb = 0.0
    for i in range(n):
        a = sweep[i]
        v = x[i] + feedback * fb
        for s in range(stages):
            out = a * v + zx[s] - a * zy[s]
            zx[s] = v
            zy[s] = out
            v = out
        fb = v
        y[i] = (1.0 - mix) * x[i] + mix * v
    return y


@jit
def envelope_follower(x, att_coef, rel_coef):
    n = x.shape[0]
    env = np.zeros(n)
    e = 0.0
    for i in range(n):
        v = abs(x[i])
        if v > e:
            e = att_coef * e + (1.0 - att_coef) * v
        else:
            e = rel_coef * e + (1.0 - rel_coef) * v
        env[i] = e
    return env


@jit
def gain_computer_smooth(target_db, att_coef, rel_coef):
    """Suaviza la reducción de ganancia (en dB) con tiempos de ataque/relajación."""
    n = target_db.shape[0]
    out = np.zeros(n)
    g = 0.0
    for i in range(n):
        t = target_db[i]
        if t < g:   # más reducción -> ataque
            g = att_coef * g + (1.0 - att_coef) * t
        else:
            g = rel_coef * g + (1.0 - rel_coef) * t
        out[i] = g
    return out


def warmup():
    """Compila los núcleos (solo tiene efecto con numba)."""
    x = np.zeros(64)
    c = np.full(64, 1000.0)
    if HAS_NUMBA:
        _svf_tv_loop(x, c, 0.5, 44100.0, 0, 0.0)
    moog_ladder(x, c, 0.5, 44100.0, 0.0)
    fm_feedback(x, x, x, 0.1)
    karplus_strong(x, 64, 10.5, 0.99, 0.5, 0.0, 1)
    modulated_delay(x, np.full(64, 3.0), 0.1, 0.5)
    phaser(x, np.full(64, 0.5), 4, 0.2, 0.5)
    envelope_follower(x, 0.9, 0.99)
    gain_computer_smooth(x, 0.9, 0.99)


def comb_feedback(x, D, fb, damp=0.0):
    """
    Peine realimentado y[n] = x[n] + fb · LP(y)[n-D], con paso bajo de un polo (damp) en el lazo.
    Vectorizado por bloques de D muestras (rápido incluso para retardos largos, sin numba).
    """
    from scipy.signal import lfilter
    x = np.asarray(x, dtype=np.float64)
    if x.ndim == 2:
        return np.stack([comb_feedback(x[:, c], D, fb, damp) for c in range(x.shape[1])], axis=1)
    D = max(int(D), 1)
    n = len(x)
    y = x.copy()
    if fb == 0.0:
        return y
    b, a = [1.0 - damp], [1.0, -damp]
    zi = np.zeros(1)
    for start in range(D, n, D):
        prev = y[start - D:start]
        f, zi = lfilter(b, a, prev, zi=zi)
        end = min(start + D, n)
        y[start:end] += fb * f[:end - start]
    return y


def delay_samples(x, D):
    x = np.asarray(x, dtype=np.float64)
    D = int(D)
    if D <= 0:
        return x.copy()
    out = np.zeros_like(x)
    if D < len(x):
        out[D:] = x[:-D]
    return out


def schroeder_allpass(x, D, g):
    """Paso-todo de Schroeder/Freeverb: y = -x + w[n-D], w[n] = x[n] + g·w[n-D]."""
    w = comb_feedback(x, D, g, 0.0)
    return -x + delay_samples(w, D)
