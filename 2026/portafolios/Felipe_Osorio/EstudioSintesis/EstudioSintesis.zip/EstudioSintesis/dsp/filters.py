"""
Filtros. Cada filtro procesa audio (muestras, canales) y, cuando es posible,
devuelve su respuesta en frecuencia para dibujarla en la interfaz.
"""
from __future__ import annotations

import numpy as np
from scipy import signal

from .core import Param, Processor, LFO_SHAPES, as_2d, lfo
from . import kernels as K
from .synths import FORMANTS, VOWELS


class Effect(Processor):
    """Base de filtros y efectos."""
    tail: float = 0.0  # segundos de cola que añade el efecto

    @classmethod
    def process(cls, x: np.ndarray, sr: int, p: dict, ctx: dict) -> np.ndarray:
        raise NotImplementedError

    @classmethod
    def freq_response(cls, p: dict, sr: int):
        """Devuelve (frecuencias Hz, magnitud dB) o None."""
        return None


def _apply_ba_or_sos(x, sos=None, b=None, a=None, zero_phase=False):
    x = as_2d(x)
    if sos is not None:
        if zero_phase and len(x) > 3 * sos.shape[0] * 2 + 1:
            return signal.sosfiltfilt(sos, x, axis=0)
        return signal.sosfilt(sos, x, axis=0)
    if zero_phase and len(x) > 3 * max(len(a), len(b)):
        return signal.filtfilt(b, a, x, axis=0)
    return signal.lfilter(b, a, x, axis=0)


def _resp_sos(sos, sr):
    w, h = signal.sosfreqz(sos, worN=4096, fs=sr)
    return w, 20 * np.log10(np.maximum(np.abs(h), 1e-9))


def _resp_ba(b, a, sr):
    w, h = signal.freqz(b, a, worN=4096, fs=sr)
    return w, 20 * np.log10(np.maximum(np.abs(h), 1e-9))


# ===========================================================================
BAND_TYPES = {"paso bajo": "lowpass", "paso alto": "highpass", "paso banda": "bandpass",
              "rechaza banda": "bandstop"}
DESIGNS = {"Butterworth": "butter", "Chebyshev I": "cheby1", "Chebyshev II": "cheby2",
           "Elíptico (Cauer)": "ellip", "Bessel": "bessel"}


class ClassicIIR(Effect):
    name = "Filtro IIR clásico (Butterworth, Chebyshev, Elíptico, Bessel)"
    category = "Filtros"
    description = ("Diseños analógicos clásicos transformados a digitales. Butterworth: respuesta plana; "
                   "Chebyshev I/II: caída más abrupta con rizado; Elíptico: la más abrupta; Bessel: fase lineal.")
    params = [
        Param("design", "Diseño", "choice", "Butterworth", choices=list(DESIGNS.keys())),
        Param("btype", "Tipo", "choice", "paso bajo", choices=list(BAND_TYPES.keys())),
        Param("f1", "Frecuencia de corte / inferior", "float", 1000.0, 10.0, 20000.0, log=True, unit="Hz"),
        Param("f2", "Frecuencia superior (banda)", "float", 4000.0, 10.0, 20000.0, log=True, unit="Hz"),
        Param("order", "Orden", "int", 4, 1, 16),
        Param("rp", "Rizado banda de paso (Cheby I / Elíp.)", "float", 1.0, 0.01, 12.0, unit="dB"),
        Param("rs", "Atenuación banda de rechazo (Cheby II / Elíp.)", "float", 60.0, 10.0, 120.0, unit="dB"),
        Param("zero_phase", "Fase cero (filtfilt)", "bool", False,
              help="Filtra ida y vuelta: sin desfase, doble pendiente"),
    ]

    @classmethod
    def _sos(cls, p, sr):
        nyq = sr / 2 * 0.999
        bt = BAND_TYPES[p["btype"]]
        f1 = min(p["f1"], nyq)
        if bt in ("bandpass", "bandstop"):
            lo, hi = sorted((f1, min(p["f2"], nyq)))
            if hi - lo < 1:
                hi = min(lo + 1, nyq)
            wn = [lo, hi]
        else:
            wn = f1
        return signal.iirfilter(p["order"], wn, rp=p["rp"], rs=p["rs"], btype=bt,
                                ftype=DESIGNS[p["design"]], output="sos", fs=sr)

    @classmethod
    def process(cls, x, sr, p, ctx):
        return _apply_ba_or_sos(x, sos=cls._sos(p, sr), zero_phase=p["zero_phase"])

    @classmethod
    def freq_response(cls, p, sr):
        f, m = _resp_sos(cls._sos(p, sr), sr)
        return (f, 2 * m) if p["zero_phase"] else (f, m)


# ===========================================================================
BIQUAD_TYPES = ["pico (peaking EQ)", "estante graves (low shelf)", "estante agudos (high shelf)",
                "paso bajo", "paso alto", "paso banda", "notch", "paso todo"]


def rbj_biquad(kind, f0, q, gain_db, sr):
    """Coeficientes del 'Audio EQ Cookbook' de Robert Bristow-Johnson."""
    f0 = min(max(f0, 1.0), sr * 0.499)
    A = 10 ** (gain_db / 40)
    w0 = 2 * np.pi * f0 / sr
    cw, sw = np.cos(w0), np.sin(w0)
    alpha = sw / (2 * max(q, 1e-3))
    if kind.startswith("pico"):
        b = [1 + alpha * A, -2 * cw, 1 - alpha * A]
        a = [1 + alpha / A, -2 * cw, 1 - alpha / A]
    elif kind.startswith("estante graves"):
        sa = 2 * np.sqrt(A) * alpha
        b = [A * ((A + 1) - (A - 1) * cw + sa), 2 * A * ((A - 1) - (A + 1) * cw), A * ((A + 1) - (A - 1) * cw - sa)]
        a = [(A + 1) + (A - 1) * cw + sa, -2 * ((A - 1) + (A + 1) * cw), (A + 1) + (A - 1) * cw - sa]
    elif kind.startswith("estante agudos"):
        sa = 2 * np.sqrt(A) * alpha
        b = [A * ((A + 1) + (A - 1) * cw + sa), -2 * A * ((A - 1) + (A + 1) * cw), A * ((A + 1) + (A - 1) * cw - sa)]
        a = [(A + 1) - (A - 1) * cw + sa, 2 * ((A - 1) - (A + 1) * cw), (A + 1) - (A - 1) * cw - sa]
    elif kind == "paso bajo":
        b = [(1 - cw) / 2, 1 - cw, (1 - cw) / 2]
        a = [1 + alpha, -2 * cw, 1 - alpha]
    elif kind == "paso alto":
        b = [(1 + cw) / 2, -(1 + cw), (1 + cw) / 2]
        a = [1 + alpha, -2 * cw, 1 - alpha]
    elif kind == "paso banda":
        b = [alpha, 0, -alpha]
        a = [1 + alpha, -2 * cw, 1 - alpha]
    elif kind == "notch":
        b = [1, -2 * cw, 1]
        a = [1 + alpha, -2 * cw, 1 - alpha]
    else:
        b = [1 - alpha, -2 * cw, 1 + alpha]
        a = [1 + alpha, -2 * cw, 1 - alpha]
    b, a = np.array(b, float), np.array(a, float)
    return b / a[0], a / a[0]


class Biquad(Effect):
    name = "Biquad (EQ Cookbook RBJ)"
    category = "Filtros"
    description = "Filtro de segundo orden: pico, estantes, paso bajo/alto/banda, notch y paso todo. Q controla el ancho."
    params = [
        Param("kind", "Tipo", "choice", "pico (peaking EQ)", choices=BIQUAD_TYPES),
        Param("f0", "Frecuencia", "float", 1000.0, 10.0, 20000.0, log=True, unit="Hz"),
        Param("q", "Q", "float", 0.707, 0.1, 30.0, log=True),
        Param("gain", "Ganancia (pico/estantes)", "float", 6.0, -30.0, 30.0, unit="dB"),
        Param("stages", "Etapas en cascada", "int", 1, 1, 8),
    ]

    @classmethod
    def process(cls, x, sr, p, ctx):
        b, a = rbj_biquad(p["kind"], p["f0"], p["q"], p["gain"], sr)
        y = as_2d(x)
        for _ in range(p["stages"]):
            y = signal.lfilter(b, a, y, axis=0)
        return y

    @classmethod
    def freq_response(cls, p, sr):
        b, a = rbj_biquad(p["kind"], p["f0"], p["q"], p["gain"], sr)
        f, m = _resp_ba(b, a, sr)
        return f, m * p["stages"]


# ===========================================================================
class ParametricEQ(Effect):
    name = "Ecualizador paramétrico (5 bandas)"
    category = "Filtros"
    description = "Estante de graves + 3 bandas de pico + estante de agudos, con filtros paso alto/bajo opcionales."
    params = [
        Param("hp", "Paso alto (0 = off)", "float", 0.0, 0.0, 1000.0, unit="Hz", group="Cortes"),
        Param("lp", "Paso bajo (0 = off)", "float", 0.0, 0.0, 20000.0, unit="Hz", group="Cortes"),
        Param("ls_f", "Graves: frecuencia", "float", 120.0, 20.0, 1000.0, log=True, unit="Hz", group="Graves (estante)"),
        Param("ls_g", "Graves: ganancia", "float", 0.0, -18.0, 18.0, unit="dB", group="Graves (estante)"),
        Param("p1_f", "Banda 1: frecuencia", "float", 400.0, 20.0, 20000.0, log=True, unit="Hz", group="Banda 1"),
        Param("p1_g", "Banda 1: ganancia", "float", 0.0, -18.0, 18.0, unit="dB", group="Banda 1"),
        Param("p1_q", "Banda 1: Q", "float", 1.0, 0.1, 20.0, log=True, group="Banda 1"),
        Param("p2_f", "Banda 2: frecuencia", "float", 1500.0, 20.0, 20000.0, log=True, unit="Hz", group="Banda 2"),
        Param("p2_g", "Banda 2: ganancia", "float", 0.0, -18.0, 18.0, unit="dB", group="Banda 2"),
        Param("p2_q", "Banda 2: Q", "float", 1.0, 0.1, 20.0, log=True, group="Banda 2"),
        Param("p3_f", "Banda 3: frecuencia", "float", 5000.0, 20.0, 20000.0, log=True, unit="Hz", group="Banda 3"),
        Param("p3_g", "Banda 3: ganancia", "float", 0.0, -18.0, 18.0, unit="dB", group="Banda 3"),
        Param("p3_q", "Banda 3: Q", "float", 1.0, 0.1, 20.0, log=True, group="Banda 3"),
        Param("hs_f", "Agudos: frecuencia", "float", 8000.0, 1000.0, 20000.0, log=True, unit="Hz", group="Agudos (estante)"),
        Param("hs_g", "Agudos: ganancia", "float", 0.0, -18.0, 18.0, unit="dB", group="Agudos (estante)"),
    ]

    @classmethod
    def _sections(cls, p, sr):
        secs = []
        if p["hp"] > 0:
            secs.append(signal.butter(2, min(p["hp"], sr * 0.49), "highpass", fs=sr, output="ba"))
        if p["lp"] > 0:
            secs.append(signal.butter(2, min(p["lp"], sr * 0.49), "lowpass", fs=sr, output="ba"))
        if p["ls_g"]:
            secs.append(rbj_biquad("estante graves", p["ls_f"], 0.707, p["ls_g"], sr))
        for i in (1, 2, 3):
            if p[f"p{i}_g"]:
                secs.append(rbj_biquad("pico", p[f"p{i}_f"], p[f"p{i}_q"], p[f"p{i}_g"], sr))
        if p["hs_g"]:
            secs.append(rbj_biquad("estante agudos", p["hs_f"], 0.707, p["hs_g"], sr))
        return secs

    @classmethod
    def process(cls, x, sr, p, ctx):
        y = as_2d(x)
        for b, a in cls._sections(p, sr):
            y = signal.lfilter(b, a, y, axis=0)
        return y

    @classmethod
    def freq_response(cls, p, sr):
        f = np.linspace(0, sr / 2, 4096)
        tot = np.zeros_like(f)
        for b, a in cls._sections(p, sr):
            _, h = signal.freqz(b, a, worN=f, fs=sr)
            tot += 20 * np.log10(np.maximum(np.abs(h), 1e-9))
        return f, tot


# ===========================================================================
FIR_WINDOWS = ["hamming", "hann", "blackman", "blackmanharris", "kaiser", "rectangular"]


class FIRFilter(Effect):
    name = "Filtro FIR (ventana / sinc)"
    category = "Filtros"
    description = "Filtro de respuesta finita al impulso por el método de ventanas: fase lineal, estable siempre."
    params = [
        Param("btype", "Tipo", "choice", "paso bajo", choices=list(BAND_TYPES.keys())),
        Param("f1", "Corte / inferior", "float", 2000.0, 10.0, 20000.0, log=True, unit="Hz"),
        Param("f2", "Superior (banda)", "float", 6000.0, 10.0, 20000.0, log=True, unit="Hz"),
        Param("taps", "Nº de coeficientes (taps)", "int", 255, 3, 4095),
        Param("window", "Ventana", "choice", "hamming", choices=FIR_WINDOWS),
        Param("beta", "β (Kaiser)", "float", 8.6, 0.0, 20.0),
    ]

    @classmethod
    def _taps(cls, p, sr):
        n = p["taps"] | 1  # impar para permitir paso alto
        nyq = sr / 2 * 0.999
        bt = p["btype"]
        w = ("kaiser", p["beta"]) if p["window"] == "kaiser" else (
            "boxcar" if p["window"] == "rectangular" else p["window"])
        if bt in ("paso banda", "rechaza banda"):
            lo, hi = sorted((min(p["f1"], nyq), min(p["f2"], nyq)))
            return signal.firwin(n, [lo, max(hi, lo + 1)], window=w, fs=sr,
                                 pass_zero=(bt == "rechaza banda"))
        return signal.firwin(n, min(p["f1"], nyq), window=w, fs=sr, pass_zero=(bt == "paso bajo"))

    @classmethod
    def process(cls, x, sr, p, ctx):
        h = cls._taps(p, sr)
        x = as_2d(x)
        y = signal.fftconvolve(x, h[:, None], mode="full", axes=0)
        d = (len(h) - 1) // 2
        return y[d:d + len(x)]  # compensa el retardo de grupo

    @classmethod
    def freq_response(cls, p, sr):
        return _resp_ba(cls._taps(p, sr), [1.0], sr)


# ===========================================================================
SVF_MODES = {"paso bajo 12 dB (SVF)": 0, "paso banda (SVF)": 1, "paso alto 12 dB (SVF)": 2,
             "notch (SVF)": 3, "pico (SVF)": 4, "paso todo (SVF)": 5, "Moog escalera 24 dB": -1}


class ResonantFilter(Effect):
    name = "Filtro resonante modulable (SVF / Moog / auto-wah)"
    category = "Filtros"
    description = ("Filtro de estado variable o escalera Moog con corte modulable por LFO, "
                   "seguidor de envolvente (auto-wah) o barrido lineal/exponencial en el tiempo.")
    params = [
        Param("mode", "Modo", "choice", "paso bajo 12 dB (SVF)", choices=list(SVF_MODES.keys())),
        Param("cutoff", "Corte", "float", 800.0, 20.0, 20000.0, log=True, unit="Hz"),
        Param("res", "Resonancia", "float", 0.5, 0.0, 1.0),
        Param("drive", "Saturación", "float", 0.0, 0.0, 1.0),
        Param("mod", "Modulación del corte", "choice", "ninguna",
              choices=["ninguna", "LFO", "seguidor de envolvente (auto-wah)", "barrido en el tiempo"], group="Modulación"),
        Param("lfo_shape", "LFO forma", "choice", "seno", choices=LFO_SHAPES, group="Modulación"),
        Param("lfo_rate", "LFO velocidad", "float", 0.5, 0.01, 30.0, log=True, unit="Hz", group="Modulación"),
        Param("depth", "Profundidad (LFO / envolvente)", "float", 2.0, 0.0, 6.0, unit="oct", group="Modulación"),
        Param("env_sens", "Sensibilidad del seguidor", "float", 4.0, 0.1, 20.0, group="Modulación"),
        Param("sweep_to", "Barrido: corte final", "float", 8000.0, 20.0, 20000.0, log=True, unit="Hz", group="Modulación"),
        Param("mix", "Mezcla", "float", 1.0, 0.0, 1.0),
    ]

    @classmethod
    def process(cls, x, sr, p, ctx):
        x = as_2d(x)
        n = len(x)
        out = np.zeros_like(x)
        for c in range(x.shape[1]):
            xc = np.ascontiguousarray(x[:, c])
            octs = np.zeros(n)
            if p["mod"] == "LFO":
                octs = p["depth"] * lfo(p["lfo_shape"], p["lfo_rate"], n, sr, phase0=0.25 * c)
            elif p["mod"].startswith("seguidor"):
                att = np.exp(-1 / (0.005 * sr))
                rel = np.exp(-1 / (0.15 * sr))
                env = K.envelope_follower(xc, att, rel)
                octs = p["depth"] * np.clip(env * p["env_sens"], 0, 1)
            elif p["mod"].startswith("barrido"):
                octs = np.linspace(0, np.log2(p["sweep_to"] / p["cutoff"]), n)
            cut = p["cutoff"] * 2.0 ** octs
            m = SVF_MODES[p["mode"]]
            if m < 0:
                y = K.moog_ladder(xc, cut, p["res"], float(sr), p["drive"])
            else:
                y = K.svf_tv(xc, cut, p["res"], float(sr), m, p["drive"])
            out[:, c] = (1 - p["mix"]) * xc + p["mix"] * y
        return out

    @classmethod
    def freq_response(cls, p, sr):
        m = SVF_MODES[p["mode"]]
        if m < 0:
            return None
        # respuesta estática del SVF (equivalente analógico)
        k = 2.0 - 1.98 * p["res"]
        f = np.linspace(1, sr / 2, 4096)
        wc = np.tan(np.pi * min(p["cutoff"], sr * 0.49) / sr)
        s = 1j * np.tan(np.pi * f / sr) / wc
        d = s * s + k * s + 1
        H = {0: 1 / d, 1: s / d, 2: s * s / d, 3: (s * s + 1) / d, 4: (s * s - 1) / d,
             5: (s * s - k * s + 1) / d}[m]
        return f, 20 * np.log10(np.maximum(np.abs(H), 1e-9))


# ===========================================================================
class CombFilter(Effect):
    name = "Filtro peine (comb)"
    category = "Filtros"
    description = ("Suma de la señal con una copia retardada: picos/valles regularmente espaciados. "
                   "Realimentado produce resonancias afinadas (base de reverbs y del Karplus-Strong).")
    params = [
        Param("kind", "Tipo", "choice", "realimentado (IIR)", choices=["realimentado (IIR)", "prealimentado (FIR)"]),
        Param("tune", "Definir retardo por", "choice", "milisegundos", choices=["milisegundos", "frecuencia (Hz)"]),
        Param("delay_ms", "Retardo", "float", 5.0, 0.05, 100.0, log=True, unit="ms"),
        Param("freq", "Frecuencia de resonancia", "float", 220.0, 10.0, 10000.0, log=True, unit="Hz"),
        Param("gain", "Ganancia / realimentación", "float", 0.8, -0.999, 0.999),
        Param("mix", "Mezcla", "float", 1.0, 0.0, 1.0),
    ]
    tail = 1.0

    @classmethod
    def _ba(cls, p, sr):
        D = max(1, int(round(sr * p["delay_ms"] / 1000 if p["tune"] == "milisegundos" else sr / p["freq"])))
        if p["kind"].startswith("realimentado"):
            a = np.zeros(D + 1)
            a[0], a[D] = 1.0, -p["gain"]
            return np.array([1 - abs(p["gain"])]), a
        b = np.zeros(D + 1)
        b[0], b[D] = 1.0, p["gain"]
        return b / (1 + abs(p["gain"])), np.array([1.0])

    @classmethod
    def process(cls, x, sr, p, ctx):
        x = as_2d(x)
        g = p["gain"]
        D = max(1, int(round(sr * p["delay_ms"] / 1000 if p["tune"] == "milisegundos" else sr / p["freq"])))
        if p["kind"].startswith("realimentado"):
            y = K.comb_feedback(x * (1 - abs(g)), D, g, 0.0)
        else:
            y = (x + g * K.delay_samples(x, D)) / (1 + abs(g))
        return (1 - p["mix"]) * x + p["mix"] * y

    @classmethod
    def freq_response(cls, p, sr):
        return _resp_ba(*cls._ba(p, sr), sr)


# ===========================================================================
class FormantFilter(Effect):
    name = "Filtro de formantes (vocal)"
    category = "Filtros"
    description = "Banco de 5 filtros paso banda en las formantes de una vocal; puede transitar entre dos vocales (efecto 'talk box')."
    params = [
        Param("vowel_a", "Vocal inicial", "choice", "a", choices=VOWELS),
        Param("vowel_b", "Vocal final", "choice", "i", choices=VOWELS),
        Param("morph", "Transición", "choice", "barrido", choices=["fija (vocal inicial)", "barrido", "LFO"]),
        Param("lfo_rate", "LFO velocidad", "float", 1.0, 0.05, 20.0, log=True, unit="Hz"),
        Param("shift", "Desplazamiento de formantes", "float", 1.0, 0.5, 2.0),
        Param("q_scale", "Escala de resonancia", "float", 1.0, 0.3, 3.0),
        Param("mix", "Mezcla", "float", 1.0, 0.0, 1.0),
    ]

    @classmethod
    def process(cls, x, sr, p, ctx):
        x = as_2d(x)
        n = len(x)
        if p["morph"].startswith("fija"):
            m = np.zeros(n)
        elif p["morph"] == "barrido":
            m = np.linspace(0, 1, n)
        else:
            m = 0.5 + 0.5 * lfo("seno", p["lfo_rate"], n, sr)
        fa, ba, ga = FORMANTS[p["vowel_a"]]
        fb, bb, gb = FORMANTS[p["vowel_b"]]
        out = np.zeros_like(x)
        for c in range(x.shape[1]):
            xc = np.ascontiguousarray(x[:, c])
            acc = np.zeros(n)
            for i in range(5):
                F = ((1 - m) * fa[i] + m * fb[i]) * p["shift"]
                B = ((1 - m[0]) * ba[i] + m[0] * bb[i]) / p["q_scale"]
                G = 10 ** (((1 - m) * ga[i] + m * gb[i]) / 20)
                k = float(np.clip(B / max(fa[i], 1), 0.02, 2.0))
                acc += G * k * K.svf_tv(xc, F, (2 - k) / 1.98, float(sr), 1, 0.0)
            pk_in = np.max(np.abs(xc)) or 1
            pk = np.max(np.abs(acc)) or 1
            acc *= pk_in / pk
            out[:, c] = (1 - p["mix"]) * xc + p["mix"] * acc
        return out


FILTERS = [ClassicIIR, Biquad, ParametricEQ, FIRFilter, ResonantFilter, CombFilter, FormantFilter]
