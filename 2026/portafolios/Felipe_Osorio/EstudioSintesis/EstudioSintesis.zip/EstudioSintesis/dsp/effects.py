"""
Efectos: dinámica, distorsión, tiempo (delay/reverb), modulación, tono/tiempo, espectrales y utilidades.
"""
from __future__ import annotations

import os

import numpy as np
from scipy import signal

from .core import Param, LFO_SHAPES, as_2d, lfo, db_to_lin, lin_to_db
from . import kernels as K
from .filters import Effect, FILTERS


def _pad(x, seconds, sr):
    x = as_2d(x)
    return np.vstack([x, np.zeros((int(seconds * sr), x.shape[1]))])


def _trim_tail(y, n_min, thresh=1e-5):
    nz = np.nonzero(np.max(np.abs(y), axis=1) > thresh)[0]
    end = max(n_min, (nz[-1] + 1) if len(nz) else 0)
    return y[:end]


def _stereo(x):
    x = as_2d(x)
    return np.repeat(x, 2, axis=1) if x.shape[1] == 1 else x


# ============================== UTILIDADES =================================
class Gain(Effect):
    name = "Ganancia / Normalizar"
    category = "Utilidades"
    description = "Cambia el volumen en dB o normaliza al pico o nivel RMS indicado."
    params = [
        Param("mode", "Modo", "choice", "ganancia", choices=["ganancia", "normalizar pico", "normalizar RMS"]),
        Param("gain", "Ganancia", "float", 0.0, -60.0, 24.0, unit="dB"),
        Param("target", "Nivel objetivo", "float", -1.0, -40.0, 0.0, unit="dBFS"),
    ]

    @classmethod
    def process(cls, x, sr, p, ctx):
        x = as_2d(x)
        if p["mode"] == "ganancia":
            return x * db_to_lin(p["gain"])
        if p["mode"] == "normalizar pico":
            pk = np.max(np.abs(x)) or 1
            return x / pk * db_to_lin(p["target"])
        rms = np.sqrt(np.mean(x ** 2)) or 1
        return x / rms * db_to_lin(p["target"])


class Fade(Effect):
    name = "Fundido de entrada / salida"
    category = "Utilidades"
    description = "Fade in y fade out con curva lineal, exponencial, logarítmica o de potencia constante."
    params = [
        Param("fin", "Fade in", "float", 0.05, 0.0, 30.0, unit="s"),
        Param("fout", "Fade out", "float", 0.5, 0.0, 30.0, unit="s"),
        Param("curve", "Curva", "choice", "lineal", choices=["lineal", "exponencial", "logarítmica", "potencia constante"]),
    ]

    @staticmethod
    def _shape(n, curve):
        t = np.linspace(0, 1, n)
        return {"lineal": t, "exponencial": t ** 3, "logarítmica": 1 - (1 - t) ** 3,
                "potencia constante": np.sin(t * np.pi / 2)}[curve]

    @classmethod
    def process(cls, x, sr, p, ctx):
        y = as_2d(x).copy()
        n = len(y)
        a = min(int(p["fin"] * sr), n)
        b = min(int(p["fout"] * sr), n)
        if a > 0:
            y[:a] *= cls._shape(a, p["curve"])[:, None]
        if b > 0:
            y[n - b:] *= cls._shape(b, p["curve"])[::-1, None]
        return y


class Utility(Effect):
    name = "Utilidades (invertir, polaridad, DC, canales)"
    category = "Utilidades"
    description = "Operaciones básicas de edición sobre la señal."
    params = [
        Param("op", "Operación", "choice", "invertir en el tiempo (reverse)",
              choices=["invertir en el tiempo (reverse)", "invertir polaridad", "quitar DC",
                       "convertir a mono", "convertir a estéreo", "intercambiar canales L/R",
                       "rectificar (valor absoluto)"]),
    ]

    @classmethod
    def process(cls, x, sr, p, ctx):
        x = as_2d(x)
        op = p["op"]
        if op.startswith("invertir en"):
            return x[::-1].copy()
        if op == "invertir polaridad":
            return -x
        if op == "quitar DC":
            b, a = signal.butter(1, 10, "highpass", fs=sr)
            return signal.filtfilt(b, a, x, axis=0) if len(x) > 12 else x - x.mean(axis=0)
        if op == "convertir a mono":
            return x.mean(axis=1, keepdims=True)
        if op == "convertir a estéreo":
            return _stereo(x)
        if op.startswith("intercambiar"):
            return x[:, ::-1].copy() if x.shape[1] == 2 else x
        return np.abs(x)


class Pan(Effect):
    name = "Paneo / Ancho estéreo"
    category = "Utilidades"
    description = "Posición en el campo estéreo y ancho (procesado Mid/Side)."
    params = [
        Param("pan", "Paneo (-1 izq … 1 der)", "float", 0.0, -1.0, 1.0),
        Param("width", "Ancho (0 = mono, 1 = original, 2 = extra ancho)", "float", 1.0, 0.0, 2.0),
    ]

    @classmethod
    def process(cls, x, sr, p, ctx):
        x = _stereo(x)
        mid = (x[:, 0] + x[:, 1]) / 2
        side = (x[:, 0] - x[:, 1]) / 2 * p["width"]
        L, R = mid + side, mid - side
        th = (p["pan"] + 1) * np.pi / 4
        return np.stack([L * np.cos(th) * np.sqrt(2), R * np.sin(th) * np.sqrt(2)], axis=1)


# ============================== DISTORSIÓN =================================
class Distortion(Effect):
    name = "Distorsión / Saturación"
    category = "Distorsión"
    description = "Varias funciones de recorte no lineal, con control de tono y mezcla."
    params = [
        Param("kind", "Tipo", "choice", "saturación suave (tanh)",
              choices=["saturación suave (tanh)", "recorte duro (hard clip)", "plegado (foldback)",
                       "válvula asimétrica", "arcotangente", "rectificador onda completa",
                       "rectificador media onda", "fuzz (exponencial)"]),
        Param("drive", "Drive", "float", 12.0, 0.0, 60.0, unit="dB"),
        Param("tone", "Tono (paso bajo post)", "float", 12000.0, 200.0, 20000.0, log=True, unit="Hz"),
        Param("mix", "Mezcla", "float", 1.0, 0.0, 1.0),
        Param("out", "Salida", "float", -6.0, -40.0, 12.0, unit="dB"),
    ]

    @classmethod
    def process(cls, x, sr, p, ctx):
        x = as_2d(x)
        g = db_to_lin(p["drive"])
        v = x * g
        k = p["kind"]
        if k.startswith("saturación"):
            y = np.tanh(v)
        elif k.startswith("recorte"):
            y = np.clip(v, -1, 1)
        elif k.startswith("plegado"):
            y = np.abs(((v - 1) % 4) - 2) - 1
        elif k.startswith("válvula"):
            y = np.where(v >= 0, np.tanh(v), np.tanh(0.6 * v) / 0.6 * 0.8)
            y = y - np.mean(y, axis=0)
        elif k.startswith("arco"):
            y = 2 / np.pi * np.arctan(v)
        elif k == "rectificador onda completa":
            y = np.abs(np.tanh(v)) * 2 - 1
        elif k == "rectificador media onda":
            y = np.maximum(np.tanh(v), 0) * 2 - 1
        else:
            y = np.sign(v) * (1 - np.exp(-np.abs(v)))
        if k.startswith("rectificador"):
            y = y - np.mean(y, axis=0)
        if p["tone"] < sr / 2 * 0.95:
            b, a = signal.butter(2, p["tone"], fs=sr)
            y = signal.lfilter(b, a, y, axis=0)
        return ((1 - p["mix"]) * x + p["mix"] * y) * db_to_lin(p["out"])


class Bitcrusher(Effect):
    name = "Bitcrusher (reducción de bits / muestreo)"
    category = "Distorsión"
    description = "Cuantiza la amplitud a menos bits y reduce la frecuencia de muestreo (aliasing intencional)."
    params = [
        Param("bits", "Resolución", "float", 8.0, 1.0, 24.0, unit="bits"),
        Param("down", "Reducción de muestreo (factor)", "int", 4, 1, 64),
        Param("mix", "Mezcla", "float", 1.0, 0.0, 1.0),
    ]

    @classmethod
    def process(cls, x, sr, p, ctx):
        x = as_2d(x)
        q = 2 ** (p["bits"] - 1)
        y = np.round(x * q) / q
        d = p["down"]
        if d > 1:
            idx = (np.arange(len(y)) // d) * d
            y = y[idx]
        return (1 - p["mix"]) * x + p["mix"] * y


# ============================== DINÁMICA ===================================
class Compressor(Effect):
    name = "Compresor / Limitador"
    category = "Dinámica"
    description = "Compresor feed-forward con rodilla suave, ataque/relajación y ganancia de compensación."
    params = [
        Param("thresh", "Umbral", "float", -18.0, -60.0, 0.0, unit="dB"),
        Param("ratio", "Razón (≥ 20 ≈ limitador)", "float", 4.0, 1.0, 50.0, log=True, unit=":1"),
        Param("knee", "Rodilla", "float", 6.0, 0.0, 24.0, unit="dB"),
        Param("attack", "Ataque", "float", 10.0, 0.1, 200.0, log=True, unit="ms"),
        Param("release", "Relajación", "float", 120.0, 5.0, 2000.0, log=True, unit="ms"),
        Param("makeup", "Ganancia de compensación", "float", 0.0, -12.0, 30.0, unit="dB"),
        Param("auto", "Compensación automática", "bool", True),
        Param("link", "Enlazar canales estéreo", "bool", True),
    ]

    @classmethod
    def process(cls, x, sr, p, ctx):
        x = as_2d(x)
        det = np.max(np.abs(x), axis=1, keepdims=True) if p["link"] else np.abs(x)
        T, R, W = p["thresh"], p["ratio"], p["knee"]
        att = np.exp(-1 / (p["attack"] / 1000 * sr))
        rel = np.exp(-1 / (p["release"] / 1000 * sr))
        out = np.zeros_like(x)
        for c in range(det.shape[1]):
            lv = lin_to_db(det[:, c])
            over = lv - T
            gr = np.where(over <= -W / 2, 0.0,
                          np.where(over >= W / 2, over * (1 / R - 1),
                                   (1 / R - 1) * (over + W / 2) ** 2 / (2 * max(W, 1e-6))))
            gr = K.gain_computer_smooth(np.ascontiguousarray(gr), att, rel)
            mk = p["makeup"] + (-(T * (1 / R - 1)) / 2 if p["auto"] else 0)
            g = 10 ** ((gr + mk) / 20)
            if p["link"]:
                out = x * g[:, None]
                break
            out[:, c] = x[:, c] * g
        return out


class Gate(Effect):
    name = "Puerta de ruido / Expansor"
    category = "Dinámica"
    description = "Atenúa la señal cuando cae por debajo del umbral."
    params = [
        Param("thresh", "Umbral", "float", -40.0, -90.0, 0.0, unit="dB"),
        Param("range", "Atenuación máxima", "float", -80.0, -90.0, 0.0, unit="dB"),
        Param("attack", "Ataque", "float", 1.0, 0.1, 100.0, log=True, unit="ms"),
        Param("release", "Relajación", "float", 100.0, 5.0, 2000.0, log=True, unit="ms"),
    ]

    @classmethod
    def process(cls, x, sr, p, ctx):
        x = as_2d(x)
        det = np.max(np.abs(x), axis=1)
        env = K.envelope_follower(np.ascontiguousarray(det), np.exp(-1 / (0.001 * sr)), np.exp(-1 / (0.05 * sr)))
        target = np.where(lin_to_db(env) < p["thresh"], p["range"], 0.0)
        g = K.gain_computer_smooth(target, np.exp(-1 / (p["attack"] / 1000 * sr)),
                                   np.exp(-1 / (p["release"] / 1000 * sr)))
        # en la puerta 'ataque' = abrir (subir ganancia): invertimos los roles
        return x * (10 ** (g / 20))[:, None]


# ============================== TIEMPO =====================================
class Delay(Effect):
    name = "Delay / Eco"
    category = "Tiempo y espacio"
    description = "Eco con realimentación, amortiguamiento de agudos en la realimentación y modo ping-pong estéreo."
    params = [
        Param("time", "Tiempo", "float", 350.0, 1.0, 3000.0, log=True, unit="ms"),
        Param("feedback", "Realimentación", "float", 0.45, 0.0, 0.98),
        Param("damp", "Amortiguamiento", "float", 0.3, 0.0, 0.95),
        Param("mix", "Mezcla", "float", 0.35, 0.0, 1.0),
        Param("pingpong", "Ping-pong estéreo", "bool", False),
        Param("tail", "Cola añadida", "float", 3.0, 0.0, 20.0, unit="s"),
    ]

    @classmethod
    def _train(cls, x, D, loop, fb, d):
        """Tren de ecos: primera repetición (ganancia 1) a D muestras, luego cada `loop` con ganancia fb."""
        return K.delay_samples(K.comb_feedback(x, loop, fb, d), D)

    @classmethod
    def process(cls, x, sr, p, ctx):
        n0 = len(x)
        x = _pad(x, p["tail"], sr)
        D = max(2, int(p["time"] / 1000 * sr))
        fb, d = p["feedback"], p["damp"]
        if p["pingpong"]:
            x = _stereo(x)
            mono = x.mean(axis=1)
            wr = cls._train(mono, D, 2 * D, fb * fb, d)
            wl = fb * cls._train(mono, 2 * D, 2 * D, fb * fb, d)
            wet = np.stack([wl, wr], axis=1)
        else:
            wet = cls._train(x, D, D, fb, d)
        y = (1 - p["mix"]) * x + p["mix"] * wet
        return _trim_tail(y, n0)


class Reverb(Effect):
    name = "Reverberación algorítmica (Freeverb)"
    category = "Tiempo y espacio"
    description = "Reverb de Schroeder/Moorer (8 peines con amortiguamiento + 4 paso-todo por canal)."
    params = [
        Param("room", "Tamaño de sala", "float", 0.8, 0.0, 0.99),
        Param("damp", "Amortiguamiento", "float", 0.4, 0.0, 1.0),
        Param("predelay", "Pre-retardo", "float", 20.0, 0.0, 300.0, unit="ms"),
        Param("width", "Ancho estéreo", "float", 1.0, 0.0, 1.0),
        Param("wet", "Nivel húmedo", "float", 0.35, 0.0, 1.0),
        Param("dry", "Nivel seco", "float", 0.8, 0.0, 1.0),
        Param("tail", "Cola añadida", "float", 4.0, 0.0, 20.0, unit="s"),
    ]
    COMBS = [1116, 1188, 1277, 1356, 1422, 1491, 1557, 1617]
    APS = [556, 441, 341, 225]

    @classmethod
    def _tank(cls, x, sr, room, damp, spread):
        s = sr / 44100
        fb = 0.7 + 0.28 * room
        d = damp * 0.4
        acc = np.zeros_like(x)
        for L in cls.COMBS:  # peines con paso bajo en la realimentación (Moorer / Freeverb)
            D = max(2, int((L + spread) * s))
            acc += K.delay_samples(K.comb_feedback(x, D, fb, d), D)
        y = acc * 0.03
        for L in cls.APS:
            y = K.schroeder_allpass(y, max(2, int((L + spread) * s)), 0.5)
        return y

    @classmethod
    def process(cls, x, sr, p, ctx):
        n0 = len(x)
        x = _pad(x, p["tail"], sr)
        pre = int(p["predelay"] / 1000 * sr)
        mono = x.mean(axis=1)
        if pre > 0:
            mono = np.concatenate([np.zeros(pre), mono[:-pre]])
        l = cls._tank(mono, sr, p["room"], p["damp"], 0)
        r = cls._tank(mono, sr, p["room"], p["damp"], 23)
        w = p["width"]
        wl = l * (0.5 + w / 2) + r * (0.5 - w / 2)
        wr = r * (0.5 + w / 2) + l * (0.5 - w / 2)
        xs = _stereo(x)
        y = p["dry"] * xs + p["wet"] * np.stack([wl, wr], axis=1)
        return _trim_tail(y, n0)


class ConvolutionReverb(Effect):
    name = "Reverberación por convolución"
    category = "Tiempo y espacio"
    description = ("Convoluciona con una respuesta al impulso (IR) cargada desde un archivo de audio, "
                   "o con una IR sintética de ruido con decaimiento exponencial.")
    params = [
        Param("ir_file", "Archivo IR (vacío = sintética)", "file", ""),
        Param("decay", "IR sintética: RT60", "float", 2.5, 0.1, 20.0, log=True, unit="s"),
        Param("bright", "IR sintética: brillo", "float", 0.5, 0.0, 1.0),
        Param("wet", "Nivel húmedo", "float", 0.4, 0.0, 1.0),
        Param("dry", "Nivel seco", "float", 0.8, 0.0, 1.0),
    ]

    @classmethod
    def process(cls, x, sr, p, ctx):
        x = as_2d(x)
        ir = None
        if p["ir_file"] and os.path.isfile(p["ir_file"]):
            from audio_io import load_audio
            ir, isr = load_audio(p["ir_file"])
            if isr != sr:
                ir = signal.resample_poly(ir, sr, isr, axis=0)
        if ir is None:
            L = int(p["decay"] * sr)
            rng = np.random.default_rng(3)
            t = np.arange(L) / sr
            env = 10 ** (-3 * t / p["decay"])
            nz = rng.standard_normal((L, 2))
            b, a = signal.butter(1, 500 + p["bright"] * 15000, fs=sr)
            nz = signal.lfilter(b, a, nz, axis=0)
            ir = nz * env[:, None]
        ir = as_2d(ir)
        ir = ir / (np.sqrt(np.sum(ir ** 2, axis=0)) + 1e-12)
        ch = max(x.shape[1], ir.shape[1])
        xs = np.repeat(x, ch, axis=1) if x.shape[1] < ch else x
        irs = np.repeat(ir, ch, axis=1) if ir.shape[1] < ch else ir
        wet = signal.fftconvolve(xs, irs, axes=0)
        wet /= (np.max(np.abs(wet)) or 1) / (np.max(np.abs(xs)) or 1)
        y = np.vstack([xs, np.zeros((len(wet) - len(xs), ch))]) * p["dry"] + p["wet"] * wet
        return _trim_tail(y, len(x))


# ============================== MODULACIÓN =================================
class Chorus(Effect):
    name = "Chorus"
    category = "Modulación"
    description = "Varias copias con retardo modulado lentamente: engrosa y ensancha el sonido."
    params = [
        Param("voices", "Voces", "int", 3, 1, 8),
        Param("rate", "Velocidad", "float", 0.8, 0.01, 10.0, log=True, unit="Hz"),
        Param("depth", "Profundidad", "float", 3.0, 0.1, 20.0, unit="ms"),
        Param("delay", "Retardo base", "float", 15.0, 1.0, 50.0, unit="ms"),
        Param("mix", "Mezcla", "float", 0.5, 0.0, 1.0),
        Param("stereo", "Estéreo", "bool", True),
    ]

    @classmethod
    def process(cls, x, sr, p, ctx):
        x = _stereo(x) if p["stereo"] else as_2d(x)
        n = len(x)
        out = np.zeros_like(x)
        V = p["voices"]
        for c in range(x.shape[1]):
            xc = np.ascontiguousarray(x[:, c])
            wet = np.zeros(n)
            for v in range(V):
                ph = v / V + 0.25 * c
                d = (p["delay"] + p["depth"] * 0.5 * (1 + lfo("seno", p["rate"] * (1 + 0.1 * v), n, sr, ph))) / 1000 * sr
                wet += K.modulated_delay(xc, d, 0.0, 1.0)
            out[:, c] = (1 - p["mix"]) * xc + p["mix"] * wet / V
        return out


class Flanger(Effect):
    name = "Flanger"
    category = "Modulación"
    description = "Retardo muy corto modulado con realimentación: filtro peine en barrido ('jet')."
    params = [
        Param("rate", "Velocidad", "float", 0.25, 0.01, 10.0, log=True, unit="Hz"),
        Param("depth", "Profundidad", "float", 2.0, 0.05, 10.0, unit="ms"),
        Param("delay", "Retardo mínimo", "float", 0.5, 0.05, 10.0, unit="ms"),
        Param("feedback", "Realimentación", "float", 0.6, -0.95, 0.95),
        Param("mix", "Mezcla", "float", 0.5, 0.0, 1.0),
        Param("shape", "Forma LFO", "choice", "triangular", choices=LFO_SHAPES[:4]),
    ]

    @classmethod
    def process(cls, x, sr, p, ctx):
        x = as_2d(x)
        n = len(x)
        out = np.zeros_like(x)
        for c in range(x.shape[1]):
            m = 0.5 * (1 + lfo(p["shape"], p["rate"], n, sr, 0.25 * c))
            d = (p["delay"] + p["depth"] * m) / 1000 * sr
            out[:, c] = K.modulated_delay(np.ascontiguousarray(x[:, c]), d, p["feedback"], p["mix"])
        return out


class Phaser(Effect):
    name = "Phaser"
    category = "Modulación"
    description = "Cadena de filtros paso-todo cuya frecuencia se modula: muescas móviles en el espectro."
    params = [
        Param("stages", "Etapas paso-todo", "int", 6, 2, 16),
        Param("rate", "Velocidad", "float", 0.4, 0.01, 10.0, log=True, unit="Hz"),
        Param("fmin", "Frecuencia mínima", "float", 300.0, 20.0, 5000.0, log=True, unit="Hz"),
        Param("fmax", "Frecuencia máxima", "float", 3000.0, 100.0, 18000.0, log=True, unit="Hz"),
        Param("feedback", "Realimentación", "float", 0.5, -0.95, 0.95),
        Param("mix", "Mezcla", "float", 0.5, 0.0, 1.0),
    ]

    @classmethod
    def process(cls, x, sr, p, ctx):
        x = as_2d(x)
        n = len(x)
        out = np.zeros_like(x)
        for c in range(x.shape[1]):
            m = 0.5 * (1 + lfo("seno", p["rate"], n, sr, 0.25 * c))
            f = p["fmin"] * (p["fmax"] / p["fmin"]) ** m
            t = np.tan(np.pi * np.minimum(f, sr * 0.49) / sr)
            a = (t - 1) / (t + 1)
            out[:, c] = K.phaser(np.ascontiguousarray(x[:, c]), a, p["stages"], p["feedback"], p["mix"])
        return out


class Tremolo(Effect):
    name = "Trémolo / Auto-paneo"
    category = "Modulación"
    description = "Modulación periódica de la amplitud o de la posición estéreo."
    params = [
        Param("mode", "Modo", "choice", "trémolo", choices=["trémolo", "auto-paneo"]),
        Param("shape", "Forma", "choice", "seno", choices=LFO_SHAPES),
        Param("rate", "Velocidad", "float", 5.0, 0.05, 40.0, log=True, unit="Hz"),
        Param("depth", "Profundidad", "float", 0.7, 0.0, 1.0),
    ]

    @classmethod
    def process(cls, x, sr, p, ctx):
        x = as_2d(x)
        n = len(x)
        m = lfo(p["shape"], p["rate"], n, sr)
        if p["mode"] == "trémolo":
            return x * (1 - p["depth"] * 0.5 * (1 + m))[:, None]
        x = _stereo(x)
        th = (p["depth"] * m + 1) * np.pi / 4
        mono = x.mean(axis=1)
        return np.stack([mono * np.cos(th), mono * np.sin(th)], axis=1) * np.sqrt(2)


class RingMod(Effect):
    name = "Modulador en anillo"
    category = "Modulación"
    description = "Multiplica la señal por un oscilador: produce frecuencias suma y diferencia (sonidos metálicos, robóticos)."
    params = [
        Param("freq", "Frecuencia", "float", 440.0, 0.1, 10000.0, log=True, unit="Hz"),
        Param("shape", "Forma", "choice", "seno", choices=["seno", "triangular", "sierra", "cuadrada"]),
        Param("lfo_rate", "Modulación de frecuencia: velocidad", "float", 0.0, 0.0, 20.0, unit="Hz"),
        Param("lfo_depth", "Modulación de frecuencia: profundidad", "float", 0.0, 0.0, 4.0, unit="oct"),
        Param("mix", "Mezcla", "float", 1.0, 0.0, 1.0),
    ]

    @classmethod
    def process(cls, x, sr, p, ctx):
        from .core import oscillator
        x = as_2d(x)
        n = len(x)
        f = p["freq"]
        if p["lfo_rate"] > 0 and p["lfo_depth"] > 0:
            f = f * 2 ** (p["lfo_depth"] * lfo("seno", p["lfo_rate"], n, sr))
        m = oscillator(p["shape"], f, n, sr)
        return (1 - p["mix"]) * x + p["mix"] * x * m[:, None]


class Vibrato(Effect):
    name = "Vibrato (modulación de tono)"
    category = "Modulación"
    description = "Retardo modulado 100% húmedo: variación periódica de la altura."
    params = [
        Param("rate", "Velocidad", "float", 5.5, 0.1, 20.0, unit="Hz"),
        Param("depth", "Profundidad", "float", 30.0, 1.0, 200.0, unit="cents"),
    ]

    @classmethod
    def process(cls, x, sr, p, ctx):
        x = as_2d(x)
        n = len(x)
        # amplitud del retardo que produce la desviación de tono deseada
        ratio = 2 ** (p["depth"] / 1200) - 1
        amp = ratio * sr / (2 * np.pi * p["rate"])
        d = amp * (1 + lfo("seno", p["rate"], n, sr)) + 2
        out = np.zeros_like(x)
        for c in range(x.shape[1]):
            out[:, c] = K.modulated_delay(np.ascontiguousarray(x[:, c]), d, 0.0, 1.0)
        return out


# ============================== TONO Y TIEMPO ===============================
def _stft(x, N, H):
    w = np.hanning(N)
    x = np.concatenate([np.zeros(N), x, np.zeros(N)])
    frames = 1 + (len(x) - N) // H
    idx = np.arange(N)[None, :] + H * np.arange(frames)[:, None]
    return np.fft.rfft(x[idx] * w, axis=1)


def _istft(X, N, H, length):
    w = np.hanning(N)
    frames = X.shape[0]
    out = np.zeros(N + H * (frames - 1))
    norm = np.zeros_like(out)
    fr = np.fft.irfft(X, n=N, axis=1) * w
    for i in range(frames):
        out[i * H:i * H + N] += fr[i]
        norm[i * H:i * H + N] += w ** 2
    out /= np.maximum(norm, 1e-8)
    return out[N:N + length]


def phase_vocoder_stretch(x, factor, N=2048, H=None):
    """Estira la duración por `factor` (2 = el doble de largo) sin cambiar la altura."""
    H = H or N // 4
    X = _stft(x, N, H)
    Ha = H
    Hs = H
    steps = np.arange(0, X.shape[0] - 1, 1 / factor)
    omega = 2 * np.pi * np.arange(N // 2 + 1) * Ha / N
    phase = np.angle(X[0])
    Y = np.zeros((len(steps), X.shape[1]), complex)
    for k, s in enumerate(steps):
        i = int(s)
        fr = s - i
        mag = (1 - fr) * np.abs(X[i]) + fr * np.abs(X[i + 1])
        Y[k] = mag * np.exp(1j * phase)
        dphi = np.angle(X[i + 1]) - np.angle(X[i]) - omega
        dphi -= 2 * np.pi * np.round(dphi / (2 * np.pi))
        phase += omega + dphi
    return _istft(Y, N, Hs, int(len(x) * factor))


class TimeStretch(Effect):
    name = "Estiramiento temporal (vocoder de fase)"
    category = "Tono y tiempo"
    description = "Cambia la duración sin alterar la altura (técnica muy usada en música electroacústica)."
    params = [
        Param("factor", "Factor de duración", "float", 2.0, 0.1, 16.0, log=True,
              help="2 = el doble de largo, 0.5 = la mitad"),
        Param("fft", "Tamaño FFT", "choice", "2048", choices=["512", "1024", "2048", "4096", "8192"]),
    ]

    @classmethod
    def process(cls, x, sr, p, ctx):
        x = as_2d(x)
        N = int(p["fft"])
        cols = [phase_vocoder_stretch(x[:, c], p["factor"], N) for c in range(x.shape[1])]
        return np.stack(cols, axis=1)


class PitchShift(Effect):
    name = "Transposición (cambio de tono)"
    category = "Tono y tiempo"
    description = ("Transpone en semitonos. 'Conservar duración' usa vocoder de fase + remuestreo; "
                   "si no, cambia la velocidad como una cinta (varispeed).")
    params = [
        Param("semis", "Semitonos", "float", 7.0, -36.0, 36.0, unit="st"),
        Param("cents", "Ajuste fino", "float", 0.0, -100.0, 100.0, unit="cents"),
        Param("keep", "Conservar duración", "bool", True),
        Param("fft", "Tamaño FFT", "choice", "2048", choices=["512", "1024", "2048", "4096"]),
    ]

    @classmethod
    def process(cls, x, sr, p, ctx):
        x = as_2d(x)
        r = 2 ** ((p["semis"] + p["cents"] / 100) / 12)
        cols = []
        for c in range(x.shape[1]):
            xc = x[:, c]
            if p["keep"]:
                xc = phase_vocoder_stretch(xc, r, int(p["fft"]))
            n_out = max(int(len(xc) / r), 1)
            cols.append(np.interp(np.arange(n_out) * r, np.arange(len(xc)), xc))
        m = min(len(c) for c in cols)
        return np.stack([c[:m] for c in cols], axis=1)


# ============================== ESPECTRALES ================================
class Spectral(Effect):
    name = "Procesos espectrales (FFT)"
    category = "Espectral"
    description = ("Transformaciones en el dominio de la frecuencia: robotización, susurro, "
                   "puerta espectral, desenfoque (blur), congelado (freeze) e inversión espectral.")
    params = [
        Param("mode", "Proceso", "choice", "robotización",
              choices=["robotización", "susurro (fases aleatorias)", "puerta espectral",
                       "desenfoque espectral (blur)", "congelado (freeze)", "inversión espectral",
                       "cuantización de magnitudes"]),
        Param("fft", "Tamaño FFT", "choice", "2048", choices=["256", "512", "1024", "2048", "4096", "8192"]),
        Param("thresh", "Umbral (puerta)", "float", -40.0, -100.0, 0.0, unit="dB"),
        Param("blur", "Cantidad de desenfoque", "float", 0.9, 0.0, 0.999),
        Param("freeze_pos", "Posición de congelado", "float", 0.2, 0.0, 1.0),
        Param("steps", "Niveles de cuantización", "int", 6, 2, 64),
        Param("mix", "Mezcla", "float", 1.0, 0.0, 1.0),
    ]

    @classmethod
    def process(cls, x, sr, p, ctx):
        x = as_2d(x)
        N = int(p["fft"])
        H = N // 4
        rng = np.random.default_rng(0)
        out = np.zeros_like(x)
        for c in range(x.shape[1]):
            X = _stft(x[:, c], N, H)
            mag, ph = np.abs(X), np.angle(X)
            m = p["mode"]
            if m == "robotización":
                ph = np.zeros_like(ph)
            elif m.startswith("susurro"):
                ph = rng.uniform(-np.pi, np.pi, ph.shape)
            elif m == "puerta espectral":
                ref = np.max(mag) or 1
                mag = np.where(20 * np.log10(mag / ref + 1e-12) < p["thresh"], 0, mag)
            elif m.startswith("desenfoque"):
                mag = signal.lfilter([1 - p["blur"]], [1, -p["blur"]], mag, axis=0)
            elif m.startswith("congelado"):
                i = int(p["freeze_pos"] * (len(mag) - 1))
                mag = np.repeat(mag[i:i + 1], len(mag), axis=0)
                ph = rng.uniform(-np.pi, np.pi, ph.shape)
            elif m.startswith("inversión"):
                mag = mag[:, ::-1]
            else:
                ref = np.max(mag) or 1
                q = p["steps"]
                db = 20 * np.log10(mag / ref + 1e-12)
                db = np.round(np.clip(db, -90, 0) / 90 * q) / q * 90
                mag = ref * 10 ** (db / 20) * (db > -90)
            y = _istft(mag * np.exp(1j * ph), N, H, len(x))
            out[:, c] = (1 - p["mix"]) * x[:, c] + p["mix"] * y
        return out


EFFECTS = [
    Gain, Fade, Utility, Pan,
    Distortion, Bitcrusher,
    Compressor, Gate,
    Delay, Reverb, ConvolutionReverb,
    Chorus, Flanger, Phaser, Tremolo, RingMod, Vibrato,
    TimeStretch, PitchShift,
    Spectral,
]

# Qué esperar al oír cada procesador (se muestra en la interfaz)
SOUND_HINTS = {
    "Filtro IIR clásico (Butterworth, Chebyshev, Elíptico, Bessel)":
        "Quita graves o agudos de forma limpia. Paso bajo = más oscuro y lejano; paso alto = más fino, 'de radio'.",
    "Biquad (EQ Cookbook RBJ)": "Realza o atenúa una zona concreta: más cuerpo, más presencia, quitar un zumbido.",
    "Ecualizador paramétrico (5 bandas)": "Ajuste tonal fino como en una mesa de mezclas: más graves, menos 'caja', más brillo.",
    "Filtro FIR (ventana / sinc)": "Como el IIR pero sin desfase (fase lineal): cortes muy limpios y precisos.",
    "Filtro resonante modulable (SVF / Moog / auto-wah)":
        "Filtro de sintetizador: 'wah-wah', barridos que se abren, resonancias silbantes que se mueven.",
    "Filtro peine (comb)": "Coloración metálica, afinada o 'de tubo'; con realimentación alta, resuena como una cuerda.",
    "Filtro de formantes (vocal)": "Hace que cualquier sonido 'hable' vocales: a, e, i, o, u (efecto talk box).",
    "Ganancia / Normalizar": "Más o menos volumen, o lleva el sonido al nivel máximo sin distorsionar.",
    "Fundido de entrada / salida": "Entradas y salidas suaves, sin clics.",
    "Utilidades (invertir, polaridad, DC, canales)": "Sonido al revés (reverse), convertir mono/estéreo, limpiar el DC.",
    "Paneo / Ancho estéreo": "Mueve el sonido a izquierda/derecha o lo hace más ancho o más mono.",
    "Distorsión / Saturación": "De calidez de válvula a fuzz agresivo; el plegado da un timbre metálico y áspero.",
    "Bitcrusher (reducción de bits / muestreo)": "Sonido 'lo-fi' de videojuego antiguo o sampler de 8 bits, granulado y áspero.",
    "Compresor / Limitador": "Sonido más parejo, compacto y 'al frente'; el limitador evita que sature.",
    "Puerta de ruido / Expansor": "Silencia el ruido de fondo entre notas; con umbral alto, cortes rítmicos.",
    "Delay / Eco": "Repeticiones del sonido; en ping-pong rebotan de un lado a otro.",
    "Reverberación algorítmica (Freeverb)": "Ambiente de sala: de una habitación pequeña a una catedral.",
    "Reverberación por convolución": "Espacio muy realista (o la acústica de la IR que cargues); colas largas y densas.",
    "Chorus": "Más ancho y 'grueso', como varias copias tocando a la vez (típico de pads y guitarras de los 80).",
    "Flanger": "Barrido metálico tipo 'avión a reacción'.",
    "Phaser": "Barrido suave y giratorio, más sutil que el flanger.",
    "Trémolo / Auto-paneo": "Vibración rítmica del volumen, o sonido que va y viene entre los altavoces.",
    "Modulador en anillo": "Timbre metálico e inarmónico, voces de robot, campanas distorsionadas.",
    "Vibrato (modulación de tono)": "Ondulación de la altura, como un cantante o una cinta vieja (wow).",
    "Estiramiento temporal (vocoder de fase)": "Alarga o acorta el sonido sin cambiar la nota; muy estirado se vuelve una textura etérea.",
    "Transposición (cambio de tono)": "Sube o baja la nota; sin conservar la duración suena como una cinta acelerada.",
    "Procesos espectrales (FFT)": "Transformaciones radicales: voz de robot, susurro, sonidos congelados o difuminados.",
}
for _p in FILTERS + EFFECTS:
    _p.sound = SOUND_HINTS.get(_p.name, "")

ALL_PROCESSORS = FILTERS + EFFECTS
PROCESSOR_BY_NAME = {e.name: e for e in ALL_PROCESSORS}
CATEGORIES = []
for e in ALL_PROCESSORS:
    if e.category not in CATEGORIES:
        CATEGORIES.append(e.category)


def run_chain(x: np.ndarray, sr: int, chain: list[dict], ctx: dict | None = None, progress=None) -> np.ndarray:
    """chain: lista de {'name': str, 'params': dict, 'bypass': bool}."""
    ctx = ctx or {}
    y = as_2d(x).astype(np.float64)
    active = [c for c in chain if not c.get("bypass")]
    for i, item in enumerate(active):
        cls = PROCESSOR_BY_NAME[item["name"]]
        p = cls.coerce(item.get("params", {}))
        y = np.nan_to_num(as_2d(cls.process(y, sr, p, ctx)))
        if progress:
            progress(i + 1, len(active), cls.name)
    return y
