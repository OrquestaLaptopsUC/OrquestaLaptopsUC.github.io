@echo off
rem Igual que ejecutar.bat pero deja visible la consola (util para ver mensajes de error).
cd /d "%~dp0"
".venv\Scripts\python.exe" main.py
pause
